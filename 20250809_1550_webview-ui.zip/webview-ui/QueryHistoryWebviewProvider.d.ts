import * as vscode from 'vscode';
import { QueryHistoryOrchestrator } from '../src/features/queryHistoryManager/QueryHistoryOrchestrator';
export declare class QueryHistoryWebviewProvider implements vscode.WebviewViewProvider {
    private readonly _extensionUri;
    static readonly viewType = "prologQueryHistory";
    private _view?;
    private orchestrator;
    constructor(_extensionUri: vscode.Uri, orchestrator: QueryHistoryOrchestrator);
    resolveWebviewView(webviewView: vscode.WebviewView, context: vscode.WebviewViewResolveContext, _token: vscode.CancellationToken): void;
    private _refresh;
    private _postMessage;
    private _getHtmlForWebview;
}
//# sourceMappingURL=QueryHistoryWebviewProvider.d.ts.map