'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
exports.activate = activate;
exports.deactivate = deactivate;
const extensionManager_1 = require("./modules/extensionManager");
// Global extension manager instance
let extensionManager = null;
// This method is called when your extension is activated
// Your extension is activated the very first time the command is executed
async function activate(context) {
    try {
        // Get the singleton extension manager instance
        extensionManager = extensionManager_1.ExtensionManager.getInstance();
        // Activate the extension through the manager
        await extensionManager.activate(context);
    }
    catch (error) {
        console.error('[Extension] Failed to activate extension:', error);
        throw error;
    }
}
// This method is called when your extension is deactivated
async function deactivate() {
    if (extensionManager) {
        try {
            await extensionManager.deactivate();
        }
        catch (error) {
            console.error('[Extension] Error during deactivation:', error);
        }
        finally {
            extensionManager = null;
        }
    }
}
//# sourceMappingURL=extension.js.map