import { ExtensionContext } from 'vscode';
export declare function activate(context: ExtensionContext): Promise<void>;
export declare function deactivate(): Promise<void>;
//# sourceMappingURL=extension.d.ts.map