'use strict';
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExtensionManager = void 0;
const path = __importStar(require("path"));
const vscode_1 = require("vscode");
const apiServer_1 = require("../features/apiServer");
const definitionProvider_js_1 = require("../features/definitionProvider.js");
const documentHighlightProvider_js_1 = __importDefault(require("../features/documentHighlightProvider.js"));
const editHelpers_js_1 = require("../features/editHelpers.js");
const externalWebSocketManager_js_1 = require("../features/externalWebSocketManager.js");
const hoverProvider_js_1 = __importDefault(require("../features/hoverProvider.js"));
const prologLinter_js_1 = __importDefault(require("../features/linting/prologLinter.js"));
const multiIDESupport_js_1 = require("../features/multiIDESupport.js");
const prologActivityProvider_js_1 = require("../features/prologActivityProvider.js");
const prologDashboardProvider_js_1 = require("../features/prologDashboardProvider.js");
const prologFormatter_js_1 = require("../features/prologFormatter.js");
const prologLSPClient_js_1 = require("../features/prologLSPClient.js");
const prologRefactor_js_1 = require("../features/prologRefactor.js");
const prologTerminal_js_1 = __importDefault(require("../features/prologTerminal.js"));
const QueryHistoryOrchestrator_1 = require("../features/queryHistoryManager/QueryHistoryOrchestrator");
const referenceProvider_js_1 = require("../features/referenceProvider.js");
const registerQueryHistoryWebview_1 = require("../features/registerQueryHistoryWebview");
const settingsWebviewProvider_js_1 = require("../features/settingsWebviewProvider.js");
const updateSnippets_js_1 = require("../features/updateSnippets.js");
const prologBackend_js_1 = require("../prologBackend.js");
// Utils import removed; use modular utilities instead
const utils_1 = require("../utils/utils");
const chatHandler_js_1 = require("./chatHandler.js");
const configurationManager_js_1 = require("./configurationManager.js");
const installationManager_js_1 = require("./installationManager.js");
const chatCommandRegistry_1 = require("./chatCommandRegistry");
const chatInputCompletionProvider_1 = require("./chatInputCompletionProvider");
const telemetryCollector_1 = require("./telemetryCollector");
class ExtensionManager {
    static instance;
    // Global instances
    prologBackend = null;
    prologLSPClient = null;
    apiServer = null;
    externalWebSocketManager = null;
    // Module instances
    telemetry;
    chatHandler;
    installationManager;
    configurationManager;
    // Query History Orchestrator
    queryHistoryOrchestrator;
    constructor() {
        this.telemetry = new telemetryCollector_1.TelemetryCollector();
        this.chatHandler = new chatHandler_js_1.ChatHandler(null, this.telemetry);
        this.installationManager = installationManager_js_1.InstallationManager.getInstance();
        this.configurationManager = configurationManager_js_1.ConfigurationManager.getInstance();
        this.queryHistoryOrchestrator = new QueryHistoryOrchestrator_1.QueryHistoryOrchestrator();
    }
    static getInstance() {
        if (!ExtensionManager.instance) {
            ExtensionManager.instance = new ExtensionManager();
        }
        return ExtensionManager.instance;
    }
    // Main activation method
    async activate(context) {
        console.log('Congratulations, your extension "vsc-prolog" is now active! :)');
        // Check SWI-Prolog installation before proceeding
        await this.installationManager.checkAndHandleInstallation(context);
        // Initialize workspace for dialect
        await this.configurationManager.initForDialect(context);
        // Initialize core extension features
        await this.initializeCoreFeatures(context);
        // Initialize backend and services
        await this.initializeBackendServices(context);
        // Register providers and UI components
        this.registerProvidersAndUI(context);
        // Start backend automatically (with error handling)
        this.startBackend();
    }
    // Initialize core extension features
    async initializeCoreFeatures(context) {
        // Filter the files to process
        const PROLOG_MODE = { language: 'prolog', scheme: 'file' };
        // Load snippets file with its predicates
        utils_1.SnippetUtils.loadSnippets(context);
        // Automatic indent on change
        (0, editHelpers_js_1.loadEditHelpers)(context.subscriptions);
        // Register extension commands
        this.registerExtensionCommands(context);
        // Register installation commands
        this.installationManager.registerInstallationCommands(context);
        // Initialize linter if enabled
        this.initializeLinter(context, PROLOG_MODE);
        // Register language providers
        this.registerLanguageProviders(context, PROLOG_MODE);
        // Initialize terminal and snippets
        this.initializeTerminalAndSnippets(context, PROLOG_MODE);
    }
    // Register extension-specific commands
    registerExtensionCommands(context) {
        const myCommands = [
            {
                command: 'prolog.load.document',
                callback: () => {
                    prologTerminal_js_1.default.loadDocument();
                },
            },
            {
                command: 'prolog.query.goal',
                callback: () => {
                    prologTerminal_js_1.default.queryGoalUnderCursor();
                },
            },
            {
                command: 'prolog.refactorPredicate',
                callback: () => {
                    new prologRefactor_js_1.PrologRefactor().refactorPredUnderCursor();
                },
            },
            {
                command: 'prolog.openSettings',
                callback: () => {
                    // This will be handled by the webview view registration
                },
            },
            {
                command: 'prolog.newFile',
                callback: async () => {
                    await this.createNewPrologFile();
                },
            },
            {
                command: 'prolog.rerunQuery',
                callback: async (query) => {
                    await this.rerunQuery(query);
                },
            },
            {
                command: 'prolog.clearQueryHistory',
                callback: async () => {
                    vscode_1.window.showInformationMessage('Query history cleared');
                },
            },
            {
                command: 'prolog.viewLogs',
                callback: () => {
                    vscode_1.commands.executeCommand('workbench.action.showLogs');
                },
            },
            {
                command: 'prolog.reportIssue',
                callback: () => {
                    const issueUrl = 'https://github.com/mediaprophet/VSCode-Prolog-Toolkit/issues/new';
                    vscode_1.commands.executeCommand('vscode.open', issueUrl);
                },
            },
        ];
        // Register commands
        myCommands.forEach(command => {
            context.subscriptions.push(vscode_1.commands.registerCommand(command.command, command.callback));
        });
    }
    // Initialize linter if enabled
    initializeLinter(context, PROLOG_MODE) {
        let linter;
        if (this.configurationManager.getConfiguration().linterTrigger !== 'never') {
            linter = new prologLinter_js_1.default(context);
            linter.activate();
            // Register linter commands
            const linterCommands = [
                {
                    command: 'prolog.linter.nextErrLine',
                    callback: () => {
                        linter?.nextErrLine();
                    },
                },
                {
                    command: 'prolog.linter.prevErrLine',
                    callback: () => {
                        linter?.prevErrLine();
                    },
                },
            ];
            linterCommands.forEach(command => {
                context.subscriptions.push(vscode_1.commands.registerCommand(command.command, command.callback));
            });
            // Register code actions provider
            context.subscriptions.push(vscode_1.languages.registerCodeActionsProvider(PROLOG_MODE, linter));
        }
    }
    // Register language providers
    registerLanguageProviders(context, PROLOG_MODE) {
        // Hover provider
        context.subscriptions.push(vscode_1.languages.registerHoverProvider(PROLOG_MODE, new hoverProvider_js_1.default()));
        // Highlight provider
        context.subscriptions.push(vscode_1.languages.registerDocumentHighlightProvider(PROLOG_MODE, new documentHighlightProvider_js_1.default()));
        // Definition provider (go to definition command)
        context.subscriptions.push(vscode_1.languages.registerDefinitionProvider(PROLOG_MODE, new definitionProvider_js_1.PrologDefinitionProvider()));
        // Reference provider (find all references command)
        context.subscriptions.push(vscode_1.languages.registerReferenceProvider(PROLOG_MODE, new referenceProvider_js_1.PrologReferenceProvider()));
        // Auto completion provider
        context.subscriptions.push(vscode_1.languages.registerCompletionItemProvider(PROLOG_MODE, new updateSnippets_js_1.PrologCompletionProvider()));
        // File formatting provider
        context.subscriptions.push(vscode_1.languages.registerDocumentRangeFormattingEditProvider(PROLOG_MODE, new prologFormatter_js_1.PrologFormatter()));
        context.subscriptions.push(vscode_1.languages.registerDocumentFormattingEditProvider(PROLOG_MODE, new prologFormatter_js_1.PrologFormatter()));
    }
    // Initialize terminal and snippets
    initializeTerminalAndSnippets(context, PROLOG_MODE) {
        // Create prolog terminal (load file command)
        context.subscriptions.push(prologTerminal_js_1.default.init());
        // Add created predicate to the snippet
        const snippetUpdater = new updateSnippets_js_1.SnippetUpdater();
        context.subscriptions.push(new updateSnippets_js_1.SnippetUpdaterController(snippetUpdater));
        context.subscriptions.push(snippetUpdater);
    }
    // Initialize backend and services
    async initializeBackendServices(context) {
        const config = vscode_1.workspace.getConfiguration('prolog');
        const swiplPath = config.get('executablePath', 'swipl');
        // Initialize Prolog backend
        this.prologBackend = new prologBackend_js_1.PrologBackend({
            swiplPath,
            port: 3060,
            streamingEnabled: true,
            maxResultsPerChunk: 50,
        });
        // Update chat handler with backend reference
        this.chatHandler.updateBackend(this.prologBackend);
        // Initialize API server if enabled
        await this.initializeApiServer(config);
        // Initialize LSP services
        await this.initializeLSPServices(context);
        // Generate multi-IDE configurations
        await this.initializeMultiIDESupport();
        // Set up backend event handlers
        this.setupBackendEventHandlers();
    }
    // Initialize API server if enabled
    async initializeApiServer(config) {
        const apiServerEnabled = config.get('apiServer.enabled', false);
        if (apiServerEnabled && this.prologBackend) {
            try {
                const apiServerConfig = {
                    enabled: true,
                    port: config.get('apiServer.port', 8080),
                    host: config.get('apiServer.host', 'localhost'),
                    corsOrigins: config.get('apiServer.corsOrigins', ['http://localhost:*']),
                    maxConnections: config.get('apiServer.maxConnections', 100),
                    requestTimeout: config.get('apiServer.requestTimeout', 60000),
                    rateLimiting: {
                        enabled: config.get('apiServer.rateLimiting.enabled', true),
                        requestsPerMinute: config.get('apiServer.rateLimiting.requestsPerMinute', 60),
                        burstLimit: config.get('apiServer.rateLimiting.burstLimit', 10),
                    },
                    auth: this.configurationManager.createAuthConfig(config),
                };
                this.apiServer = new apiServer_1.ApiServer({
                    config: apiServerConfig,
                    prologBackend: this.prologBackend,
                });
                // Initialize external WebSocket manager if enabled
                const wsEnabled = config.get('webSocketServer.enabled', true);
                if (wsEnabled) {
                    const wsConfig = {
                        enabled: true,
                        port: config.get('webSocketServer.port', 8081),
                        maxConnections: config.get('webSocketServer.maxConnections', 50),
                        heartbeatInterval: config.get('webSocketServer.heartbeatInterval', 30),
                        auth: apiServerConfig.auth,
                    };
                    this.externalWebSocketManager = new externalWebSocketManager_js_1.ExternalWebSocketManager(wsConfig, this.prologBackend.getNotificationManager());
                }
                console.log('[Extension] API server and WebSocket manager initialized');
            }
            catch (error) {
                console.error('[Extension] Failed to initialize API server:', error);
                vscode_1.window.showErrorMessage(`Failed to initialize API server: ${error}`);
            }
        }
    }
    // Initialize LSP services
    async initializeLSPServices(context) {
        if (!this.prologBackend)
            return;
        // Initialize full LSP Client
        this.prologLSPClient = new prologLSPClient_js_1.PrologLSPClient(context);
        // Start LSP client
        try {
            await this.prologLSPClient.start();
            console.log('[Extension] Prolog LSP Client started successfully');
        }
        catch (error) {
            console.error('[Extension] Failed to start Prolog LSP Client:', error);
            vscode_1.window.showWarningMessage('Prolog LSP Client failed to start. Some features may not be available.');
        }
    }
    // Initialize multi-IDE support
    async initializeMultiIDESupport() {
        const workspaceFolder = vscode_1.workspace.workspaceFolders?.[0];
        if (workspaceFolder) {
            try {
                await multiIDESupport_js_1.MultiIDESupport.generateIDEConfigurations(workspaceFolder.uri.fsPath);
                multiIDESupport_js_1.MultiIDESupport.generateLaunchConfigurations(workspaceFolder.uri.fsPath);
                // Detect available IDEs
                const availableIDEs = await multiIDESupport_js_1.MultiIDESupport.detectAvailableIDEs();
                if (availableIDEs.length > 1) {
                    console.log('[Extension] Detected IDEs:', availableIDEs.join(', '));
                }
            }
            catch (error) {
                console.error('[Extension] Failed to generate multi-IDE configurations:', error);
            }
        }
    }
    // Set up backend event handlers
    setupBackendEventHandlers() {
        if (!this.prologBackend)
            return;
        this.prologBackend.on('ready', () => {
            console.log('[Extension] Prolog backend ready');
            vscode_1.window.showInformationMessage('Prolog backend started successfully');
        });
        this.prologBackend.on('stopped', () => {
            console.log('[Extension] Prolog backend stopped');
            vscode_1.window.showWarningMessage('Prolog backend stopped');
        });
        this.prologBackend.on('restarted', () => {
            console.log('[Extension] Prolog backend restarted');
            vscode_1.window.showInformationMessage('Prolog backend restarted successfully');
        });
        this.prologBackend.on('error', error => {
            console.error('[Extension] Prolog backend error:', error);
            vscode_1.window.showErrorMessage(`Prolog backend error: ${error}`);
        });
    }
    // Register providers and UI components
    registerProvidersAndUI(context) {
        // Register chat participant with enhanced followup provider
        const chatParticipant = vscode_1.chat.createChatParticipant('prolog', (request, context, stream, token) => this.chatHandler.handleChatRequest(request, context, stream, token));
        chatParticipant.iconPath = new vscode_1.ThemeIcon('symbol-class');
        chatParticipant.followupProvider = {
            provideFollowups(result, _context, __token) {
                return ExtensionManager.getInstance().getChatFollowups(result);
            },
        };
        context.subscriptions.push(chatParticipant);
        // Register chat input inline completion provider
        const chatCommandRegistry = new chatCommandRegistry_1.ChatCommandRegistry();
        const chatInputCompletionProvider = new chatInputCompletionProvider_1.ChatInputCompletionProvider(chatCommandRegistry);
        // Use a document selector for the chat input. Adjust language if needed.
        const chatInputSelector = { language: 'prolog-chat', scheme: 'untitled' };
        context.subscriptions.push(vscode_1.languages.registerInlineCompletionItemProvider(chatInputSelector, chatInputCompletionProvider));
        // Register settings webview provider
        const settingsProvider = new settingsWebviewProvider_js_1.SettingsWebviewProvider(context.extensionUri);
        context.subscriptions.push(vscode_1.window.registerWebviewViewProvider(settingsWebviewProvider_js_1.SettingsWebviewProvider.viewType, settingsProvider));
        // Register Query History Webview
        (0, registerQueryHistoryWebview_1.registerQueryHistoryWebview)(context, this.queryHistoryOrchestrator);
        // Register activity bar providers
        const prologActivityProvider = new prologActivityProvider_js_1.PrologActivityProvider(context);
        const prologDashboardProvider = new prologDashboardProvider_js_1.PrologDashboardProvider(context.extensionUri);
        context.subscriptions.push(vscode_1.window.registerTreeDataProvider('prologActivity', prologActivityProvider), vscode_1.window.registerTreeDataProvider('prologQueries', prologActivityProvider), vscode_1.window.registerTreeDataProvider('prologFiles', prologActivityProvider), vscode_1.window.registerWebviewViewProvider(prologDashboardProvider_js_1.PrologDashboardProvider.viewType, prologDashboardProvider));
        // Refresh activity bar when installation status changes
        const refreshActivityBar = () => {
            prologActivityProvider.refresh();
        };
        // Listen for configuration changes to refresh activity bar
        context.subscriptions.push(vscode_1.workspace.onDidChangeConfiguration(event => {
            if (event.affectsConfiguration('prolog')) {
                refreshActivityBar();
            }
        }));
    }
    // Get chat followups based on result
    getChatFollowups(result) {
        const followups = [];
        // Context-aware followups based on command type
        if (result.metadata?.command === 'query') {
            followups.push({
                prompt: '/status',
                label: '🔧 Check backend status',
            });
            followups.push({
                prompt: '/help findall/3',
                label: '📖 Learn about findall/3',
            });
        }
        if (result.metadata?.command === 'consult') {
            followups.push({
                prompt: '/query',
                label: '🔍 Run a query',
            });
        }
        if (result.metadata?.command === 'error') {
            followups.push({
                prompt: '/status',
                label: '🚨 Check what went wrong',
            });
            followups.push({
                prompt: '/help',
                label: '❓ Show help',
            });
        }
        if (result.metadata?.command === 'n3_load') {
            followups.push({
                prompt: '/n3_list --limit 10',
                label: '📋 List loaded triples',
            });
            followups.push({
                prompt: '/n3_reason',
                label: '🧠 Start reasoning',
            });
        }
        // Always include help as fallback
        followups.push({
            prompt: '/help',
            label: '💡 Show all commands',
        });
        return followups;
    }
    // Start backend
    startBackend() {
        try {
            this.prologBackend?.start();
        }
        catch (error) {
            console.error('[Extension] Failed to start Prolog backend:', error);
            // Don't show error immediately - let user trigger it via chat if needed
        }
    }
    // Helper method to create new Prolog file
    async createNewPrologFile() {
        const fileName = await vscode_1.window.showInputBox({
            prompt: 'Enter the name for the new Prolog file',
            value: 'untitled.pl',
            validateInput: value => {
                if (!value)
                    return 'File name cannot be empty';
                if (!value.match(/\.(pl|pro|prolog|plt|ecl)$/)) {
                    return 'File must have a Prolog extension (.pl, .pro, .prolog, .plt, .ecl)';
                }
                return null;
            },
        });
        if (fileName) {
            const workspaceFolder = vscode_1.workspace.workspaceFolders?.[0];
            if (workspaceFolder) {
                const uri = vscode_1.window.activeTextEditor?.document.uri || workspaceFolder.uri;
                const newFileUri = uri.with({ path: path.join(path.dirname(uri.fsPath), fileName) });
                const edit = new vscode_1.WorkspaceEdit();
                edit.createFile(newFileUri, { ignoreIfExists: false });
                await Promise.resolve(vscode_1.workspace.applyEdit(edit));
                await vscode_1.window.showTextDocument(newFileUri);
            }
            else {
                const doc = await vscode_1.workspace.openTextDocument({
                    language: 'prolog',
                    content: `% ${fileName}\n% New Prolog file\n\n`,
                });
                await vscode_1.window.showTextDocument(doc);
            }
        }
    }
    // Helper method to rerun query
    async rerunQuery(query) {
        if (query && this.prologBackend?.isRunning()) {
            try {
                const response = await this.prologBackend.sendRequest('query', { goal: query });
                if (response.status === 'ok') {
                    vscode_1.window.showInformationMessage(`Query executed: ${query}`);
                }
                else {
                    vscode_1.window.showErrorMessage(`Query failed: ${response.error}`);
                }
            }
            catch (error) {
                vscode_1.window.showErrorMessage(`Query error: ${error}`);
            }
        }
    }
    // Deactivation method
    async deactivate() {
        // Stop API server
        if (this.apiServer) {
            try {
                await this.apiServer.stop();
                console.log('[Extension] API server stopped');
            }
            catch (error) {
                console.error('[Extension] Error stopping API server:', error);
            }
            this.apiServer = null;
        }
        // Stop external WebSocket manager
        if (this.externalWebSocketManager) {
            try {
                await this.externalWebSocketManager.stop();
                console.log('[Extension] External WebSocket manager stopped');
            }
            catch (error) {
                console.error('[Extension] Error stopping WebSocket manager:', error);
            }
            this.externalWebSocketManager = null;
        }
        // Stop LSP client
        if (this.prologLSPClient) {
            try {
                await this.prologLSPClient.stop();
                console.log('[Extension] Prolog LSP Client stopped');
            }
            catch (error) {
                console.error('[Extension] Error stopping LSP Client:', error);
            }
            this.prologLSPClient = null;
        }
        // Stop backend
        if (this.prologBackend) {
            this.prologBackend.stop(true);
            this.prologBackend = null;
        }
    }
}
exports.ExtensionManager = ExtensionManager;
//# sourceMappingURL=extensionManager.js.map