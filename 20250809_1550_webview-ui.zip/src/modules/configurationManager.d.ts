import { ExtensionContext } from 'vscode';
import { AuthConfig } from '../features/apiMiddleware';
export declare class ConfigurationManager {
    private static instance;
    private constructor();
    static getInstance(): ConfigurationManager;
    initForDialect(context: ExtensionContext): Promise<void>;
    createAuthConfig(config: any): AuthConfig;
    getConfiguration(): {
        dialect: string;
        executablePath: string;
        linterTrigger: string;
        formatEnabled: boolean;
        apiServerEnabled: boolean;
        webSocketEnabled: boolean;
        telemetryEnabled: boolean;
    };
}
//# sourceMappingURL=configurationManager.d.ts.map