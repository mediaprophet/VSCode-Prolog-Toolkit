'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelemetryCollector = void 0;
const vscode_1 = require("vscode");
// Simple telemetry collector (can be disabled via settings)
class TelemetryCollector {
    enabled = false;
    data = [];
    constructor() {
        const config = vscode_1.workspace.getConfiguration('prolog');
        this.enabled = config.get('telemetry.enabled', false);
    }
    collect(data) {
        if (this.enabled && this.data.length < 1000) {
            // Limit storage
            this.data.push(data);
        }
    }
    getStats() {
        if (!this.enabled)
            return null;
        const commands = this.data.reduce((acc, item) => {
            acc[item.command] = (acc[item.command] || 0) + 1;
            return acc;
        }, {});
        return { totalCommands: this.data.length, commands };
    }
}
exports.TelemetryCollector = TelemetryCollector;
//# sourceMappingURL=telemetryCollector.js.map