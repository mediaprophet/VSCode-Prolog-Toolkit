import { CancellationToken, ChatRequest, ChatResponseStream, ChatResult } from 'vscode';
import { PrologBackend } from '../prologBackend';
import { TelemetryCollector } from './telemetryCollector';
export declare class ChatHandler {
    private prologBackend;
    private telemetry;
    private registry;
    private chatHistory;
    constructor(prologBackend: PrologBackend | null, telemetry: TelemetryCollector);
    updateBackend(backend: PrologBackend | null): void;
    handleChatRequest(request: ChatRequest, context: any, stream: ChatResponseStream, token: CancellationToken): Promise<ChatResult>;
}
//# sourceMappingURL=chatHandler.d.ts.map