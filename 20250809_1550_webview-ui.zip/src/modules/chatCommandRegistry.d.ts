import { ChatCommand } from './chat-commands/types';
export declare class ChatCommandRegistry {
    private commands;
    constructor();
    /**
     * Helper to register all built-in commands in a single place for maintainability.
     */
    private registerAllCommands;
    /**
     * Returns all registered chat commands.
     */
    getAllCommands(): ChatCommand[];
    findHandler(command: string): ChatCommand | undefined;
    registerCommand(cmd: ChatCommand): void;
    unregisterCommand(commandName: string): void;
}
//# sourceMappingURL=chatCommandRegistry.d.ts.map