export interface TelemetryData {
    command: string;
    success: boolean;
    error?: string;
    timestamp: number;
}
export declare class TelemetryCollector {
    private enabled;
    private data;
    constructor();
    collect(data: TelemetryData): void;
    getStats(): {
        totalCommands: number;
        commands: Record<string, number>;
    };
}
//# sourceMappingURL=telemetryCollector.d.ts.map