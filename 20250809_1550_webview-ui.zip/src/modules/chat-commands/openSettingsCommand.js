"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OpenSettingsCommand = void 0;
const vscode_1 = require("vscode");
class OpenSettingsCommand {
    name = '/open_settings';
    description = 'Open the VS Code settings UI.';
    arguments = [];
    canHandle(command) {
        return command === 'open_settings' || command === '/open_settings';
    }
    async handle(args, request, stream, token, context) {
        try {
            await vscode_1.commands.executeCommand('workbench.action.openSettings');
            stream.markdown('Settings UI opened.');
        }
        catch (err) {
            stream.markdown('Failed to open settings: ' + err);
        }
    }
}
exports.OpenSettingsCommand = OpenSettingsCommand;
//# sourceMappingURL=openSettingsCommand.js.map