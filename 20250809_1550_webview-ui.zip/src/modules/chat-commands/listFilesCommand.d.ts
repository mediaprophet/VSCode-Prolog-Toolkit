import { CancellationToken, ChatRequest, ChatResponseStream } from 'vscode';
import { ChatCommand, ChatCommandContext } from './types';
export declare class ListFilesCommand implements ChatCommand {
    name: string;
    description: string;
    arguments: any[];
    canHandle(command: string): boolean;
    handle(args: string, request: ChatRequest, stream: ChatResponseStream, token: CancellationToken, context: ChatCommandContext): Promise<void>;
    private listFilesRecursive;
}
//# sourceMappingURL=listFilesCommand.d.ts.map