"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConsultCommand = void 0;
class ConsultCommand {
    name = '/consult';
    description = 'Consult a Prolog file in the backend.';
    arguments = [
        {
            name: 'file',
            type: 'file',
            description: 'The Prolog file to consult (e.g. family.pl).',
            example: 'family.pl',
            required: true
        }
    ];
    canHandle(command) {
        return command === '/consult' || command === 'consult';
    }
    async handle(args, request, stream, token, context) {
        stream.markdown('Consult command handler (stub)');
    }
}
exports.ConsultCommand = ConsultCommand;
//# sourceMappingURL=consultCommand.js.map