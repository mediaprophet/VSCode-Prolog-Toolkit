"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProblemsCommand = void 0;
const vscode_1 = require("vscode");
class ProblemsCommand {
    name = '/problems';
    description = 'Show current diagnostics from the Problems panel.';
    arguments = [];
    canHandle(command) {
        return command === 'problems' || command === '/problems';
    }
    async handle(args, request, stream, token, context) {
        // Show current diagnostics from Problems panel
        const allDiagnostics = vscode_1.languages.getDiagnostics();
        if (!allDiagnostics.length) {
            stream.markdown('No problems found.');
            return;
        }
        let output = '**Problems Panel Diagnostics:**\n';
        for (const [uri, diags] of allDiagnostics) {
            if (!diags.length)
                continue;
            output += `- **${uri.fsPath}**\n`;
            for (const d of diags) {
                output += `  - [${d.severity}] ${d.message} (Line ${d.range.start.line + 1})\n`;
            }
        }
        stream.markdown(output);
    }
}
exports.ProblemsCommand = ProblemsCommand;
//# sourceMappingURL=problemsCommand.js.map