"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.N3ListCommand = void 0;
class N3ListCommand {
    name = '/n3_list';
    description = 'List loaded N3 files or graphs.';
    arguments = [];
    canHandle(command) {
        return command === '/n3_list' || command === 'n3_list';
    }
    async handle(args, request, stream, token, context) {
        stream.markdown('N3 list command handler (stub)');
    }
}
exports.N3ListCommand = N3ListCommand;
//# sourceMappingURL=n3ListCommand.js.map