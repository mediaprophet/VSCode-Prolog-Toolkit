import { CancellationToken, ChatRequest, ChatResponseStream } from 'vscode';
import { ChatCommand, ChatCommandContext } from './types';
export declare class ConsultCommand implements ChatCommand {
    name: string;
    description: string;
    arguments: {
        name: string;
        type: string;
        description: string;
        example: string;
        required: boolean;
    }[];
    canHandle(command: string): command is "/consult" | "consult";
    handle(args: string, request: ChatRequest, stream: ChatResponseStream, token: CancellationToken, context: ChatCommandContext): Promise<void>;
}
//# sourceMappingURL=consultCommand.d.ts.map