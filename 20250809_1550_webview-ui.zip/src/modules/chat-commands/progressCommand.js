"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProgressCommand = void 0;
class ProgressCommand {
    name = '/progress';
    description = 'Show backend and task progress status.';
    arguments = [];
    canHandle(command) {
        return command === 'progress' || command === '/progress';
    }
    async handle(args, request, stream, token, context) {
        // Example: Show status of backend and any known long-running tasks
        let progressInfo = '**Progress Status:**\n';
        if (context.prologBackend) {
            progressInfo += `- Backend running: ${context.prologBackend.isRunning ? context.prologBackend.isRunning() : 'unknown'}\n`;
        }
        else {
            progressInfo += '- Backend: unknown\n';
        }
        // Add more task status as needed
        stream.markdown(progressInfo);
    }
}
exports.ProgressCommand = ProgressCommand;
//# sourceMappingURL=progressCommand.js.map