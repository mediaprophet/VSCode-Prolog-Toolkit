"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReloadBackendCommand = void 0;
const vscode_1 = require("vscode");
class ReloadBackendCommand {
    name = '/reload_backend';
    description = 'Reload the Prolog backend service.';
    arguments = [];
    canHandle(command) {
        return command === 'reload_backend' || command === '/reload_backend';
    }
    async handle(args, request, stream, token, context) {
        try {
            await vscode_1.commands.executeCommand('vscode-prolog-toolkit.reloadBackend');
            stream.markdown('Prolog backend reload triggered.');
        }
        catch (err) {
            stream.markdown('Failed to reload backend: ' + err);
        }
    }
}
exports.ReloadBackendCommand = ReloadBackendCommand;
//# sourceMappingURL=reloadBackendCommand.js.map