"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FeedbackCommand = void 0;
class FeedbackCommand {
    name = '/feedback';
    description = 'Send feedback to the extension authors.';
    arguments = [
        {
            name: 'message',
            type: 'string',
            description: 'Your feedback message.',
            example: 'Great extension!',
            required: true
        }
    ];
    canHandle(command) {
        return command === 'feedback' || command === '/feedback';
    }
    async handle(args, request, stream, token, context) {
        // Log feedback as a telemetry event
        if (context.telemetry) {
            context.telemetry.collect({
                command: 'feedback',
                success: true,
                error: args.trim() ? undefined : 'No feedback provided',
                timestamp: Date.now(),
            });
        }
        stream.markdown('Thank you for your feedback!');
    }
}
exports.FeedbackCommand = FeedbackCommand;
//# sourceMappingURL=feedbackCommand.js.map