"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DebugCommand = void 0;
class DebugCommand {
    name = '/debug';
    description = 'Show extension and backend debug diagnostics.';
    arguments = [];
    canHandle(command) {
        return command === 'debug' || command === '/debug';
    }
    async handle(args, request, stream, token, context) {
        // Basic diagnostics: extension status, backend status, memory, etc.
        const diagnostics = {
            extensionActive: true,
            backendStatus: context.prologBackend?.isRunning ? context.prologBackend.isRunning() : 'unknown',
            memoryUsage: process.memoryUsage(),
            platform: process.platform,
            nodeVersion: process.version,
            cwd: process.cwd(),
            timestamp: new Date().toISOString(),
        };
        stream.markdown('**Debug Diagnostics:**\n');
        stream.markdown('```json\n' + JSON.stringify(diagnostics, null, 2) + '\n```');
    }
}
exports.DebugCommand = DebugCommand;
//# sourceMappingURL=debugCommand.js.map