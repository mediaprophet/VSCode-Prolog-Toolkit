"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.ListFilesCommand = void 0;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const vscode_1 = require("vscode");
class ListFilesCommand {
    name = '/list_files';
    description = 'List files in the workspace (depth 2).';
    arguments = [];
    canHandle(command) {
        return command === 'list_files';
    }
    async handle(args, request, stream, token, context) {
        try {
            const folders = vscode_1.workspace.workspaceFolders?.map(f => f.uri.fsPath) || [];
            let files = [];
            for (const folder of folders) {
                files = files.concat(await this.listFilesRecursive(folder, 2)); // limit depth for performance
            }
            stream.markdown('**Workspace Files (depth 2):**\n');
            stream.markdown('```json\n' + JSON.stringify(files, null, 2) + '\n```');
        }
        catch (err) {
            stream.markdown('Failed to list files: ' + err);
            stream.markdown('Try `/troubleshoot`, `/logs`, or see the [README](https://github.com/mediaprophet/VSCode-Prolog-Toolkit#readme) for help.');
        }
    }
    async listFilesRecursive(dir, depth) {
        if (depth < 0)
            return [];
        let results = [];
        const entries = await fs.promises.readdir(dir, { withFileTypes: true });
        for (const entry of entries) {
            const fullPath = path.join(dir, entry.name);
            results.push(fullPath);
            if (entry.isDirectory()) {
                results = results.concat(await this.listFilesRecursive(fullPath, depth - 1));
            }
        }
        return results;
    }
}
exports.ListFilesCommand = ListFilesCommand;
//# sourceMappingURL=listFilesCommand.js.map