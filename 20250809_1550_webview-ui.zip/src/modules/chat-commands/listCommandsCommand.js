"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ListCommandsCommand = void 0;
class ListCommandsCommand {
    name = '/list-commands';
    description = 'List all available chat commands.';
    arguments = [];
    registry;
    constructor(registry) {
        this.registry = registry;
    }
    canHandle(command) {
        return command === '/list-commands' || command === 'list-commands';
    }
    async handle(args, request, stream, token, context) {
        const commands = this.registry.getAllCommands();
        stream.markdown('**Available Chat Commands:**\n');
        for (const cmd of commands) {
            stream.markdown(`- \`${cmd.name}\`: ${cmd.description || ''}`);
        }
        stream.markdown('\nType `/help <command>` for more info.');
    }
}
exports.ListCommandsCommand = ListCommandsCommand;
//# sourceMappingURL=listCommandsCommand.js.map