"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.N3LoadCommand = void 0;
class N3LoadCommand {
    name = '/n3_load';
    description = 'Load an N3 file into the backend.';
    arguments = [
        {
            name: 'file',
            type: 'file',
            description: 'The N3 or Turtle file to load (e.g. data.n3).',
            example: 'data.n3',
            required: true
        }
    ];
    canHandle(command) {
        return command === '/n3_load' || command === 'n3_load';
    }
    async handle(args, request, stream, token, context) {
        stream.markdown('N3 load command handler (stub)');
    }
}
exports.N3LoadCommand = N3LoadCommand;
//# sourceMappingURL=n3LoadCommand.js.map