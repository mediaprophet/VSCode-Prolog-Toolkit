import { CancellationToken, ChatRequest, ChatResponseStream } from 'vscode';
import { ChatCommand, ChatCommandContext } from './types';
export declare class DescribeCommand implements ChatCommand {
    name: string;
    description: string;
    arguments: {
        name: string;
        type: string;
        description: string;
        example: string;
        required: boolean;
    }[];
    canHandle(command: string): boolean;
    handle(args: string, request: ChatRequest, stream: ChatResponseStream, token: CancellationToken, context: ChatCommandContext): Promise<void>;
}
//# sourceMappingURL=describeCommand.d.ts.map