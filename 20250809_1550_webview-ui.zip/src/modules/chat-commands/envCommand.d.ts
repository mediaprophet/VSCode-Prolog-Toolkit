import { CancellationToken, ChatRequest, ChatResponseStream } from 'vscode';
import { ChatCommand, ChatCommandContext } from './types';
export declare class EnvCommand implements ChatCommand {
    name: string;
    description: string;
    arguments: any[];
    canHandle(command: string): boolean;
    handle(args: string, request: ChatRequest, stream: ChatResponseStream, token: CancellationToken, context: ChatCommandContext): Promise<void>;
}
//# sourceMappingURL=envCommand.d.ts.map