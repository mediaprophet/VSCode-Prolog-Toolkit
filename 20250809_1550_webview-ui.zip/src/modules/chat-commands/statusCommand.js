"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatusCommand = void 0;
class StatusCommand {
    name = '/status';
    description = 'Show the current status of the Prolog backend.';
    arguments = [];
    canHandle(command) {
        return command === '/status' || command === 'status';
    }
    async handle(args, request, stream, token, context) {
        stream.markdown('Status command handler (stub)');
    }
}
exports.StatusCommand = StatusCommand;
//# sourceMappingURL=statusCommand.js.map