"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelemetryStatsCommand = void 0;
class TelemetryStatsCommand {
    name = '/telemetry_stats';
    description = 'Show telemetry statistics collected by the extension.';
    arguments = [];
    canHandle(command) {
        return command === 'telemetry_stats' || command === '/telemetry_stats';
    }
    async handle(args, request, stream, token, context) {
        if (!context.telemetry) {
            stream.markdown('Telemetry is not available.');
            return;
        }
        const stats = context.telemetry.getStats();
        if (!stats) {
            stream.markdown('Telemetry is disabled or no data collected.');
            return;
        }
        stream.markdown('**Telemetry Stats:**\n');
        stream.markdown('```json\n' + JSON.stringify(stats, null, 2) + '\n```');
    }
}
exports.TelemetryStatsCommand = TelemetryStatsCommand;
//# sourceMappingURL=telemetryStatsCommand.js.map