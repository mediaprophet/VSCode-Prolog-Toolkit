"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InstallCommand = void 0;
const vscode_1 = require("vscode");
class InstallCommand {
    name = '/install';
    description = 'Install a VS Code extension by ID or name.';
    arguments = [
        {
            name: 'extension',
            type: 'string',
            description: 'The extension ID or name to install (e.g. ms-python.python).',
            example: 'ms-python.python',
            required: true
        }
    ];
    canHandle(command) {
        return command === 'install' || command === '/install';
    }
    async handle(args, request, stream, token, context) {
        const extId = args.trim();
        if (!extId) {
            stream.markdown('Please provide an extension ID or name.');
            return;
        }
        try {
            await vscode_1.commands.executeCommand('workbench.extensions.installExtension', extId);
            stream.markdown(`Extension **${extId}** installation triggered.`);
        }
        catch (err) {
            stream.markdown('Failed to install extension: ' + err);
        }
    }
}
exports.InstallCommand = InstallCommand;
//# sourceMappingURL=installCommand.js.map