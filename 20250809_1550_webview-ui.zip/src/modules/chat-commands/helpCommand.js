"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HelpCommand = void 0;
class HelpCommand {
    name = '/help';
    description = 'Show help for chat commands.';
    arguments = [
        {
            name: 'command',
            type: 'string',
            description: 'The command to show help for (e.g. /query).',
            example: '/query',
            required: false
        }
    ];
    canHandle(command) {
        return command === '/help' || command === 'help';
    }
    async handle(args, request, stream, token, context) {
        stream.markdown('Help command handler (stub)');
    }
}
exports.HelpCommand = HelpCommand;
//# sourceMappingURL=helpCommand.js.map