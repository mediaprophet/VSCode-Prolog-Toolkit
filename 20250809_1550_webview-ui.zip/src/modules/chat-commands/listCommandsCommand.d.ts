import { CancellationToken, ChatRequest, ChatResponseStream } from 'vscode';
import { ChatCommandRegistry } from '../chatCommandRegistry';
import { ChatCommand, ChatCommandContext } from './types';
export declare class ListCommandsCommand implements ChatCommand {
    name: string;
    description: string;
    arguments: any[];
    private registry;
    constructor(registry: ChatCommandRegistry);
    canHandle(command: string): boolean;
    handle(args: string, request: ChatRequest, stream: ChatResponseStream, token: CancellationToken, context: ChatCommandContext): Promise<void>;
}
//# sourceMappingURL=listCommandsCommand.d.ts.map