import { CancellationToken, ChatRequest, ChatResponseStream } from 'vscode';
import { ChatCommand, ChatCommandContext } from './types';
export declare class StatusCommand implements ChatCommand {
    name: string;
    description: string;
    arguments: any[];
    canHandle(command: string): command is "status" | "/status";
    handle(args: string, request: ChatRequest, stream: ChatResponseStream, token: CancellationToken, context: ChatCommandContext): Promise<void>;
}
//# sourceMappingURL=statusCommand.d.ts.map