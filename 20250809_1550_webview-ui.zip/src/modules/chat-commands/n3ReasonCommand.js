"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.N3ReasonCommand = void 0;
class N3ReasonCommand {
    name = '/n3_reason';
    description = 'Run N3 reasoning on loaded data.';
    arguments = [];
    canHandle(command) {
        return command === '/n3_reason' || command === 'n3_reason';
    }
    async handle(args, request, stream, token, context) {
        stream.markdown('N3 reason command handler (stub)');
    }
}
exports.N3ReasonCommand = N3ReasonCommand;
//# sourceMappingURL=n3ReasonCommand.js.map