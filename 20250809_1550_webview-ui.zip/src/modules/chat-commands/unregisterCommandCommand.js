"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnregisterCommandCommand = void 0;
class UnregisterCommandCommand {
    name = '/unregister_command';
    description = 'Unregister a chat command by name.';
    arguments = [
        {
            name: 'command',
            type: 'string',
            description: 'The name of the command to unregister.',
            example: '/my_echo',
            required: true
        }
    ];
    canHandle(command) {
        return command === 'unregister_command' || command === '/unregister_command';
    }
    async handle(args, request, stream, token, context) {
        // args: commandName
        const registry = context.registry;
        const name = args.trim();
        if (!name) {
            stream.markdown('Please provide a command name.');
            return;
        }
        if (!registry) {
            stream.markdown('Command registry not available.');
            return;
        }
        registry.unregisterCommand(name);
        stream.markdown(`Unregistered command: **${name}**`);
    }
}
exports.UnregisterCommandCommand = UnregisterCommandCommand;
//# sourceMappingURL=unregisterCommandCommand.js.map