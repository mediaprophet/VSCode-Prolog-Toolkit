import { CancellationToken, ChatRequest, ChatResponseStream } from 'vscode';
import { ChatCommand, ChatCommandContext } from './types';
export declare class N3LoadCommand implements ChatCommand {
    name: string;
    description: string;
    arguments: {
        name: string;
        type: string;
        description: string;
        example: string;
        required: boolean;
    }[];
    canHandle(command: string): command is "n3_load" | "/n3_load";
    handle(args: string, request: ChatRequest, stream: ChatResponseStream, token: CancellationToken, context: ChatCommandContext): Promise<void>;
}
//# sourceMappingURL=n3LoadCommand.d.ts.map