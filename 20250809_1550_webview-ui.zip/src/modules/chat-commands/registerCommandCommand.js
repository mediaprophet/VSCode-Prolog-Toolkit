"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RegisterCommandCommand = void 0;
// Simple dynamic echo command for demonstration
class DynamicEchoCommand {
    name;
    description;
    constructor(name) {
        this.name = name.startsWith('/') ? name : '/' + name;
        this.description = `Dynamic echo command for ${this.name}`;
    }
    canHandle(command) { return command === this.name || command === this.name.replace(/^\//, ''); }
    async handle(args, request, stream) {
        stream.markdown(`[${this.name}] Echo: ${args}`);
    }
}
class RegisterCommandCommand {
    name = '/register_command';
    description = 'Register a new dynamic echo command by name.';
    arguments = [
        {
            name: 'command',
            type: 'string',
            description: 'The name of the new command to register.',
            example: 'my_echo',
            required: true
        }
    ];
    canHandle(command) {
        return command === '/register_command' || command === 'register_command';
    }
    async handle(args, request, stream, token, context) {
        // args: commandName
        const registry = context.registry;
        const name = args.trim();
        if (!name) {
            stream.markdown('Please provide a command name.');
            return;
        }
        if (!registry) {
            stream.markdown('Command registry not available.');
            return;
        }
        registry.registerCommand(new DynamicEchoCommand(name));
        stream.markdown(`Registered new command: **${name}** (echo handler)`);
    }
}
exports.RegisterCommandCommand = RegisterCommandCommand;
//# sourceMappingURL=registerCommandCommand.js.map