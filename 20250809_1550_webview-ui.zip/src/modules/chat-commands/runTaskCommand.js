"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RunTaskCommand = void 0;
const vscode_1 = require("vscode");
class RunTaskCommand {
    name = '/run_task';
    description = 'Run a VS Code task by name or type.';
    arguments = [
        {
            name: 'task',
            type: 'string',
            description: 'The name or type of the VS Code task to run.',
            example: 'build',
            required: true
        }
    ];
    canHandle(command) {
        return command === 'run_task' || command === '/run_task';
    }
    async handle(args, request, stream, token, context) {
        try {
            const allTasks = await vscode_1.tasks.fetchTasks();
            const arg = args.trim();
            let matched = allTasks.find(t => t.name === arg || t.definition.type === arg);
            if (!matched) {
                stream.markdown(`No task found matching: ${arg}`);
                return;
            }
            await vscode_1.tasks.executeTask(matched);
            stream.markdown(`Task **${matched.name}** started.`);
        }
        catch (err) {
            stream.markdown('Failed to run task: ' + err);
        }
    }
}
exports.RunTaskCommand = RunTaskCommand;
//# sourceMappingURL=runTaskCommand.js.map