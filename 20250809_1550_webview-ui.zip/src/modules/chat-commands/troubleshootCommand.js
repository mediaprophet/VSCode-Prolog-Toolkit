"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TroubleshootCommand = void 0;
class TroubleshootCommand {
    name = '/troubleshoot';
    description = 'Run troubleshooting diagnostics and suggestions.';
    arguments = [];
    canHandle(command) {
        return command === 'troubleshoot' || command === '/troubleshoot';
    }
    async handle(args, request, stream, token, context) {
        // Provide actionable suggestions and health checks
        const suggestions = [
            'Restart the Prolog backend if queries are not responding.',
            'Check SWI-Prolog is installed and available in PATH.',
            'Use /logs to view recent extension logs.',
            'Use /debug for diagnostics.',
            'Consult the README for setup instructions.',
        ];
        stream.markdown('**Troubleshooting Suggestions:**\n');
        suggestions.forEach((s, i) => stream.markdown(`${i + 1}. ${s}`));
    }
}
exports.TroubleshootCommand = TroubleshootCommand;
//# sourceMappingURL=troubleshootCommand.js.map