import { CancellationToken, ChatRequest, ChatResponseStream } from 'vscode';
import { ChatCommand, ChatCommandContext } from './types';
export declare class HelpCommand implements ChatCommand {
    name: string;
    description: string;
    arguments: {
        name: string;
        type: string;
        description: string;
        example: string;
        required: boolean;
    }[];
    canHandle(command: string): command is "/help" | "help";
    handle(args: string, request: ChatRequest, stream: ChatResponseStream, token: CancellationToken, context: ChatCommandContext): Promise<void>;
}
//# sourceMappingURL=helpCommand.d.ts.map