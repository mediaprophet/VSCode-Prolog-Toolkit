"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.ErrorsCommand = void 0;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
class ErrorsCommand {
    name = '/errors';
    description = 'Show the most recent problems/errors file from test/logs or logs/.';
    arguments = [];
    canHandle(command) {
        return command === '/errors' || command === 'errors';
    }
    async handle(args, request, stream, token, context) {
        // Look for recent problems files in test/logs or logs/
        const logDirs = [
            path.join(process.cwd(), 'test', 'logs'),
            path.join(process.cwd(), 'logs'),
        ];
        let foundProblems = [];
        for (const dir of logDirs) {
            if (fs.existsSync(dir)) {
                const files = fs.readdirSync(dir).filter(f => f.endsWith('.problems.json'));
                foundProblems = foundProblems.concat(files.map(f => path.join(dir, f)));
            }
        }
        if (foundProblems.length === 0) {
            stream.markdown('No error/problem files found.');
            return;
        }
        // Show the most recent problems file (by mtime)
        const sorted = foundProblems.map(f => ({ f, mtime: fs.statSync(f).mtime })).sort((a, b) => b.mtime.getTime() - a.mtime.getTime());
        if (sorted.length === 0) {
            stream.markdown('No error/problem files found.');
            return;
        }
        const latestProblems = sorted[0];
        if (!latestProblems) {
            stream.markdown('No error/problem files found.');
            return;
        }
        const problemsContent = fs.readFileSync(latestProblems.f, 'utf8');
        stream.markdown(`**Latest Problems File:** ${path.basename(latestProblems.f)}\n`);
        stream.markdown('```json\n' + problemsContent.slice(0, 2000) + '\n```');
    }
}
exports.ErrorsCommand = ErrorsCommand;
//# sourceMappingURL=errorsCommand.js.map