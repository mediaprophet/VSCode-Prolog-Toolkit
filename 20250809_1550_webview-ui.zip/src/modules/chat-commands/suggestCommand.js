"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SuggestCommand = void 0;
class SuggestCommand {
    name = '/suggest';
    description = 'Suggest next steps or commands based on context.';
    arguments = [];
    canHandle(command) {
        return command === 'suggest' || command === '/suggest';
    }
    async handle(args, request, stream, token, context) {
        // Suggest next steps based on last error or context
        let suggestion = 'No suggestions available.';
        if (context.telemetry) {
            const stats = context.telemetry.getStats();
            if (stats && stats.totalCommands > 0) {
                suggestion = 'Try /debug, /logs, or /troubleshoot for more information.';
            }
        }
        stream.markdown('**Next Step Suggestion:** ' + suggestion);
    }
}
exports.SuggestCommand = SuggestCommand;
//# sourceMappingURL=suggestCommand.js.map