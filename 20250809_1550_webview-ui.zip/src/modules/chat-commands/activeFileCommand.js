"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ActiveFileCommand = void 0;
const vscode_1 = require("vscode");
class ActiveFileCommand {
    name = '/active_file';
    description = 'Show or operate on the active file in the editor.';
    arguments = [];
    canHandle(command) {
        return command === '/active_file' || command === 'active_file';
    }
    async handle(args, request, stream, token, context) {
        try {
            const editor = vscode_1.window.activeTextEditor;
            if (!editor) {
                stream.markdown('No active file.');
                return;
            }
            const fileInfo = {
                fileName: editor.document.fileName,
                languageId: editor.document.languageId,
                isDirty: editor.document.isDirty,
                lineCount: editor.document.lineCount,
                selection: editor.selection,
            };
            stream.markdown('**Active File Info:**\n');
            stream.markdown('```json\n' + JSON.stringify(fileInfo, null, 2) + '\n```');
        }
        catch (err) {
            stream.markdown('Failed to fetch active file info: ' + err);
            stream.markdown('Try `/troubleshoot`, `/logs`, or see the [README](https://github.com/mediaprophet/VSCode-Prolog-Toolkit#readme) for help.');
        }
    }
}
exports.ActiveFileCommand = ActiveFileCommand;
//# sourceMappingURL=activeFileCommand.js.map