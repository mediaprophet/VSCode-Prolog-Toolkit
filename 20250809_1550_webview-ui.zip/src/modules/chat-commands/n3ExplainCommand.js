"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.N3ExplainCommand = void 0;
class N3ExplainCommand {
    name = '/n3_explain';
    description = 'Explain N3 reasoning results.';
    arguments = [];
    canHandle(command) {
        return command === '/n3_explain' || command === 'n3_explain';
    }
    async handle(args, request, stream, token, context) {
        stream.markdown('N3 explain command handler (stub)');
    }
}
exports.N3ExplainCommand = N3ExplainCommand;
//# sourceMappingURL=n3ExplainCommand.js.map