"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubscribeCommand = void 0;
// In-memory subscription registry (for demo; production should persist or use event emitter)
const subscribers = new Set();
class SubscribeCommand {
    name = '/subscribe';
    description = 'Subscribe the user/session to backend events (demo only).';
    arguments = [];
    canHandle(command) {
        return command === 'subscribe' || command === '/subscribe';
    }
    async handle(args, request, stream, token, context) {
        // For demo: subscribe user/session to backend events
        // Use sessionId or fallback to 'anonymous'
        const user = request?.sessionId || 'anonymous';
        subscribers.add(user);
        stream.markdown(`Subscribed **${user}** to backend events. (Demo only)`);
    }
}
exports.SubscribeCommand = SubscribeCommand;
//# sourceMappingURL=subscribeCommand.js.map