"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RestartDebugCommand = void 0;
const vscode_1 = require("vscode");
class RestartDebugCommand {
    name = '/restart_debug';
    description = 'Restart the current debug session.';
    arguments = [];
    canHandle(command) {
        return command === 'restart_debug' || command === '/restart_debug';
    }
    async handle(args, request, stream, token, context) {
        try {
            await vscode_1.commands.executeCommand('workbench.action.debug.restart');
            stream.markdown('Debug session restart triggered.');
        }
        catch (err) {
            stream.markdown('Failed to restart debug session: ' + err);
        }
    }
}
exports.RestartDebugCommand = RestartDebugCommand;
//# sourceMappingURL=restartDebugCommand.js.map