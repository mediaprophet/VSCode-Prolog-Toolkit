"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.DescribeCommand = void 0;
const fs = __importStar(require("fs"));
function toRdfJson(triples) {
    // Convert triples to RDF/JSON (https://www.w3.org/TR/rdf-json/)
    const rdf = {};
    for (const { subject, predicate, object } of triples) {
        if (!rdf[subject])
            rdf[subject] = {};
        if (!rdf[subject][predicate])
            rdf[subject][predicate] = [];
        rdf[subject][predicate].push({ value: object, type: 'literal' });
    }
    return rdf;
}
class DescribeCommand {
    name = '/describe';
    description = 'Describe a Prolog or N3 file or snippet, extracting predicates.';
    arguments = [
        {
            name: 'fileOrSnippet',
            type: 'string',
            description: 'The file path or code snippet to describe.',
            example: 'family.pl',
            required: true
        },
        {
            name: 'format',
            type: 'string',
            description: 'Output format: markdown, json, or rdf-json (default: markdown).',
            example: 'json',
            required: false
        }
    ];
    canHandle(command) {
        return command === 'describe' || command === '/describe';
    }
    async handle(args, request, stream, token, context) {
        // Usage: /describe <file> [format=markdown|json|rdf-json]
        const parts = args.trim().split(/\s+/);
        const fileOrSnippet = parts[0];
        const format = (parts[1] || 'markdown').toLowerCase();
        if (!fileOrSnippet) {
            stream.markdown('Usage: /describe <file> [format=markdown|json|rdf-json]');
            return;
        }
        let code = '';
        let filePath = '';
        if (fs.existsSync(fileOrSnippet)) {
            filePath = fileOrSnippet;
            code = fs.readFileSync(fileOrSnippet, 'utf8');
        }
        else {
            code = fileOrSnippet;
        }
        // Simple Prolog/N3 predicate extraction (stub)
        const predicates = Array.from(code.matchAll(/([a-zA-Z0-9_]+)\s*\(/g)).map(m => m[1]);
        const summary = `**Predicates found:** ${predicates.join(', ')}`;
        const triples = predicates.map(p => ({ subject: filePath || 'snippet', predicate: 'hasPredicate', object: String(p) }));
        if (format === 'markdown') {
            stream.markdown(summary);
        }
        else if (format === 'json') {
            stream.markdown('```json\n' + JSON.stringify({ predicates }, null, 2) + '\n```');
        }
        else if (format === 'rdf-json') {
            stream.markdown('```json\n' + JSON.stringify(toRdfJson(triples), null, 2) + '\n```');
        }
        else {
            stream.markdown('Unknown format. Use markdown, json, or rdf-json.');
        }
    }
}
exports.DescribeCommand = DescribeCommand;
//# sourceMappingURL=describeCommand.js.map