import { type ExtensionContext } from 'vscode';
export declare class ExtensionManager {
    private static instance;
    private prologBackend;
    private prologLSPClient;
    private apiServer;
    private externalWebSocketManager;
    private telemetry;
    private chatHandler;
    private installationManager;
    private configurationManager;
    private queryHistoryOrchestrator;
    private constructor();
    static getInstance(): ExtensionManager;
    activate(context: ExtensionContext): Promise<void>;
    private initializeCoreFeatures;
    private registerExtensionCommands;
    private initializeLinter;
    private registerLanguageProviders;
    private initializeTerminalAndSnippets;
    private initializeBackendServices;
    private initializeApiServer;
    private initializeLSPServices;
    private initializeMultiIDESupport;
    private setupBackendEventHandlers;
    private registerProvidersAndUI;
    private getChatFollowups;
    private startBackend;
    private createNewPrologFile;
    private rerunQuery;
    deactivate(): Promise<void>;
}
//# sourceMappingURL=extensionManager.d.ts.map