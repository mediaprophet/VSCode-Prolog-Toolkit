'use strict';
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigurationManager = void 0;
const fs = __importStar(require("fs"));
const vscode_1 = require("vscode");
const platformUtils_1 = require("../utils/platformUtils");
class ConfigurationManager {
    static instance;
    constructor() { }
    static getInstance() {
        if (!ConfigurationManager.instance) {
            ConfigurationManager.instance = new ConfigurationManager();
        }
        return ConfigurationManager.instance;
    }
    // Initialization of workspace for dialect
    async initForDialect(context) {
        // get the user preferences for the extension
        const section = vscode_1.workspace.getConfiguration('prolog');
        const dialect = section.get('dialect');
        // Use platform-aware executable path resolution
        let exec = section.get('executablePath', '');
        if (!exec) {
            exec = (0, platformUtils_1.getPlatformDefaults)().defaultExecutablePath;
        }
        exec = platformUtils_1.PlatformUtils.normalizePath(exec);
        // TODO: Refactor to use PrologExecUtils and modular config
        // Use platform-aware path construction
        const exPath = platformUtils_1.PlatformUtils.normalizePath(context.extensionPath);
        // check if the dialect links have already been done
        const diaFile = platformUtils_1.PlatformUtils.joinPath(exPath, '.vscode', 'dialect.json');
        let lastDialect = '';
        try {
            if (await platformUtils_1.PlatformUtils.pathExists(diaFile)) {
                const dialectContent = fs.readFileSync(diaFile, 'utf8');
                lastDialect = JSON.parse(dialectContent).dialect;
            }
        }
        catch (error) {
            // File doesn't exist or is invalid, continue with setup
            const errorMsg = error instanceof Error ? error.message : String(error);
            console.log('[Platform] Dialect file not found or invalid, proceeding with setup:', errorMsg);
        }
        if (lastDialect === dialect) {
            return;
        }
        // creating links for the right dialect using platform-aware paths
        const symLinks = [
            {
                path: platformUtils_1.PlatformUtils.joinPath(exPath, 'syntaxes'),
                srcFile: `prolog.${dialect}.tmLanguage.json`,
                targetFile: 'prolog.tmLanguage.json',
            },
            {
                path: platformUtils_1.PlatformUtils.joinPath(exPath, 'snippets'),
                srcFile: `prolog.${dialect}.json`,
                targetFile: 'prolog.json',
            },
        ];
        await Promise.all(symLinks.map(async (link) => {
            const srcPath = platformUtils_1.PlatformUtils.joinPath(link.path, link.srcFile);
            const targetPath = platformUtils_1.PlatformUtils.joinPath(link.path, link.targetFile);
            // remove old link
            try {
                if (await platformUtils_1.PlatformUtils.pathExists(targetPath)) {
                    fs.unlinkSync(targetPath);
                }
            }
            catch (error) {
                // Ignore errors when removing non-existent files, but log for debugging
                const errorMsg = error instanceof Error ? error.message : String(error);
                console.debug('[Platform] Failed to remove old symlink:', targetPath, errorMsg);
            }
            // make link
            try {
                // Try to create symlink, fallback to copy if symlink fails
                try {
                    fs.symlinkSync(srcPath, targetPath);
                }
                catch (error) {
                    // If symlink fails (e.g., on Windows without admin), copy the file
                    const errorMsg = error instanceof Error ? error.message : String(error);
                    console.debug('[Platform] Symlink failed, falling back to copy:', errorMsg);
                    fs.copyFileSync(srcPath, targetPath);
                }
            }
            catch (err) {
                const platform = (0, platformUtils_1.getPlatform)();
                const errorMsg = platform === 'windows'
                    ? 'VSC-Prolog failed in initialization. Try running VS Code as administrator or enable Developer Mode in Windows Settings.'
                    : 'VSC-Prolog failed in initialization. Check file permissions.';
                console.error('[Extension] Initialization failed:', err);
                throw new Error(errorMsg);
            }
        }));
        // Ensure .vscode directory exists
        const vscodeDirPath = platformUtils_1.PlatformUtils.joinPath(exPath, '.vscode');
        if (!(await platformUtils_1.PlatformUtils.pathExists(vscodeDirPath))) {
            fs.mkdirSync(vscodeDirPath, { recursive: true });
        }
        // write the dialect to the json for later initialization
        fs.writeFileSync(diaFile, JSON.stringify({ dialect: dialect }));
    }
    // Helper function to create auth configuration from VSCode settings
    createAuthConfig(config) {
        const method = config.get('apiServer.auth.method', 'api_key');
        // Ensure method is one of the valid values
        const validMethods = ['api_key', 'jwt_token', 'local_only', 'oauth2'];
        const authMethod = validMethods.includes(method)
            ? method
            : 'api_key';
        return {
            method: authMethod,
            apiKeys: config.get('apiServer.auth.apiKeys', []),
            jwtSecret: config.get('apiServer.auth.jwtSecret', ''),
            localOnly: config.get('apiServer.auth.localOnly', true),
            oauth2: {
                providers: config.get('apiServer.auth.oauth2.providers', ['google', 'github']),
                clientId: config.get('apiServer.auth.oauth2.clientId', ''),
                clientSecret: config.get('apiServer.auth.oauth2.clientSecret', ''),
                redirectUri: config.get('apiServer.auth.oauth2.redirectUri', ''),
                scope: config.get('apiServer.auth.oauth2.scope', 'read'),
            },
            roles: {
                admin: config.get('apiServer.auth.roles.admin', []),
                agent: config.get('apiServer.auth.roles.agent', []),
                readonly: config.get('apiServer.auth.roles.readonly', []),
                limited: config.get('apiServer.auth.roles.limited', []),
            },
            quotas: {
                admin: {
                    requestsPerMinute: config.get('apiServer.auth.quotas.admin.requestsPerMinute', 1000),
                    maxConcurrentSessions: config.get('apiServer.auth.quotas.admin.maxConcurrentSessions', 50),
                },
                agent: {
                    requestsPerMinute: config.get('apiServer.auth.quotas.agent.requestsPerMinute', 300),
                    maxConcurrentSessions: config.get('apiServer.auth.quotas.agent.maxConcurrentSessions', 20),
                },
                readonly: {
                    requestsPerMinute: config.get('apiServer.auth.quotas.readonly.requestsPerMinute', 100),
                    maxConcurrentSessions: config.get('apiServer.auth.quotas.readonly.maxConcurrentSessions', 10),
                },
                limited: {
                    requestsPerMinute: config.get('apiServer.auth.quotas.limited.requestsPerMinute', 30),
                    maxConcurrentSessions: config.get('apiServer.auth.quotas.limited.maxConcurrentSessions', 5),
                },
            },
        };
    }
    // Get current configuration values
    getConfiguration() {
        const config = vscode_1.workspace.getConfiguration('prolog');
        return {
            dialect: config.get('dialect', 'swi'),
            executablePath: config.get('executablePath', 'swipl'),
            linterTrigger: config.get('linter.run', 'never'),
            formatEnabled: config.get('format.enabled', false),
            apiServerEnabled: config.get('apiServer.enabled', false),
            webSocketEnabled: config.get('webSocketServer.enabled', true),
            telemetryEnabled: config.get('telemetry.enabled', false),
        };
    }
}
exports.ConfigurationManager = ConfigurationManager;
//# sourceMappingURL=configurationManager.js.map