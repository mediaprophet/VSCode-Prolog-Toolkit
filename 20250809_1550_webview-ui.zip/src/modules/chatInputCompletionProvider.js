"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatInputCompletionProvider = void 0;
const vscode_1 = require("vscode");
/**
 * Provides inline completions for the chat input box, suggesting commands and argument hints.
 */
class ChatInputCompletionProvider {
    registry;
    constructor(registry) {
        this.registry = registry;
    }
    async provideInlineCompletionItems(document, position, context, token) {
        const line = document.lineAt(position.line).text.substring(0, position.character);
        const completions = [];
        // Suggest commands when user types '/'
        if (/^\s*\/?\w*$/.test(line)) {
            for (const cmd of this.registry.getAllCommands()) {
                completions.push(new vscode_1.InlineCompletionItem(cmd.name + ' ', new vscode_1.Range(position.line, 0, position.line, position.character)));
            }
            return completions;
        }
        // Suggest argument hints if a command is detected
        const match = line.match(/^(\/\w+)(\s+)(.*)$/);
        if (match && match[1]) {
            const command = match[1];
            const handler = this.registry.findHandler(command);
            if (handler && handler.arguments && handler.arguments.length > 0) {
                const argString = match[3] || '';
                const providedArgs = argString.trim().length > 0 ? argString.trim().split(/\s+/).filter(Boolean) : [];
                if (providedArgs.length < handler.arguments.length) {
                    const nextArg = handler.arguments[providedArgs.length];
                    if (nextArg) {
                        completions.push(new vscode_1.InlineCompletionItem((providedArgs.length > 0 ? ' ' : '') + `<${nextArg.name}> `, new vscode_1.Range(position.line, position.character, position.line, position.character)));
                    }
                }
            }
        }
        return completions;
    }
}
exports.ChatInputCompletionProvider = ChatInputCompletionProvider;
//# sourceMappingURL=chatInputCompletionProvider.js.map