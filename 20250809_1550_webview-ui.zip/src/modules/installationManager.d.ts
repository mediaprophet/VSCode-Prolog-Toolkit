import { ExtensionContext } from 'vscode';
export declare class InstallationManager {
    private static instance;
    private installationChecker;
    private installationGuide;
    private configurationMigration;
    private constructor();
    static getInstance(): InstallationManager;
    checkAndHandleInstallation(context: ExtensionContext): Promise<void>;
    private showInstallationInstructions;
    registerInstallationCommands(context: ExtensionContext): void;
}
//# sourceMappingURL=installationManager.d.ts.map