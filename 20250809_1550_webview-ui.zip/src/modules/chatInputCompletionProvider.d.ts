import { CancellationToken, InlineCompletionContext, InlineCompletionItem, InlineCompletionItemProvider, Position, TextDocument } from 'vscode';
import { ChatCommandRegistry } from './chatCommandRegistry';
/**
 * Provides inline completions for the chat input box, suggesting commands and argument hints.
 */
export declare class ChatInputCompletionProvider implements InlineCompletionItemProvider {
    private registry;
    constructor(registry: ChatCommandRegistry);
    provideInlineCompletionItems(document: TextDocument, position: Position, context: InlineCompletionContext, token: CancellationToken): Promise<InlineCompletionItem[]>;
}
//# sourceMappingURL=chatInputCompletionProvider.d.ts.map