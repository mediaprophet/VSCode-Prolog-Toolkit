"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatCommandRegistry = void 0;
const activeFileCommand_1 = require("./chat-commands/activeFileCommand");
const consultCommand_1 = require("./chat-commands/consultCommand");
const debugCommand_1 = require("./chat-commands/debugCommand");
const describeCommand_1 = require("./chat-commands/describeCommand");
const envCommand_1 = require("./chat-commands/envCommand");
const errorsCommand_1 = require("./chat-commands/errorsCommand");
const feedbackCommand_1 = require("./chat-commands/feedbackCommand");
const helpCommand_1 = require("./chat-commands/helpCommand");
const installCommand_1 = require("./chat-commands/installCommand");
const listCommandsCommand_1 = require("./chat-commands/listCommandsCommand");
const listFilesCommand_1 = require("./chat-commands/listFilesCommand");
const logsCommand_1 = require("./chat-commands/logsCommand");
const n3ExplainCommand_1 = require("./chat-commands/n3ExplainCommand");
const n3ListCommand_1 = require("./chat-commands/n3ListCommand");
const n3LoadCommand_1 = require("./chat-commands/n3LoadCommand");
const n3ReasonCommand_1 = require("./chat-commands/n3ReasonCommand");
const openSettingsCommand_1 = require("./chat-commands/openSettingsCommand");
const problemsCommand_1 = require("./chat-commands/problemsCommand");
const progressCommand_1 = require("./chat-commands/progressCommand");
const queryCommand_1 = require("./chat-commands/queryCommand");
const registerCommandCommand_1 = require("./chat-commands/registerCommandCommand");
const reloadBackendCommand_1 = require("./chat-commands/reloadBackendCommand");
const restartDebugCommand_1 = require("./chat-commands/restartDebugCommand");
const runTaskCommand_1 = require("./chat-commands/runTaskCommand");
const statusCommand_1 = require("./chat-commands/statusCommand");
const subscribeCommand_1 = require("./chat-commands/subscribeCommand");
const suggestCommand_1 = require("./chat-commands/suggestCommand");
const telemetryStatsCommand_1 = require("./chat-commands/telemetryStatsCommand");
const troubleshootCommand_1 = require("./chat-commands/troubleshootCommand");
const unregisterCommandCommand_1 = require("./chat-commands/unregisterCommandCommand");
class ChatCommandRegistry {
    commands;
    constructor() {
        this.commands = [];
        this.registerAllCommands();
        // Register the list-commands command with access to this registry (only once, after all others)
        this.commands.push(new listCommandsCommand_1.ListCommandsCommand(this));
    }
    /**
     * Helper to register all built-in commands in a single place for maintainability.
     */
    registerAllCommands() {
        this.commands.push(new queryCommand_1.QueryCommand(), new consultCommand_1.ConsultCommand(), new helpCommand_1.HelpCommand(), new statusCommand_1.StatusCommand(), new n3LoadCommand_1.N3LoadCommand(), new n3ListCommand_1.N3ListCommand(), new n3ReasonCommand_1.N3ReasonCommand(), new n3ExplainCommand_1.N3ExplainCommand(), new envCommand_1.EnvCommand(), new listFilesCommand_1.ListFilesCommand(), new activeFileCommand_1.ActiveFileCommand(), new debugCommand_1.DebugCommand(), new troubleshootCommand_1.TroubleshootCommand(), new logsCommand_1.LogsCommand(), new errorsCommand_1.ErrorsCommand(), new runTaskCommand_1.RunTaskCommand(), new installCommand_1.InstallCommand(), new reloadBackendCommand_1.ReloadBackendCommand(), new restartDebugCommand_1.RestartDebugCommand(), new openSettingsCommand_1.OpenSettingsCommand(), new feedbackCommand_1.FeedbackCommand(), new telemetryStatsCommand_1.TelemetryStatsCommand(), new suggestCommand_1.SuggestCommand(), new progressCommand_1.ProgressCommand(), new subscribeCommand_1.SubscribeCommand(), new registerCommandCommand_1.RegisterCommandCommand(), new unregisterCommandCommand_1.UnregisterCommandCommand(), new describeCommand_1.DescribeCommand(), new problemsCommand_1.ProblemsCommand());
    }
    /**
     * Returns all registered chat commands.
     */
    getAllCommands() {
        return this.commands;
    }
    findHandler(command) {
        return this.commands.find(cmd => cmd.canHandle(command));
    }
    registerCommand(cmd) {
        this.commands.push(cmd);
    }
    unregisterCommand(commandName) {
        this.commands = this.commands.filter(cmd => !cmd.canHandle(commandName));
    }
}
exports.ChatCommandRegistry = ChatCommandRegistry;
//# sourceMappingURL=chatCommandRegistry.js.map