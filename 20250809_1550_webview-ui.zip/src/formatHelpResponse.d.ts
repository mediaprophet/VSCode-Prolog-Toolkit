import { ChatResponseStream } from 'vscode';
export declare function formatHelpResponse(doc: any, stream: ChatResponseStream): void;
//# sourceMappingURL=formatHelpResponse.d.ts.map