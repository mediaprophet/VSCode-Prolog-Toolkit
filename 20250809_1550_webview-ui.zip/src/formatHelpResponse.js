"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatHelpResponse = formatHelpResponse;
// Format help response
function formatHelpResponse(doc, stream) {
    stream.markdown(`# ${doc.name}/${doc.arity}\n\n`);
    // Status badges
    const badges = [];
    if (doc.is_builtin)
        badges.push('**Built-in**');
    if (doc.module && doc.module !== 'user')
        badges.push(`**Module**: \`${doc.module}\``);
    if (doc.deterministic)
        badges.push('**Deterministic**');
    if (badges.length > 0) {
        stream.markdown(`${badges.join(' | ')}\n\n`);
    }
    if (doc.summary) {
        stream.markdown(`## Description\n\n${doc.summary}\n\n`);
    }
    if (doc.args && doc.args.length > 0) {
        stream.markdown('## Arguments\n\n');
        doc.args.forEach((arg, index) => {
            stream.markdown(`**${index + 1}. ${arg.name}** - ${arg.description}\n\n`);
        });
    }
    if (doc.examples && doc.examples.length > 0) {
        stream.markdown('## Examples\n\n');
        doc.examples.forEach((example, index) => {
            stream.markdown(`**Example ${index + 1}:**\n\`\`\`prolog\n${example}\n\`\`\`\n\n`);
        });
    }
    if (doc.see_also && doc.see_also.length > 0) {
        stream.markdown('## See Also\n\n');
        doc.see_also.forEach((related) => {
            stream.markdown(`- \`${related}\`\n`);
        });
        stream.markdown('\n');
    }
}
//# sourceMappingURL=formatHelpResponse.js.map