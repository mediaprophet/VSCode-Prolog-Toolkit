import { EventEmitter } from 'events';
import { QueryCallback, QueryNotificationManager, QueryNotificationOptions } from './features/queryNotificationManager';
import { UIHandler } from './features/uiHandler';
import { QueryHistoryOptions, QueryPriority, ResourceQuota, SessionManagerOptions } from './types/backend';
export interface PrologBackendOptions {
    swiplPath?: string;
    args?: string[];
    cwd?: string;
    port?: number;
    maxResultsPerChunk?: number;
    streamingEnabled?: boolean;
    notificationOptions?: QueryNotificationOptions;
    concurrencyOptions?: {
        resourceQuota?: Partial<ResourceQuota>;
        enabled?: boolean;
    };
    historyOptions?: Partial<QueryHistoryOptions>;
    schedulerOptions?: {
        enabled?: boolean;
        maxScheduledQueries?: number;
        checkInterval?: number;
        enableRecurring?: boolean;
        enableConditional?: boolean;
        enableDependencies?: boolean;
    };
    sessionOptions?: Partial<SessionManagerOptions>;
    uiHandler?: UIHandler;
}
export declare class PrologBackend extends EventEmitter {
    private process;
    private options;
    private isReady;
    private pendingRequests;
    private intentionalStop;
    private _suppressStoppedEvent;
    private port;
    private maxResultsPerChunk;
    private streamingEnabled;
    private notificationManager;
    private concurrencyManager;
    private historyManager;
    private queryScheduler;
    private sessionManager;
    private runningQueries;
    private uiHandler;
    private log;
    constructor(options?: PrologBackendOptions);
    /**
     * Set up event handlers for all managers
     */
    private setupEventHandlers;
    /**
     * Handle query execution from concurrency manager
     */
    private handleConcurrencyManagerExecution;
    isRunning(): boolean;
    stop(intentional?: boolean): void;
    restart(): void;
    /**
     * Handle query cancellation
     */
    private handleQueryCancellation;
    sendRequest(cmdOrBatch: string | Array<{
        cmd: string;
        params?: Record<string, any>;
        timeoutMs?: number;
    }>, params?: Record<string, any>): Promise<any>;
    /**
     * Send request with notification support
     */
    sendRequestWithNotifications(cmdOrBatch: string | Array<{
        cmd: string;
        params?: Record<string, any>;
        timeoutMs?: number;
    }>, params?: Record<string, any>, callback?: QueryCallback): Promise<any>;
    /**
     * Send a streaming request that can handle large result sets
     */
    sendStreamingRequest(cmd: string, params?: Record<string, any>, onChunk?: (chunk: any, isFirst: boolean, isLast: boolean) => void): Promise<any>;
    /**
     * Get streaming configuration
     */
    getStreamingConfig(): {
        enabled: boolean;
        maxResultsPerChunk: number;
    };
    /**
     * Update streaming configuration
     */
    updateStreamingConfig(config: {
        enabled?: boolean;
        maxResultsPerChunk?: number;
    }): void;
    /**
     * Get notification manager for direct access
     */
    getNotificationManager(): QueryNotificationManager;
    /**
     * Cancel a running query
     */
    cancelQuery(queryId: string): boolean;
    /**
     * Get query status
     */
    getQueryStatus(queryId: string): import("./features/queryNotificationManager").QueryStatus;
    /**
     * Get all active queries
     */
    getActiveQueries(): import("./features/queryNotificationManager").QueryStatus[];
    /**
     * Get query statistics
     */
    getQueryStatistics(): {
        total: number;
        pending: number;
        running: number;
        completed: number;
        error: number;
        cancelled: number;
        timeout: number;
    };
    /**
     * Execute a query directly (used internally by concurrency manager)
     */
    /**
     * Execute a query and record source, resource usage, and artifacts in history metadata.
     * @param cmd Prolog command
     * @param params Query parameters
     * @param options { source?: 'ui'|'api'|'automation', artifacts?: Array<{name:string,path:string,type?:string}> }
     */
    private executeQueryDirect;
    /**
     * Execute a query and record source, resource usage, and artifacts in history metadata.
     * @param cmd Prolog command
     * @param params Query parameters
     * @param options { source?: 'ui'|'api'|'automation', artifacts?: Array<{name:string,path:string,type?:string}> }
     */
    /**
     * Send request with advanced concurrency control
     */
    sendRequestWithConcurrency(cmd: string, params?: Record<string, any>, priority?: Partial<QueryPriority>, resourceRequirements?: {
        memoryMB?: number;
        cpuPercent?: number;
    }): Promise<any>;
    /**
     * Schedule a query for future execution
     */
    scheduleQuery(cmd: string, params?: Record<string, any>, scheduleType?: 'immediate' | 'delayed' | 'recurring' | 'conditional', scheduleConfig?: any, priority?: Partial<QueryPriority>, metadata?: any): Promise<string>;
    /**
     * Cancel a scheduled query
     */
    cancelScheduledQuery(queryId: string): Promise<boolean>;
    /**
     * Get scheduled queries
     */
    getScheduledQueries(filter?: any): any[];
    /**
     * Get query history
     */
    getQueryHistory(filter?: any): Promise<any>;
    /**
     * Get query history statistics
     */
    getQueryHistoryStatistics(): Promise<any>;
    /**
     * Get concurrency manager status
     */
    getConcurrencyStatus(): any;
    /**
     * Get scheduler statistics
     */
    getSchedulerStatistics(): any;
    /**
     * Update resource quota
     */
    updateResourceQuota(newQuota: Partial<ResourceQuota>): void;
    /**
     * Pause a recurring query
     */
    pauseRecurringQuery(queryId: string): Promise<boolean>;
    /**
     * Resume a paused recurring query
     */
    resumeRecurringQuery(queryId: string): Promise<boolean>;
    /**
     * Register a custom condition evaluator for conditional queries
     */
    registerConditionEvaluator(queryId: string, evaluator: () => boolean): void;
    /**
     * Clear query history
     */
    clearQueryHistory(): Promise<void>;
    /**
     * Get a specific query from history
     */
    getQueryFromHistory(queryId: string): Promise<any>;
    /**
     * Delete a query from history
     */
    deleteQueryFromHistory(queryId: string): Promise<boolean>;
    /**
     * Create a new session
     */
    createSession(name: string, options?: {
        description?: string;
        userId?: string;
        agentId?: string;
        resourceQuota?: Partial<ResourceQuota>;
        persistenceEnabled?: boolean;
        autoSave?: boolean;
        metadata?: Record<string, any>;
    }): Promise<string>;
    /**
     * Switch to a different session
     */
    switchToSession(sessionId: string): Promise<void>;
    /**
     * Get current active session
     */
    getCurrentSession(): {
        sessionId: string;
        config: any;
        state: any;
    } | null;
    /**
     * Get session by ID
     */
    getSession(sessionId: string): {
        config: any;
        state: any;
    } | null;
    /**
     * List all sessions
     */
    listSessions(filter?: {
        userId?: string;
        agentId?: string;
        isActive?: boolean;
        includeInactive?: boolean;
    }): Array<{
        sessionId: string;
        config: any;
    }>;
    /**
     * Delete a session
     */
    deleteSession(sessionId: string): Promise<boolean>;
    /**
     * Save current session state
     */
    saveCurrentSessionState(): Promise<void>;
    /**
     * Save session state
     */
    saveSessionState(sessionId: string, state?: any): Promise<void>;
    /**
     * Restore session state
     */
    restoreSessionState(sessionId: string, snapshotId?: string): Promise<void>;
    /**
     * Create a snapshot of session state
     */
    createSessionSnapshot(sessionId: string, name: string, description?: string): Promise<string>;
    /**
     * Get session-specific concurrency manager
     */
    /**
     * Get session-specific history manager
     */
    /**
     * Update session resource quota
     */
    updateSessionResourceQuota(sessionId: string, quota: Partial<ResourceQuota>): Promise<void>;
    /**
     * Get session statistics
     */
    getSessionStatistics(sessionId: string): Promise<any>;
    /**
     * Export session state to file
     */
    exportSessionState(sessionId: string, filePath: string): Promise<void>;
    /**
     * Import session state from file
     */
    importSessionState(sessionId: string, filePath: string): Promise<void>;
    /**
     * Get session manager for direct access
     */
    private handleExit;
    start(): Promise<void>;
}
//# sourceMappingURL=prologBackend.d.ts.map