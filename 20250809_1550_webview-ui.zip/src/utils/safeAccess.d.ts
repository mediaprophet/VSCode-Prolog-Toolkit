/**
 * Safe access utilities for handling null/undefined values in strict mode
 */
/**
 * Safely access a property that might be undefined
 */
export declare function safeGet<T, K extends keyof T>(obj: T | null | undefined, key: K): T[K] | undefined;
/**
 * Safely access a nested property
 */
export declare function safeGetNested<T>(obj: any, path: string): T | undefined;
/**
 * Provide a default value if the input is null or undefined
 */
export declare function withDefault<T>(value: T | null | undefined, defaultValue: T): T;
/**
 * Check if a value is not null or undefined
 */
export declare function isNotNullish<T>(value: T | null | undefined): value is T;
/**
 * Filter out null and undefined values from an array
 */
export declare function filterNullish<T>(array: (T | null | undefined)[]): T[];
/**
 * Safely access array element
 */
export declare function safeArrayAccess<T>(array: T[] | null | undefined, index: number): T | undefined;
/**
 * Safely call a function if it exists
 */
export declare function safeCall<T extends (...args: any[]) => any>(fn: T | null | undefined, ...args: Parameters<T>): ReturnType<T> | undefined;
/**
 * Create a safe property accessor
 */
export declare function createSafeAccessor<T extends Record<string, any>>(obj: T | null | undefined): {
    get<K extends keyof T>(key: K): T[K] | undefined;
    has<K extends keyof T>(key: K): boolean;
    keys(): (keyof T)[];
};
/**
 * Safely parse JSON with error handling
 */
export declare function safeJsonParse<T = any>(json: string | null | undefined): T | undefined;
/**
 * Safely convert to string
 */
export declare function safeToString(value: any): string;
/**
 * Safely convert to number
 */
export declare function safeToNumber(value: any): number | undefined;
/**
 * Safely convert to boolean
 */
export declare function safeToBoolean(value: any): boolean;
//# sourceMappingURL=safeAccess.d.ts.map