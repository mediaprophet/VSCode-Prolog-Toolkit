export declare class PrologExecUtils {
    static DIALECT: string | null;
    static RUNTIMEPATH: string | null;
    static execPrologSync(args: string[], clause: string, call: string, inputTerm: string, resultReg: RegExp): string[] | null;
}
//# sourceMappingURL=prologExecUtils.d.ts.map