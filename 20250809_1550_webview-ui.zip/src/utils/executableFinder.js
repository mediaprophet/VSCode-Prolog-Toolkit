"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExecutableFinder = void 0;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const os = __importStar(require("os"));
const child_process_1 = require("child_process");
const which_1 = __importDefault(require("which"));
const platformUtils_1 = require("./platformUtils");
/**
 * Comprehensive executable finder with platform-specific detection strategies
 */
class ExecutableFinder {
    platform;
    strategies = [];
    constructor() {
        this.platform = platformUtils_1.PlatformUtils.getPlatform();
        this.initializeStrategies();
    }
    /**
     * Initialize platform-specific detection strategies
     */
    initializeStrategies() {
        switch (this.platform) {
            case 'windows': {
                this.strategies = [
                    new WindowsPathStrategy(),
                    new WindowsProgramFilesStrategy(),
                    new WindowsRegistryStrategy(),
                    new WindowsEnvironmentStrategy(),
                ];
                break;
            }
            case 'macos': {
                this.strategies = [
                    new MacOSWhichStrategy(),
                    new MacOSHomebrewStrategy(),
                    new MacOSApplicationsStrategy(),
                    new MacOSMacPortsStrategy(),
                    new MacOSStandardPathsStrategy(),
                ];
                break;
            }
            case 'linux': {
                this.strategies = [
                    new LinuxWhichStrategy(),
                    new LinuxWhereisStrategy(),
                    new LinuxStandardPathsStrategy(),
                    new LinuxPackageManagerStrategy(),
                    new LinuxSnapFlatpakStrategy(),
                    new LinuxUserLocalStrategy(),
                ];
                break;
            }
        }
        // Sort strategies by priority (higher priority first)
        this.strategies.sort((a, b) => b.priority - a.priority);
    }
    /**
     * Find SWI-Prolog executable using all available strategies
     */
    async findSwiplExecutable() {
        const issues = [];
        for (const strategy of this.strategies) {
            try {
                const foundPath = await strategy.detect();
                if (foundPath) {
                    const validation = await this.validateExecutable(foundPath);
                    if (validation.found) {
                        return {
                            ...validation,
                            detectionMethod: strategy.name,
                        };
                    }
                    else {
                        issues.push(`Found potential executable at '${foundPath}' via ${strategy.name}, but validation failed: ${validation.issues?.join(', ')}`);
                    }
                }
            }
            catch (error) {
                issues.push(`Strategy '${strategy.name}' failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
            }
        }
        return {
            found: false,
            issues: issues.length > 0
                ? issues
                : ['No SWI-Prolog executable found using any detection strategy'],
        };
    }
    /**
     * Validate an executable path and get detailed information
     */
    async validateExecutable(execPath) {
        if (!execPath) {
            return {
                found: false,
                issues: ['Empty executable path provided'],
            };
        }
        const normalizedPath = platformUtils_1.PlatformUtils.normalizePath(execPath);
        const issues = [];
        try {
            // Check if file exists
            const stats = await fs.promises.stat(normalizedPath);
            if (!stats.isFile()) {
                return {
                    found: false,
                    path: normalizedPath,
                    issues: ['Path exists but is not a file'],
                };
            }
            // Check permissions
            const permissions = await this.checkPermissions(normalizedPath);
            if (!permissions.executable) {
                issues.push('File is not executable');
            }
            // Try to execute and get version
            const versionResult = await this.getExecutableVersion(normalizedPath);
            if (!versionResult.success) {
                issues.push(`Failed to execute: ${versionResult.error}`);
                return {
                    found: false,
                    path: normalizedPath,
                    permissions,
                    issues,
                };
            }
            // Validate that it's actually SWI-Prolog
            if (!this.isSwiplOutput(versionResult.output)) {
                issues.push('Executable does not appear to be SWI-Prolog');
                return {
                    found: false,
                    path: normalizedPath,
                    permissions,
                    issues,
                };
            }
            return {
                found: true,
                path: normalizedPath,
                version: this.extractVersion(versionResult.output),
                permissions,
                issues: issues.length > 0 ? issues : undefined,
            };
        }
        catch (error) {
            return {
                found: false,
                path: normalizedPath,
                issues: [`File system error: ${error instanceof Error ? error.message : 'Unknown error'}`],
            };
        }
    }
    /**
     * Check file permissions (Unix-style and Windows)
     */
    async checkPermissions(filePath) {
        const permissions = {
            readable: false,
            writable: false,
            executable: false,
        };
        try {
            // Check readable
            await fs.promises.access(filePath, fs.constants.R_OK);
            permissions.readable = true;
        }
        catch {
            // Not readable
        }
        try {
            // Check writable
            await fs.promises.access(filePath, fs.constants.W_OK);
            permissions.writable = true;
        }
        catch {
            // Not writable (this is normal for system executables)
        }
        try {
            // Check executable
            await fs.promises.access(filePath, fs.constants.X_OK);
            permissions.executable = true;
        }
        catch {
            // Not executable - this is a problem for executables
        }
        return permissions;
    }
    /**
     * Execute the binary to get version information
     */
    async getExecutableVersion(execPath) {
        return new Promise(resolve => {
            const process = (0, child_process_1.spawn)(execPath, ['--version'], {
                stdio: ['ignore', 'pipe', 'pipe'],
                timeout: 10000,
            });
            let stdout = '';
            let stderr = '';
            process.stdout?.on('data', data => {
                stdout += data.toString();
            });
            process.stderr?.on('data', data => {
                stderr += data.toString();
            });
            process.on('close', code => {
                if (code === 0) {
                    resolve({ success: true, output: stdout });
                }
                else {
                    resolve({ success: false, error: `Process exited with code ${code}. stderr: ${stderr}` });
                }
            });
            process.on('error', error => {
                resolve({ success: false, error: error.message });
            });
            // Timeout fallback
            setTimeout(() => {
                process.kill();
                resolve({ success: false, error: 'Process timed out after 10 seconds' });
            }, 10000);
        });
    }
    /**
     * Check if output is from SWI-Prolog
     */
    isSwiplOutput(output) {
        return /SWI-Prolog/i.test(output);
    }
    /**
     * Extract version number from SWI-Prolog output
     */
    extractVersion(output) {
        const versionMatch = output.match(/SWI-Prolog version (\d+\.\d+\.\d+)/i);
        if (versionMatch) {
            return versionMatch[1];
        }
        // Fallback: try to extract any version-like pattern
        const fallbackMatch = output.match(/(\d+\.\d+\.\d+)/);
        return fallbackMatch ? fallbackMatch[1] : 'Unknown';
    }
    /**
     * Get platform-specific installation suggestions
     */
    async getInstallationSuggestions() {
        // Import here to avoid circular dependencies
        const { PackageManagerIntegration } = await Promise.resolve().then(() => __importStar(require('../features/packageManagerIntegration')));
        const packageManager = PackageManagerIntegration.getInstance();
        try {
            return await packageManager.getInstallationSuggestions();
        }
        catch (error) {
            // Fallback to basic suggestions if package manager integration fails
            const errorMsg = error instanceof Error ? error.message : String(error);
            console.warn('[ExecutableFinder] Package manager integration failed, using fallback suggestions:', errorMsg);
            const suggestions = [];
            suggestions.push(`Install SWI-Prolog from https://www.swi-prolog.org/download/stable`);
            switch (this.platform) {
                case 'windows': {
                    suggestions.push('Windows installation options:');
                    suggestions.push('  • Download and run the .exe installer from the official website');
                    suggestions.push('  • Use Chocolatey: choco install swi-prolog');
                    suggestions.push('  • Use Winget: winget install SWI.SWI-Prolog');
                    suggestions.push('  • Use Scoop: scoop install swi-prolog');
                    break;
                }
                case 'macos': {
                    suggestions.push('macOS installation options:');
                    suggestions.push('  • Use Homebrew: brew install swi-prolog');
                    suggestions.push('  • Use MacPorts: sudo port install swi-prolog');
                    suggestions.push('  • Download and install the .dmg file from the official website');
                    break;
                }
                case 'linux': {
                    suggestions.push('Linux installation options:');
                    suggestions.push('  • Ubuntu/Debian: sudo apt install swi-prolog');
                    suggestions.push('  • CentOS/RHEL: sudo yum install pl');
                    suggestions.push('  • Fedora: sudo dnf install pl');
                    suggestions.push('  • Arch Linux: sudo pacman -S swi-prolog');
                    suggestions.push('  • openSUSE: sudo zypper install swi-prolog');
                    suggestions.push('  • Snap: sudo snap install swi-prolog');
                    suggestions.push('  • Flatpak: flatpak install org.swi_prolog.SWI-Prolog');
                    break;
                }
            }
            return suggestions;
        }
    }
}
exports.ExecutableFinder = ExecutableFinder;
// Windows-specific detection strategies
class WindowsPathStrategy {
    name = 'Windows PATH Environment';
    priority = 100;
    async detect() {
        try {
            const result = await (0, which_1.default)('swipl.exe');
            return result || null;
        }
        catch {
            try {
                const result = await (0, which_1.default)('swipl');
                return result || null;
            }
            catch {
                return null;
            }
        }
    }
}
class WindowsProgramFilesStrategy {
    name = 'Windows Program Files';
    priority = 90;
    async detect() {
        const paths = [
            'C:\\Program Files\\swipl\\bin\\swipl.exe',
            'C:\\Program Files (x86)\\swipl\\bin\\swipl.exe',
            'C:\\swipl\\bin\\swipl.exe',
        ];
        if (process.env.ProgramFiles) {
            paths.push(path.join(process.env.ProgramFiles, 'swipl', 'bin', 'swipl.exe'));
        }
        if (process.env['ProgramFiles(x86)']) {
            paths.push(path.join(process.env['ProgramFiles(x86)'], 'swipl', 'bin', 'swipl.exe'));
        }
        for (const execPath of paths) {
            try {
                await fs.promises.access(execPath, fs.constants.F_OK);
                return execPath;
            }
            catch {
                continue;
            }
        }
        return null;
    }
}
class WindowsRegistryStrategy {
    name = 'Windows Registry';
    priority = 80;
    async detect() {
        // Note: This is a simplified registry check
        // In a full implementation, you might use a Windows registry library
        // For now, we'll check common registry-based installation paths
        const registryPaths = [
            path.join(os.homedir(), 'AppData', 'Local', 'swipl', 'bin', 'swipl.exe'),
            path.join(os.homedir(), 'AppData', 'Roaming', 'swipl', 'bin', 'swipl.exe'),
        ];
        for (const execPath of registryPaths) {
            try {
                await fs.promises.access(execPath, fs.constants.F_OK);
                return execPath;
            }
            catch {
                continue;
            }
        }
        return null;
    }
}
class WindowsEnvironmentStrategy {
    name = 'Windows Environment Variables';
    priority = 70;
    async detect() {
        const swiplHome = process.env.SWIPL_HOME;
        if (swiplHome) {
            const execPath = path.join(swiplHome, 'bin', 'swipl.exe');
            try {
                await fs.promises.access(execPath, fs.constants.F_OK);
                return execPath;
            }
            catch {
                // Continue
            }
        }
        return null;
    }
}
// macOS-specific detection strategies
class MacOSWhichStrategy {
    name = 'macOS which command';
    priority = 100;
    async detect() {
        try {
            const result = await (0, which_1.default)('swipl');
            return result || null;
        }
        catch {
            return null;
        }
    }
}
class MacOSHomebrewStrategy {
    name = 'macOS Homebrew';
    priority = 90;
    async detect() {
        const homebrewPaths = [
            '/usr/local/bin/swipl', // Intel Macs
            '/opt/homebrew/bin/swipl', // Apple Silicon Macs
        ];
        for (const execPath of homebrewPaths) {
            try {
                await fs.promises.access(execPath, fs.constants.F_OK);
                return execPath;
            }
            catch {
                continue;
            }
        }
        return null;
    }
}
class MacOSApplicationsStrategy {
    name = 'macOS Applications';
    priority = 80;
    async detect() {
        const appPath = '/Applications/SWI-Prolog.app/Contents/MacOS/swipl';
        try {
            await fs.promises.access(appPath, fs.constants.F_OK);
            return appPath;
        }
        catch {
            return null;
        }
    }
}
class MacOSMacPortsStrategy {
    name = 'macOS MacPorts';
    priority = 70;
    async detect() {
        const macPortsPaths = [
            '/opt/local/bin/swipl',
            '/sw/bin/swipl', // Fink
        ];
        for (const execPath of macPortsPaths) {
            try {
                await fs.promises.access(execPath, fs.constants.F_OK);
                return execPath;
            }
            catch {
                continue;
            }
        }
        return null;
    }
}
class MacOSStandardPathsStrategy {
    name = 'macOS Standard Paths';
    priority = 60;
    async detect() {
        const standardPaths = ['/usr/bin/swipl', path.join(os.homedir(), '.local', 'bin', 'swipl')];
        for (const execPath of standardPaths) {
            try {
                await fs.promises.access(execPath, fs.constants.F_OK);
                return execPath;
            }
            catch {
                continue;
            }
        }
        return null;
    }
}
// Linux-specific detection strategies
class LinuxWhichStrategy {
    name = 'Linux which command';
    priority = 100;
    async detect() {
        try {
            const result = await (0, which_1.default)('swipl');
            return result || null;
        }
        catch {
            return null;
        }
    }
}
class LinuxWhereisStrategy {
    name = 'Linux whereis command';
    priority = 95;
    async detect() {
        return new Promise(resolve => {
            const process = (0, child_process_1.spawn)('whereis', ['swipl'], {
                stdio: ['ignore', 'pipe', 'pipe'],
                timeout: 5000,
            });
            let output = '';
            process.stdout?.on('data', data => {
                output += data.toString();
            });
            process.on('close', code => {
                if (code === 0) {
                    // whereis output format: "swipl: /usr/bin/swipl /usr/share/man/man1/swipl.1.gz"
                    const match = output.match(/swipl:\s+([^\s]+)/);
                    if (match?.[1] && !match[1].includes('.gz')) {
                        resolve(match[1]);
                        return;
                    }
                }
                resolve(null);
            });
            process.on('error', () => {
                resolve(null);
            });
            setTimeout(() => {
                process.kill();
                resolve(null);
            }, 5000);
        });
    }
}
class LinuxStandardPathsStrategy {
    name = 'Linux Standard Paths';
    priority = 90;
    async detect() {
        const standardPaths = ['/usr/bin/swipl', '/usr/local/bin/swipl', '/opt/swipl/bin/swipl'];
        for (const execPath of standardPaths) {
            try {
                await fs.promises.access(execPath, fs.constants.F_OK);
                return execPath;
            }
            catch {
                continue;
            }
        }
        return null;
    }
}
class LinuxPackageManagerStrategy {
    name = 'Linux Package Manager Paths';
    priority = 80;
    async detect() {
        const packagePaths = [
            '/usr/lib/swi-prolog/bin/x86_64-linux/swipl', // Debian/Ubuntu specific
            '/usr/lib64/swi-prolog/bin/x86_64-linux/swipl', // 64-bit systems
        ];
        for (const execPath of packagePaths) {
            try {
                await fs.promises.access(execPath, fs.constants.F_OK);
                return execPath;
            }
            catch {
                continue;
            }
        }
        return null;
    }
}
class LinuxSnapFlatpakStrategy {
    name = 'Linux Snap/Flatpak';
    priority = 70;
    async detect() {
        const snapFlatpakPaths = [
            '/snap/bin/swi-prolog',
            '/var/lib/flatpak/exports/bin/org.swi_prolog.SWI-Prolog',
            path.join(os.homedir(), '.local', 'share', 'flatpak', 'exports', 'bin', 'org.swi_prolog.SWI-Prolog'),
        ];
        for (const execPath of snapFlatpakPaths) {
            try {
                await fs.promises.access(execPath, fs.constants.F_OK);
                return execPath;
            }
            catch {
                continue;
            }
        }
        return null;
    }
}
class LinuxUserLocalStrategy {
    name = 'Linux User Local';
    priority = 60;
    async detect() {
        const userPaths = [
            path.join(os.homedir(), '.local', 'bin', 'swipl'),
            path.join(os.homedir(), 'bin', 'swipl'),
        ];
        for (const execPath of userPaths) {
            try {
                await fs.promises.access(execPath, fs.constants.F_OK);
                return execPath;
            }
            catch {
                continue;
            }
        }
        return null;
    }
}
//# sourceMappingURL=executableFinder.js.map