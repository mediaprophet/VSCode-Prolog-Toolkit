import { Position } from 'vscode';
export declare class PositionUtils {
    static findLineColForByte(doc: string, index: number): Position;
}
//# sourceMappingURL=positionUtils.d.ts.map