/**
 * Executable detection result interface
 */
export interface ExecutableDetectionResult {
    found: boolean;
    path?: string;
    version?: string;
    permissions?: {
        readable: boolean;
        writable: boolean;
        executable: boolean;
    };
    issues?: string[];
    detectionMethod?: string;
}
/**
 * Platform-specific detection strategy interface
 */
export interface DetectionStrategy {
    name: string;
    priority: number;
    detect(): Promise<string | null>;
}
/**
 * Comprehensive executable finder with platform-specific detection strategies
 */
export declare class ExecutableFinder {
    private platform;
    private strategies;
    constructor();
    /**
     * Initialize platform-specific detection strategies
     */
    private initializeStrategies;
    /**
     * Find SWI-Prolog executable using all available strategies
     */
    findSwiplExecutable(): Promise<ExecutableDetectionResult>;
    /**
     * Validate an executable path and get detailed information
     */
    validateExecutable(execPath: string): Promise<ExecutableDetectionResult>;
    /**
     * Check file permissions (Unix-style and Windows)
     */
    private checkPermissions;
    /**
     * Execute the binary to get version information
     */
    private getExecutableVersion;
    /**
     * Check if output is from SWI-Prolog
     */
    private isSwiplOutput;
    /**
     * Extract version number from SWI-Prolog output
     */
    private extractVersion;
    /**
     * Get platform-specific installation suggestions
     */
    getInstallationSuggestions(): Promise<string[]>;
}
//# sourceMappingURL=executableFinder.d.ts.map