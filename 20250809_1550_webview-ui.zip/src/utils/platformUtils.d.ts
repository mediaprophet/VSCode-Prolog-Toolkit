/**
 * Platform configuration interface defining platform-specific settings
 */
export interface PlatformConfig {
    executablePaths: string[];
    packageManager: string;
    installCommands: string[];
    pathSeparator: string;
    executableExtension: string;
    defaultExecutablePath: string;
    defaultRuntimeArgs: string[];
    configurationLocation: string;
    tempDirectory: string;
    homeDirectory: string;
}
/**
 * Supported platform types
 */
export type PlatformType = 'windows' | 'macos' | 'linux';
/**
 * Supported architecture types
 */
export type ArchitectureType = 'x64' | 'arm64' | 'x86' | 'x32';
/**
 * Environment variable mappings for different platforms
 */
export interface EnvironmentVariables {
    crossPlatform: string[];
    platformSpecific: string[];
}
/**
 * Utility class for platform detection and configuration
 */
export declare class PlatformUtils {
    private static _platform;
    private static _architecture;
    private static _config;
    /**
     * Get the current platform type
     */
    static getPlatform(): PlatformType;
    /**
     * Get the current architecture type
     */
    static getArchitecture(): ArchitectureType;
    /**
     * Get platform-specific default configuration
     */
    static getPlatformDefaults(): PlatformConfig;
    /**
     * Normalize a file path for the current platform
     */
    static normalizePath(inputPath: string): string;
    /**
     * Get the executable extension for the current platform
     */
    static getExecutableExtension(): string;
    /**
     * Get the path separator for the current platform
     */
    static getPathSeparator(): string;
    /**
     * Get the home directory for the current platform
     */
    static getHomeDirectory(): string;
    /**
     * Get the temporary directory for the current platform
     */
    static getTempDirectory(): string;
    /**
     * Get the configuration file location for the current platform
     */
    static getConfigurationLocation(): string;
    /**
     * Get platform-specific environment variables
     */
    static getEnvironmentVariables(): EnvironmentVariables;
    /**
     * Expand environment variables in a path string
     */
    static expandEnvironmentVariables(inputPath: string): string;
    /**
     * Check if a path exists and is accessible
     */
    static pathExists(filePath: string): Promise<boolean>;
    /**
     * Check if a path is executable
     */
    static isExecutable(filePath: string): Promise<boolean>;
    /**
     * Get platform-specific executable paths for SWI-Prolog
     */
    static getExecutablePaths(): string[];
    /**
     * Get the default executable path for the current platform
     */
    static getDefaultExecutablePath(): string;
    /**
     * Get default runtime arguments for the current platform
     */
    static getDefaultRuntimeArgs(): string[];
    /**
     * Get package manager information for the current platform
     */
    static getPackageManager(): string;
    /**
     * Get installation commands for the current platform
     */
    static getInstallCommands(): string[];
    /**
     * Create a platform-appropriate file path
     */
    static joinPath(...segments: string[]): string;
    /**
     * Resolve a path relative to another path
     */
    static resolvePath(basePath: string, ...segments: string[]): string;
    /**
     * Get the directory name from a path
     */
    static dirname(filePath: string): string;
    /**
     * Get the base name from a path
     */
    static basename(filePath: string, ext?: string): string;
    /**
     * Get the file extension from a path
     */
    static extname(filePath: string): string;
    /**
     * Check if a path is absolute
     */
    static isAbsolute(filePath: string): boolean;
    /**
     * Convert a relative path to absolute
     */
    static toAbsolute(filePath: string, basePath?: string): string;
    /**
     * Get platform information summary
     */
    static getPlatformInfo(): {
        platform: PlatformType;
        architecture: ArchitectureType;
        osVersion: string;
        nodeVersion: string;
        homeDirectory: string;
        tempDirectory: string;
        pathSeparator: string;
        executableExtension: string;
    };
    /**
     * Reset cached platform information (useful for testing)
     */
    static resetCache(): void;
}
/**
 * Convenience functions for common operations
 */
/**
 * Get the current platform type
 */
export declare function getPlatform(): PlatformType;
/**
 * Get the current architecture type
 */
export declare function getArchitecture(): ArchitectureType;
/**
 * Get platform-specific default configuration
 */
export declare function getPlatformDefaults(): PlatformConfig;
/**
 * Normalize a file path for the current platform
 */
export declare function normalizePath(inputPath: string): string;
/**
 * Get the executable extension for the current platform
 */
export declare function getExecutableExtension(): string;
/**
 * Get the path separator for the current platform
 */
export declare function getPathSeparator(): string;
/**
 * Get the home directory for the current platform
 */
export declare function getHomeDirectory(): string;
/**
 * Get the temporary directory for the current platform
 */
export declare function getTempDirectory(): string;
//# sourceMappingURL=platformUtils.d.ts.map