import { Position, TextDocument } from 'vscode';
import { ExtensionContext } from 'vscode';
export interface ISnippet {
    [predIndicator: string]: {
        prefix: string;
        body: string[];
        description: string;
    };
}
export interface IPredModule {
    [predicate: string]: string[];
}
export interface IPredicate {
    wholePred: string;
    pi: string;
    functor: string;
    arity: number;
    params: string;
    module: string;
}
export declare class SnippetUtils {
    /**
     * Extracts the predicate under the cursor from a VSCode TextDocument and Position.
     * Returns an IPredicate or null if not found.
     */
    static getPredicateUnderCursor(doc: TextDocument, position: Position): IPredicate | null;
    static snippets: ISnippet | null;
    static predModules: IPredModule | null;
    static loadSnippets(context: ExtensionContext): void;
    static genPredicateModules(): void;
    static getPredDescriptions(pred: string): string;
    static getPredModules(pred1: string): string[];
    static getBuiltinNames(): string[];
}
//# sourceMappingURL=snippetUtils.d.ts.map