"use strict";
/**
 * Error handling utilities for strict TypeScript mode
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.TimeoutError = exports.NetworkError = exports.ValidationError = exports.TypedError = void 0;
exports.isError = isError;
exports.hasErrorProperty = hasErrorProperty;
exports.getErrorMessage = getErrorMessage;
exports.getErrorCode = getErrorCode;
exports.getErrorStack = getErrorStack;
exports.standardizeError = standardizeError;
exports.safeExecute = safeExecute;
exports.safeExecuteSync = safeExecuteSync;
exports.wrapWithResult = wrapWithResult;
exports.wrapWithResultSync = wrapWithResultSync;
exports.assertNotNull = assertNotNull;
exports.assert = assert;
exports.retryWithBackoff = retryWithBackoff;
/**
 * Type guard to check if an error is an instance of Error
 */
function isError(error) {
    return error instanceof Error;
}
/**
 * Type guard to check if an error has a specific property
 */
function hasErrorProperty(error, property) {
    return isError(error) && property in error;
}
/**
 * Safely extract error message from unknown error
 */
function getErrorMessage(error) {
    if (isError(error)) {
        return error.message;
    }
    if (typeof error === 'string') {
        return error;
    }
    if (error && typeof error === 'object' && 'message' in error) {
        return String(error.message);
    }
    return 'Unknown error occurred';
}
/**
 * Safely extract error code from unknown error
 */
function getErrorCode(error) {
    if (hasErrorProperty(error, 'code')) {
        return typeof error.code === 'string' ? error.code : String(error.code);
    }
    return undefined;
}
/**
 * Safely extract error stack from unknown error
 */
function getErrorStack(error) {
    if (isError(error)) {
        return error.stack;
    }
    return undefined;
}
function standardizeError(error) {
    return {
        message: getErrorMessage(error),
        code: getErrorCode(error),
        stack: getErrorStack(error),
        originalError: error,
    };
}
/**
 * Safely execute a function and handle errors
 */
async function safeExecute(fn, onError) {
    try {
        return await fn();
    }
    catch (error) {
        const standardError = standardizeError(error);
        onError?.(standardError);
        return undefined;
    }
}
/**
 * Safely execute a synchronous function and handle errors
 */
function safeExecuteSync(fn, onError) {
    try {
        return fn();
    }
    catch (error) {
        const standardError = standardizeError(error);
        onError?.(standardError);
        return undefined;
    }
}
/**
 * Wrap a function to return a SafeResult
 */
async function wrapWithResult(fn) {
    try {
        const data = await fn();
        return { success: true, data };
    }
    catch (error) {
        return { success: false, error: standardizeError(error) };
    }
}
/**
 * Wrap a synchronous function to return a SafeResult
 */
function wrapWithResultSync(fn) {
    try {
        const data = fn();
        return { success: true, data };
    }
    catch (error) {
        return { success: false, error: standardizeError(error) };
    }
}
/**
 * Assert that a value is not null or undefined
 */
function assertNotNull(value, message = 'Value is null or undefined') {
    if (value == null) {
        throw new Error(message);
    }
}
/**
 * Assert that a condition is true
 */
function assert(condition, message = 'Assertion failed') {
    if (!condition) {
        throw new Error(message);
    }
}
/**
 * Create a typed error class
 */
class TypedError extends Error {
    type;
    details;
    constructor(type, message, details) {
        super(message);
        this.type = type;
        this.details = details;
        this.name = `TypedError<${type}>`;
    }
}
exports.TypedError = TypedError;
/**
 * Create specific error types
 */
class ValidationError extends TypedError {
    field;
    constructor(message, field, details) {
        super('validation', message, details);
        this.field = field;
        this.name = 'ValidationError';
    }
}
exports.ValidationError = ValidationError;
class NetworkError extends TypedError {
    statusCode;
    constructor(message, statusCode, details) {
        super('network', message, details);
        this.statusCode = statusCode;
        this.name = 'NetworkError';
    }
}
exports.NetworkError = NetworkError;
class TimeoutError extends TypedError {
    timeoutMs;
    constructor(message, timeoutMs, details) {
        super('timeout', message, details);
        this.timeoutMs = timeoutMs;
        this.name = 'TimeoutError';
    }
}
exports.TimeoutError = TimeoutError;
/**
 * Retry a function with exponential backoff
 */
async function retryWithBackoff(fn, maxRetries = 3, baseDelayMs = 1000, maxDelayMs = 10000) {
    let lastError;
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
        try {
            return await fn();
        }
        catch (error) {
            lastError = error;
            if (attempt === maxRetries) {
                throw error;
            }
            const delay = Math.min(baseDelayMs * Math.pow(2, attempt), maxDelayMs);
            await new Promise(resolve => setTimeout(resolve, delay));
        }
    }
    throw lastError;
}
//# sourceMappingURL=errorHandling.js.map