"use strict";
/**
 * Safe access utilities for handling null/undefined values in strict mode
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.safeGet = safeGet;
exports.safeGetNested = safeGetNested;
exports.withDefault = withDefault;
exports.isNotNullish = isNotNullish;
exports.filterNullish = filterNullish;
exports.safeArrayAccess = safeArrayAccess;
exports.safeCall = safeCall;
exports.createSafeAccessor = createSafeAccessor;
exports.safeJsonParse = safeJsonParse;
exports.safeToString = safeToString;
exports.safeToNumber = safeToNumber;
exports.safeToBoolean = safeToBoolean;
/**
 * Safely access a property that might be undefined
 */
function safeGet(obj, key) {
    return obj?.[key];
}
/**
 * Safely access a nested property
 */
function safeGetNested(obj, path) {
    if (!obj || typeof obj !== 'object')
        return undefined;
    const keys = path.split('.');
    let current = obj;
    for (const key of keys) {
        if (current == null || typeof current !== 'object')
            return undefined;
        current = current[key];
    }
    return current;
}
/**
 * Provide a default value if the input is null or undefined
 */
function withDefault(value, defaultValue) {
    return value ?? defaultValue;
}
/**
 * Check if a value is not null or undefined
 */
function isNotNullish(value) {
    return value != null;
}
/**
 * Filter out null and undefined values from an array
 */
function filterNullish(array) {
    return array.filter(isNotNullish);
}
/**
 * Safely access array element
 */
function safeArrayAccess(array, index) {
    if (!array || index < 0 || index >= array.length)
        return undefined;
    return array[index];
}
/**
 * Safely call a function if it exists
 */
function safeCall(fn, ...args) {
    return fn?.(...args);
}
/**
 * Create a safe property accessor
 */
function createSafeAccessor(obj) {
    return {
        get(key) {
            return obj?.[key];
        },
        has(key) {
            return obj != null && key in obj;
        },
        keys() {
            return obj ? Object.keys(obj) : [];
        },
    };
}
/**
 * Safely parse JSON with error handling
 */
function safeJsonParse(json) {
    if (!json)
        return undefined;
    try {
        return JSON.parse(json);
    }
    catch {
        return undefined;
    }
}
/**
 * Safely convert to string
 */
function safeToString(value) {
    if (value == null)
        return '';
    if (typeof value === 'string')
        return value;
    if (typeof value === 'object') {
        try {
            return JSON.stringify(value);
        }
        catch {
            return String(value);
        }
    }
    return String(value);
}
/**
 * Safely convert to number
 */
function safeToNumber(value) {
    if (value == null)
        return undefined;
    const num = Number(value);
    return isNaN(num) ? undefined : num;
}
/**
 * Safely convert to boolean
 */
function safeToBoolean(value) {
    if (value == null)
        return false;
    if (typeof value === 'boolean')
        return value;
    if (typeof value === 'string') {
        const lower = value.toLowerCase();
        return lower === 'true' || lower === '1' || lower === 'yes';
    }
    if (typeof value === 'number')
        return value !== 0;
    return Boolean(value);
}
//# sourceMappingURL=safeAccess.js.map