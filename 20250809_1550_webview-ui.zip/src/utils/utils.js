"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SnippetUtils = exports.PrologExecUtils = exports.PositionUtils = exports.PlatformEnvUtils = void 0;
// Modularized utility re-exports and orchestration
var platformUtils_mod_1 = require("./platformUtils.mod");
Object.defineProperty(exports, "PlatformEnvUtils", { enumerable: true, get: function () { return platformUtils_mod_1.PlatformEnvUtils; } });
var positionUtils_1 = require("./positionUtils");
Object.defineProperty(exports, "PositionUtils", { enumerable: true, get: function () { return positionUtils_1.PositionUtils; } });
var prologExecUtils_1 = require("./prologExecUtils");
Object.defineProperty(exports, "PrologExecUtils", { enumerable: true, get: function () { return prologExecUtils_1.PrologExecUtils; } });
var snippetUtils_1 = require("./snippetUtils");
Object.defineProperty(exports, "SnippetUtils", { enumerable: true, get: function () { return snippetUtils_1.SnippetUtils; } });
//# sourceMappingURL=utils.js.map