/**
 * Error handling utilities for strict TypeScript mode
 */
/**
 * Type guard to check if an error is an instance of Error
 */
export declare function isError(error: unknown): error is Error;
/**
 * Type guard to check if an error has a specific property
 */
export declare function hasErrorProperty<K extends string>(error: unknown, property: K): error is Error & Record<K, unknown>;
/**
 * Safely extract error message from unknown error
 */
export declare function getErrorMessage(error: unknown): string;
/**
 * Safely extract error code from unknown error
 */
export declare function getErrorCode(error: unknown): string | undefined;
/**
 * Safely extract error stack from unknown error
 */
export declare function getErrorStack(error: unknown): string | undefined;
/**
 * Create a standardized error object from unknown error
 */
export interface StandardError {
    message: string;
    code?: string | undefined;
    stack?: string | undefined;
    originalError: unknown;
}
export declare function standardizeError(error: unknown): StandardError;
/**
 * Safely execute a function and handle errors
 */
export declare function safeExecute<T>(fn: () => Promise<T>, onError?: (error: StandardError) => void): Promise<T | undefined>;
/**
 * Safely execute a synchronous function and handle errors
 */
export declare function safeExecuteSync<T>(fn: () => T, onError?: (error: StandardError) => void): T | undefined;
/**
 * Create a result type that can contain either success or error
 */
export interface SafeResult<T, E = StandardError> {
    success: boolean;
    data?: T;
    error?: E;
}
/**
 * Wrap a function to return a SafeResult
 */
export declare function wrapWithResult<T>(fn: () => Promise<T>): Promise<SafeResult<T>>;
/**
 * Wrap a synchronous function to return a SafeResult
 */
export declare function wrapWithResultSync<T>(fn: () => T): SafeResult<T>;
/**
 * Assert that a value is not null or undefined
 */
export declare function assertNotNull<T>(value: T | null | undefined, message?: string): asserts value is T;
/**
 * Assert that a condition is true
 */
export declare function assert(condition: unknown, message?: string): asserts condition;
/**
 * Create a typed error class
 */
export declare class TypedError<T extends string = string> extends Error {
    readonly type: T;
    readonly details?: Record<string, unknown>;
    constructor(type: T, message: string, details?: Record<string, unknown>);
}
/**
 * Create specific error types
 */
export declare class ValidationError extends TypedError<'validation'> {
    readonly field?: string;
    constructor(message: string, field?: string, details?: Record<string, unknown>);
}
export declare class NetworkError extends TypedError<'network'> {
    readonly statusCode?: number;
    constructor(message: string, statusCode?: number, details?: Record<string, unknown>);
}
export declare class TimeoutError extends TypedError<'timeout'> {
    readonly timeoutMs?: number;
    constructor(message: string, timeoutMs?: number, details?: Record<string, unknown>);
}
/**
 * Retry a function with exponential backoff
 */
export declare function retryWithBackoff<T>(fn: () => Promise<T>, maxRetries?: number, baseDelayMs?: number, maxDelayMs?: number): Promise<T>;
//# sourceMappingURL=errorHandling.d.ts.map