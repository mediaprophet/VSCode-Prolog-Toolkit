export {};
//# sourceMappingURL=snippets_from_txt.ecl.d.ts.map