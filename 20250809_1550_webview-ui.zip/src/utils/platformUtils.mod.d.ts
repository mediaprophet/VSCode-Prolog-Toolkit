export declare class PlatformEnvUtils {
    static initializePlatformSettings(): void;
    static getPlatformExecutablePath(): string;
    static getPlatformRuntimeArgs(): string[];
    static expandEnvironmentVariables(inputPath: string): string;
    static getPlatformEnvironmentVariables(): Record<string, string>;
    static createPlatformPath(...segments: string[]): string;
    static resolvePlatformPath(basePath: string, ...segments: string[]): string;
}
//# sourceMappingURL=platformUtils.mod.d.ts.map