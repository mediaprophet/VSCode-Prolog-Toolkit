"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlatformEnvUtils = void 0;
// Platform/path/environment variable utilities extracted from utils.ts
const vscode_1 = require("vscode");
const platformUtils_1 = require("./platformUtils");
class PlatformEnvUtils {
    static initializePlatformSettings() {
        const config = vscode_1.workspace.getConfiguration('prolog');
        const autoDetect = config.get('platform.autoDetect', true);
        if (autoDetect) {
            const platformDefaults = (0, platformUtils_1.getPlatformDefaults)();
            const currentExecPath = config.get('executablePath');
            if (!currentExecPath || currentExecPath === '/usr/bin/swipl') {
                const platformExecPath = platformDefaults.defaultExecutablePath;
                if (platformExecPath !== currentExecPath) {
                    console.log(`[Platform Utils] Auto-detected executable path: ${platformExecPath}`);
                }
            }
            const currentRuntimeArgs = config.get('terminal.runtimeArgs');
            if (!currentRuntimeArgs || currentRuntimeArgs.length === 0) {
                const platformRuntimeArgs = platformDefaults.defaultRuntimeArgs;
                if (platformRuntimeArgs.length > 0) {
                    console.log(`[Platform Utils] Auto-detected runtime args: ${platformRuntimeArgs.join(' ')}`);
                }
            }
        }
    }
    static getPlatformExecutablePath() {
        const config = vscode_1.workspace.getConfiguration('prolog');
        let execPath = config.get('executablePath', '');
        if (!execPath)
            execPath = (0, platformUtils_1.getPlatformDefaults)().defaultExecutablePath;
        return platformUtils_1.PlatformUtils.normalizePath(execPath);
    }
    static getPlatformRuntimeArgs() {
        const config = vscode_1.workspace.getConfiguration('prolog');
        let runtimeArgs = config.get('terminal.runtimeArgs', []);
        if (runtimeArgs.length === 0)
            runtimeArgs = (0, platformUtils_1.getPlatformDefaults)().defaultRuntimeArgs;
        return runtimeArgs;
    }
    static expandEnvironmentVariables(inputPath) {
        return platformUtils_1.PlatformUtils.expandEnvironmentVariables(inputPath);
    }
    static getPlatformEnvironmentVariables() {
        const config = vscode_1.workspace.getConfiguration('prolog');
        const customEnvVars = config.get('platform.environmentVariables', {});
        const platformEnvVars = platformUtils_1.PlatformUtils.getEnvironmentVariables();
        const result = {};
        platformEnvVars.crossPlatform.forEach(varName => {
            if (process.env[varName])
                result[varName] = process.env[varName];
        });
        platformEnvVars.platformSpecific.forEach(varName => {
            if (process.env[varName])
                result[varName] = process.env[varName];
        });
        Object.assign(result, customEnvVars);
        return result;
    }
    static createPlatformPath(...segments) {
        return platformUtils_1.PlatformUtils.joinPath(...segments);
    }
    static resolvePlatformPath(basePath, ...segments) {
        const normalizedBase = platformUtils_1.PlatformUtils.normalizePath(basePath);
        return platformUtils_1.PlatformUtils.resolvePath(normalizedBase, ...segments);
    }
}
exports.PlatformEnvUtils = PlatformEnvUtils;
//# sourceMappingURL=platformUtils.mod.js.map