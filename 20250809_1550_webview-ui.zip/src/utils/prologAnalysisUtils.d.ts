import { Uri } from 'vscode';
/**
 * Utility methods for advanced Prolog code analysis, including cross-file predicate resolution and refactoring helpers.
 */
export declare class PrologAnalysisUtils {
    /**
     * Find all files in the workspace that define a given predicate (by functor/arity).
     * Returns an array of {uri, line, predicate} objects.
     */
    static findPredicateDefinitions(functor: string, arity: number): Promise<Array<{
        uri: Uri;
        line: number;
        predicate: string;
    }>>;
    /**
     * Refactor all occurrences of a predicate (functor/arity) to a new name in the workspace.
     * Returns a list of files and line numbers changed.
     */
    static refactorPredicateName(oldFunctor: string, oldArity: number, newFunctor: string): Promise<Array<{
        uri: Uri;
        line: number;
    }>>;
}
//# sourceMappingURL=prologAnalysisUtils.d.ts.map