"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PositionUtils = void 0;
// Position and document helpers extracted from utils.ts
const vscode_1 = require("vscode");
class PositionUtils {
    static findLineColForByte(doc, index) {
        const lines = doc.split('\n');
        let totalLength = 0;
        let lineStartPos = 0;
        for (let lineNo = 0; lineNo < lines.length; lineNo++) {
            totalLength += lines[lineNo].length + 1;
            if (index < totalLength) {
                const colNo = index - lineStartPos;
                return new vscode_1.Position(lineNo, colNo);
            }
            lineStartPos = totalLength;
        }
        return new vscode_1.Position(0, 0);
    }
}
exports.PositionUtils = PositionUtils;
//# sourceMappingURL=positionUtils.js.map