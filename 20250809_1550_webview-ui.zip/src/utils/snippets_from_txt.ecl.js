"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = __importStar(require("fs"));
const fast_glob_1 = __importDefault(require("fast-glob"));
const snippets = {};
async function libsToSnippets(path, builtin) {
    // Use fast-glob to find all directories in the given path
    const libs = await (0, fast_glob_1.default)([`${path}/*/`], { onlyDirectories: true });
    await Promise.all(libs.map(async (lib) => {
        // Use fast-glob to find all .txt files in the library directory
        const preds = await (0, fast_glob_1.default)([`${lib}/*.txt`], { onlyFiles: true });
        await Promise.all(preds.map(async (pred) => {
            const snippet = await fileToSnippet(pred);
            if (snippet) {
                let key = pred
                    .split('/')
                    .slice(-2)
                    .join(':')
                    .replace('-', '/')
                    .replace(/\.txt$/, '');
                if (builtin) {
                    key = key.split(':')[1];
                }
                snippets[key] = snippet;
            }
        }));
    }));
}
async function fileToSnippet(file) {
    if (/summary\.txt$/.test(file)) {
        return null;
    }
    try {
        let snippet = null;
        const txt = await fs.promises.readFile(file, 'utf8');
        const str = txt.toString().replace(/\n\n+/g, '\n\n').replace(/ {8,}/g, '    ').trim();
        const match = str.match(/^(\w+)(\(([^)]*)\))?/);
        let prefix = '', params = '', body;
        if (match) {
            prefix = match[1];
            body = prefix;
            if (match[2]) {
                params = match[3];
                const plist = params.split(',');
                body += '(';
                for (let i = 1; i <= plist.length; i++) {
                    const mtch = plist[i - 1].match(/\w+/);
                    if (mtch) {
                        const pName = mtch[0];
                        body += '${' + i + ':' + pName + '}';
                        if (i < plist.length) {
                            body += ', ';
                        }
                        else {
                            body += ')$' + (i + 1) + '\n$0';
                        }
                    }
                }
            }
            snippet = {
                prefix: prefix,
                body: body,
                description: str,
            };
        }
        return snippet;
    }
    catch (error) {
        console.log(error);
        return undefined;
    }
}
(async () => {
    const docRoot = '/opt/eclipseclp/doc/bips/';
    await libsToSnippets(docRoot + 'kernel', true);
    await libsToSnippets(docRoot + 'lib', false);
    await libsToSnippets(docRoot + 'lib_public', false);
    await fs.promises.writeFile('prolog.ecl.json', JSON.stringify(snippets, null, 2));
})();
//# sourceMappingURL=snippets_from_txt.ecl.js.map