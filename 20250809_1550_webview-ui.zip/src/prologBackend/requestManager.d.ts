export interface PrologRequestManagerOptions {
    port: number;
    maxResultsPerChunk: number;
    streamingEnabled: boolean;
    logger?: (msg: string) => void;
}
export declare class PrologRequestManager {
    private options;
    constructor(options: PrologRequestManagerOptions);
    sendRequest(cmd: string, params?: Record<string, any>, timeoutMs?: number): Promise<any>;
}
//# sourceMappingURL=requestManager.d.ts.map