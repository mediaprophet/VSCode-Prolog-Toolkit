"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ModularPrologBackend = void 0;
// Main orchestrator for modular Prolog backend
const concurrencyManager_1 = require("./concurrencyManager");
const historyManager_1 = require("./historyManager");
const notificationManager_1 = require("./notificationManager");
const processManager_1 = require("./processManager");
const requestManager_1 = require("./requestManager");
const sessionManager_1 = require("./sessionManager");
class ModularPrologBackend {
    processManager;
    requestManager;
    notificationManager;
    concurrencyManager;
    sessionManager;
    historyManager;
    constructor(options) {
        this.processManager = new processManager_1.PrologProcessManager(options);
        this.requestManager = new requestManager_1.PrologRequestManager({
            port: options.port || 3060,
            maxResultsPerChunk: options.maxResultsPerChunk || 50,
            streamingEnabled: options.streamingEnabled ?? true,
        });
        this.notificationManager = new notificationManager_1.PrologNotificationManager({
            enableWebSocket: true,
            webSocketPort: (options.port || 3060) + 2,
        });
        this.concurrencyManager = new concurrencyManager_1.PrologConcurrencyManager({});
        this.sessionManager = new sessionManager_1.PrologSessionManager({});
        this.historyManager = new historyManager_1.PrologHistoryManager({});
    }
}
exports.ModularPrologBackend = ModularPrologBackend;
//# sourceMappingURL=index.js.map