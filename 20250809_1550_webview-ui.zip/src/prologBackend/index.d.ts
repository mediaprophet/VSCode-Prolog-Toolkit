import { PrologConcurrencyManager } from './concurrencyManager';
import { PrologHistoryManager } from './historyManager';
import { PrologNotificationManager } from './notificationManager';
import { PrologProcessManager } from './processManager';
import { PrologRequestManager } from './requestManager';
import { PrologSessionManager } from './sessionManager';
export interface ModularPrologBackendOptions {
    swiplPath?: string;
    args?: string[];
    cwd?: string;
    port?: number;
    maxResultsPerChunk?: number;
    streamingEnabled?: boolean;
}
export declare class ModularPrologBackend {
    readonly processManager: PrologProcessManager;
    readonly requestManager: PrologRequestManager;
    readonly notificationManager: PrologNotificationManager;
    readonly concurrencyManager: PrologConcurrencyManager;
    readonly sessionManager: PrologSessionManager;
    readonly historyManager: PrologHistoryManager;
    constructor(options: ModularPrologBackendOptions);
}
//# sourceMappingURL=index.d.ts.map