"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrologHistoryManager = void 0;
const events_1 = require("events");
class PrologHistoryManager extends events_1.EventEmitter {
    constructor(options) {
        super();
        // ...setup logic...
    }
}
exports.PrologHistoryManager = PrologHistoryManager;
//# sourceMappingURL=historyManager.js.map