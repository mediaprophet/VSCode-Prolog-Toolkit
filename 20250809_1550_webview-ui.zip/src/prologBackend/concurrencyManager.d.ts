import { EventEmitter } from 'events';
import { ResourceQuota } from '../features/concurrencyManager';
export interface PrologConcurrencyManagerOptions {
    resourceQuota?: Partial<ResourceQuota>;
    logger?: (msg: string) => void;
}
export declare class PrologConcurrencyManager extends EventEmitter {
    constructor(options: PrologConcurrencyManagerOptions);
}
//# sourceMappingURL=concurrencyManager.d.ts.map