"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrologRequestManager = void 0;
class PrologRequestManager {
    options;
    constructor(options) {
        this.options = options;
    }
    async sendRequest(cmd, params = {}, timeoutMs = 10000) {
        // ...request logic, streaming, batching, timeouts...
    }
}
exports.PrologRequestManager = PrologRequestManager;
//# sourceMappingURL=requestManager.js.map