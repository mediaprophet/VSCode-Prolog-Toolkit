import { EventEmitter } from 'events';
import { SessionManagerOptions } from '../features/sessionManager';
export interface PrologSessionManagerOptions extends Partial<SessionManagerOptions> {
    logger?: (msg: string) => void;
}
export declare class PrologSessionManager extends EventEmitter {
    constructor(options: PrologSessionManagerOptions);
}
//# sourceMappingURL=sessionManager.d.ts.map