"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrologConcurrencyManager = void 0;
const events_1 = require("events");
class PrologConcurrencyManager extends events_1.EventEmitter {
    constructor(options) {
        super();
        // ...setup logic...
    }
}
exports.PrologConcurrencyManager = PrologConcurrencyManager;
//# sourceMappingURL=concurrencyManager.js.map