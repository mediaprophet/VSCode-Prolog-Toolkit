"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrologNotificationManager = void 0;
const events_1 = require("events");
class PrologNotificationManager extends events_1.EventEmitter {
    constructor(options) {
        super();
        // ...setup logic...
    }
}
exports.PrologNotificationManager = PrologNotificationManager;
//# sourceMappingURL=notificationManager.js.map