import { EventEmitter } from 'events';
export interface PrologNotificationManagerOptions {
    enableWebSocket?: boolean;
    webSocketPort?: number;
    logger?: (msg: string) => void;
}
export declare class PrologNotificationManager extends EventEmitter {
    constructor(options: PrologNotificationManagerOptions);
}
//# sourceMappingURL=notificationManager.d.ts.map