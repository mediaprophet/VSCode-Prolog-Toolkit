import { EventEmitter } from 'events';
export interface PrologProcessOptions {
    swiplPath?: string;
    args?: string[];
    cwd?: string;
    port?: number;
    onReady?: () => void;
    onExit?: (code: number | null, signal: NodeJS.Signals | null) => void;
    logger?: (msg: string) => void;
}
export declare class PrologProcessManager extends EventEmitter {
    private process;
    private options;
    private intentionalStop;
    private isReady;
    constructor(options: PrologProcessOptions);
    start(): Promise<void>;
    stop(intentional?: boolean): void;
    restart(): void;
    isRunning(): boolean;
    private log;
}
//# sourceMappingURL=processManager.d.ts.map