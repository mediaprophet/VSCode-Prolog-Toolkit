"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrologProcessManager = void 0;
const events_1 = require("events");
const platformUtils_1 = require("../utils/platformUtils");
class PrologProcessManager extends events_1.EventEmitter {
    process = null;
    options;
    intentionalStop = false;
    isReady = false;
    constructor(options) {
        super();
        this.options = options;
    }
    async start() {
        if (this.process) {
            this.log('Prolog backend already running.');
            return;
        }
        let swiplPath = this.options.swiplPath || platformUtils_1.PlatformUtils.getDefaultExecutablePath();
        // ...executable resolution logic (see original)...
        // ...args, cwd, spawn logic...
        // ...event handlers for exit, stdout, stderr...
        // ...emit 'ready' when handshake completes...
    }
    stop(intentional = true) {
        // ...stop logic...
    }
    restart() {
        // ...restart logic...
    }
    isRunning() {
        return !!this.process;
    }
    log(msg) {
        if (this.options.logger)
            this.options.logger(msg);
        else
            console.log('[PrologProcessManager]', msg);
    }
}
exports.PrologProcessManager = PrologProcessManager;
//# sourceMappingURL=processManager.js.map