"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrologSessionManager = void 0;
const events_1 = require("events");
class PrologSessionManager extends events_1.EventEmitter {
    constructor(options) {
        super();
        // ...setup logic...
    }
}
exports.PrologSessionManager = PrologSessionManager;
//# sourceMappingURL=sessionManager.js.map