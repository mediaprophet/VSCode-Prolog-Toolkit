import { ExtensionContext } from 'vscode';
export declare class PrologLSPClient {
    private client;
    private context;
    constructor(context: ExtensionContext);
    start(): Promise<void>;
    stop(): Promise<void>;
    restart(): Promise<void>;
    isRunning(): boolean;
    private registerEventHandlers;
    private registerCustomHandlers;
    private enhanceCompletions;
    private enhanceHover;
    private isSemanticWebContext;
    private getSemanticWebCompletions;
    private getProjectSpecificCompletions;
    private getWordAtPosition;
    private isBuiltinPredicate;
    private handleQueryResult;
    private handleHelpResult;
    private handleDiagnosticsUpdate;
    executeQuery(query: string): Promise<any>;
    getHelp(predicate: string): Promise<any>;
    consultFile(filePath: string): Promise<any>;
}
//# sourceMappingURL=prologLSPClient.d.ts.map