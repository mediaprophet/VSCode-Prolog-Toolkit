import WebSocket from 'ws';
import { EventEmitter } from 'events';
import { QueryNotificationManager } from './queryNotificationManager';
import { AuthConfig } from './apiMiddleware';
export interface ExternalWebSocketConfig {
    enabled: boolean;
    port: number;
    maxConnections: number;
    heartbeatInterval: number;
    auth: AuthConfig;
}
export interface WebSocketClient {
    id: string;
    ws: WebSocket;
    user?: {
        id: string;
        role: string;
        permissions: string[];
        method: string;
    };
    subscriptions: Set<string>;
    lastHeartbeat: number;
    isAlive: boolean;
}
/**
 * External WebSocket manager for AI agent real-time notifications
 * Extends the existing QueryNotificationManager with external access capabilities
 */
export declare class ExternalWebSocketManager extends EventEmitter {
    private server;
    private clients;
    private config;
    private queryNotificationManager;
    private heartbeatInterval;
    private isRunning;
    constructor(config: ExternalWebSocketConfig, queryNotificationManager: QueryNotificationManager);
    /**
     * Start the external WebSocket server
     */
    start(): Promise<void>;
    /**
     * Stop the external WebSocket server
     */
    stop(): Promise<void>;
    /**
     * Verify client connection
     */
    private verifyClient;
    /**
     * Handle new WebSocket connection
     */
    private handleConnection;
    /**
     * Authenticate WebSocket client
     */
    private authenticateClient;
    /**
     * Handle client message
     */
    private handleClientMessage;
    /**
     * Handle subscription request
     */
    private handleSubscribe;
    /**
     * Handle unsubscribe request
     */
    private handleUnsubscribe;
    /**
     * Handle query cancellation request
     */
    private handleCancelQuery;
    /**
     * Handle query status request
     */
    private handleGetQueryStatus;
    /**
     * Handle system status request
     */
    private handleGetSystemStatus;
    /**
     * Send message to specific client
     */
    private sendToClient;
    /**
     * Broadcast message to all subscribed clients
     */
    private broadcast;
    /**
     * Set up forwarding from QueryNotificationManager
     */
    private setupQueryNotificationForwarding;
    /**
     * Start heartbeat mechanism
     */
    private startHeartbeat;
    /**
     * Generate unique client ID
     */
    private generateClientId;
    /**
     * Get default permissions for role
     */
    private getDefaultPermissions;
    /**
     * Get server status
     */
    getStatus(): {
        running: boolean;
        port: number;
        connectedClients: number;
        maxConnections: number;
    };
}
//# sourceMappingURL=externalWebSocketManager.d.ts.map