"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigurationMigration = void 0;
const vscode = __importStar(require("vscode"));
const installationChecker_js_1 = require("./installationChecker.js");
class ConfigurationMigration {
    static instance;
    installationChecker;
    constructor() {
        this.installationChecker = installationChecker_js_1.InstallationChecker.getInstance();
    }
    static getInstance() {
        if (!ConfigurationMigration.instance) {
            ConfigurationMigration.instance = new ConfigurationMigration();
        }
        return ConfigurationMigration.instance;
    }
    /**
     * Perform automatic configuration migration
     */
    async performMigration() {
        const config = vscode.workspace.getConfiguration('prolog');
        const currentPath = config.get('executablePath', 'swipl');
        // Check if current path is valid
        const isCurrentValid = await this.installationChecker.validateSwiplPath(currentPath);
        if (isCurrentValid) {
            return {
                migrated: false,
                issues: [],
            };
        }
        // Current path is invalid, try to find a valid one
        const foundPath = await this.installationChecker.findSwiplExecutable();
        if (!foundPath) {
            return {
                migrated: false,
                oldPath: currentPath,
                issues: ['No valid SWI-Prolog installation found for migration'],
            };
        }
        // Create backup before migration
        const backupResult = await this.createConfigurationBackup('automatic_migration');
        try {
            // Update configuration
            await config.update('executablePath', foundPath, vscode.ConfigurationTarget.Global);
            return {
                migrated: true,
                oldPath: currentPath,
                newPath: foundPath,
                backupCreated: backupResult,
                issues: [],
            };
        }
        catch (error) {
            return {
                migrated: false,
                oldPath: currentPath,
                backupCreated: backupResult,
                issues: [`Failed to update configuration: ${error}`],
            };
        }
    }
    /**
     * Detect and handle outdated or invalid paths
     */
    async detectOutdatedPaths() {
        const config = vscode.workspace.getConfiguration('prolog');
        const currentPath = config.get('executablePath', 'swipl');
        const invalidPaths = [];
        const suggestions = [];
        // Check current executable path
        const isCurrentValid = await this.installationChecker.validateSwiplPath(currentPath);
        if (!isCurrentValid) {
            invalidPaths.push(currentPath);
        }
        // Check for common outdated paths
        const commonOutdatedPaths = this.getCommonOutdatedPaths();
        for (const outdatedPath of commonOutdatedPaths) {
            if (currentPath.includes(outdatedPath)) {
                invalidPaths.push(currentPath);
                break;
            }
        }
        // Find valid alternatives
        const foundPath = await this.installationChecker.findSwiplExecutable();
        if (typeof foundPath === 'string' && foundPath !== null) {
            const version = await this.installationChecker.getSwiplVersion(foundPath);
            if (foundPath !== null) {
                if (typeof version === 'string') {
                    suggestions.push({ path: foundPath, version });
                }
                else {
                    suggestions.push({ path: foundPath });
                }
            }
        }
        return {
            hasOutdatedPaths: invalidPaths.length > 0,
            invalidPaths,
            suggestions,
        };
    }
    /**
     * Attempt to find new valid paths for invalid configurations
     */
    async findNewValidPaths() {
        const validPaths = [];
        const commonPaths = installationChecker_js_1.InstallationChecker.detectCommonInstallPaths();
        for (const path of commonPaths) {
            if (typeof path === 'string' && path !== null) {
                const isValid = await this.installationChecker.validateSwiplPath(path);
                if (isValid) {
                    const version = await this.installationChecker.getSwiplVersion(path);
                    if (path !== null) {
                        if (typeof version === 'string') {
                            validPaths.push({ path: path, version });
                        }
                        else {
                            validPaths.push({ path: path });
                        }
                    }
                }
            }
        }
        return validPaths;
    }
    /**
     * Create a backup of current configuration
     */
    async createConfigurationBackup(reason) {
        try {
            const config = vscode.workspace.getConfiguration('prolog');
            const backup = {
                timestamp: new Date().toISOString(),
                reason,
                configuration: {
                    executablePath: config.get('executablePath'),
                    dialect: config.get('dialect'),
                    'linter.run': config.get('linter.run'),
                    'linter.delay': config.get('linter.delay'),
                    'linter.enableMsgInOutput': config.get('linter.enableMsgInOutput'),
                    'format.addSpace': config.get('format.addSpace'),
                    'terminal.runtimeArgs': config.get('terminal.runtimeArgs'),
                    'telemetry.enabled': config.get('telemetry.enabled'),
                },
            };
            // Store backup in global state (VS Code's storage)
            const context = this.getExtensionContext();
            if (context) {
                let existingBackups = context.globalState.get('prologConfigBackups', []);
                if (!existingBackups) {
                    existingBackups = [];
                }
                existingBackups.push(backup);
                // Keep only last 10 backups
                if (existingBackups.length > 10) {
                    existingBackups.splice(0, existingBackups.length - 10);
                }
                await context.globalState.update('prologConfigBackups', existingBackups);
                return true;
            }
            return false;
        }
        catch (error) {
            console.error('Failed to create configuration backup:', error);
            return false;
        }
    }
    /**
     * Restore configuration from backup
     */
    async restoreConfigurationBackup(backupIndex = 0) {
        try {
            const context = this.getExtensionContext();
            if (!context) {
                return false;
            }
            const backups = context.globalState.get('prologConfigBackups', []);
            if (backups.length === 0 || backupIndex >= backups.length) {
                return false;
            }
            const backup = backups[backups.length - 1 - backupIndex]; // Most recent first
            const config = vscode.workspace.getConfiguration('prolog');
            // Restore each configuration value
            if (backup && backup.configuration) {
                for (const [key, value] of Object.entries(backup.configuration)) {
                    if (value !== undefined) {
                        await config.update(key, value, vscode.ConfigurationTarget.Global);
                    }
                }
            }
            return true;
        }
        catch (error) {
            console.error('Failed to restore configuration backup:', error);
            return false;
        }
    }
    /**
     * Get list of available backups
     */
    getConfigurationBackups() {
        const context = this.getExtensionContext();
        if (!context) {
            return [];
        }
        return context.globalState.get('prologConfigBackups', []);
    }
    /**
     * Handle migration of different SWI-Prolog versions
     */
    async handleVersionMigration(oldVersion, newVersion) {
        const compatibilityIssues = [];
        const recommendations = [];
        try {
            const oldVersionParts = oldVersion.split('.').map(v => parseInt(v, 10));
            const newVersionParts = newVersion.split('.').map(v => parseInt(v, 10));
            // Check for major version changes
            if (oldVersionParts[0] !== newVersionParts[0]) {
                compatibilityIssues.push(`Major version change from ${oldVersionParts[0]} to ${newVersionParts[0]} may affect compatibility`);
                recommendations.push('Review your Prolog code for compatibility with the new major version');
            }
            // Check for specific version-related issues
            if (Array.isArray(oldVersionParts) &&
                Array.isArray(newVersionParts) &&
                oldVersionParts.length > 0 &&
                newVersionParts.length > 0 &&
                typeof oldVersionParts[0] === 'number' &&
                typeof newVersionParts[0] === 'number') {
                if (oldVersionParts[0] < 8 && newVersionParts[0] >= 8) {
                    recommendations.push('SWI-Prolog 8.x introduced new features and some syntax changes');
                    recommendations.push('Consider updating your code to use new string syntax if applicable');
                }
                if (oldVersionParts[0] < 9 && newVersionParts[0] >= 9) {
                    recommendations.push('SWI-Prolog 9.x has improved performance and new built-in predicates');
                }
            }
        }
        catch (_error) {
            compatibilityIssues.push('Unable to parse version numbers for compatibility check');
        }
        return {
            compatibilityIssues,
            recommendations,
        };
    }
    /**
     * Preserve user customizations during migration
     */
    async preserveUserCustomizations() {
        const preserved = [];
        const issues = [];
        try {
            const config = vscode.workspace.getConfiguration('prolog');
            // List of settings to preserve (non-path related)
            const settingsToPreserve = [
                'dialect',
                'linter.run',
                'linter.delay',
                'linter.enableMsgInOutput',
                'format.addSpace',
                'terminal.runtimeArgs',
                'telemetry.enabled',
            ];
            for (const setting of settingsToPreserve) {
                const value = config.get(setting);
                if (value !== undefined) {
                    preserved.push(`${setting}: ${JSON.stringify(value)}`);
                }
            }
        }
        catch (error) {
            issues.push(`Failed to preserve customizations: ${error}`);
        }
        return {
            preserved,
            issues,
        };
    }
    /**
     * Show migration dialog to user
     */
    async showMigrationDialog(migrationResult) {
        if (migrationResult.migrated) {
            const action = await vscode.window.showInformationMessage(`Configuration migrated successfully!\n\nOld path: ${migrationResult.oldPath}\nNew path: ${migrationResult.newPath}`, 'OK', 'Undo Migration');
            if (action === 'Undo Migration') {
                const restored = await this.restoreConfigurationBackup(0);
                if (restored) {
                    vscode.window.showInformationMessage('Configuration restored from backup');
                }
                else {
                    vscode.window.showErrorMessage('Failed to restore configuration backup');
                }
            }
        }
        else if (migrationResult.issues && migrationResult.issues.length > 0) {
            const issueMessage = migrationResult.issues.join('\n');
            await vscode.window.showWarningMessage(`Configuration migration failed:\n\n${issueMessage}`, 'OK');
        }
    }
    /**
     * Get common outdated paths that should be migrated
     */
    getCommonOutdatedPaths() {
        return [
            '/usr/local/bin/pl', // Old SWI-Prolog executable name
            '/usr/bin/pl', // Old SWI-Prolog executable name
            'C:\\pl\\bin\\pl.exe', // Old Windows path
            '/opt/pl/', // Old installation directory
        ];
    }
    /**
     * Get extension context (this would need to be set by the extension)
     */
    getExtensionContext() {
        // This would be set by the extension when initializing the migration system
        return global.prologExtensionContext;
    }
    /**
     * Set extension context for storage operations
     */
    setExtensionContext(context) {
        global.prologExtensionContext = context;
    }
    /**
     * Perform comprehensive migration check and handle user interaction
     */
    async performComprehensiveMigration() {
        try {
            // Check for outdated paths
            const outdatedCheck = await this.detectOutdatedPaths();
            if (outdatedCheck.hasOutdatedPaths) {
                const action = await vscode.window.showWarningMessage(`Outdated SWI-Prolog configuration detected.\n\nInvalid paths: ${outdatedCheck.invalidPaths.join(', ')}\n\nWould you like to automatically migrate to a valid installation?`, 'Migrate Now', 'Show Suggestions', 'Skip');
                switch (action) {
                    case 'Migrate Now': {
                        const migrationResult = await this.performMigration();
                        await this.showMigrationDialog(migrationResult);
                        break;
                    }
                    case 'Show Suggestions':
                        await this.showSuggestionsDialog(outdatedCheck.suggestions);
                        break;
                }
            }
        }
        catch (error) {
            console.error('Error during comprehensive migration:', error);
            vscode.window.showErrorMessage(`Migration check failed: ${error}`);
        }
    }
    /**
     * Show suggestions dialog for manual path selection
     */
    async showSuggestionsDialog(suggestions) {
        if (suggestions.length === 0) {
            vscode.window.showWarningMessage('No valid SWI-Prolog installations found for migration.');
            return;
        }
        const items = suggestions.map(suggestion => ({
            label: suggestion.path,
            description: suggestion.version ? `Version ${suggestion.version}` : 'Version unknown',
            path: suggestion.path,
        }));
        const selected = await vscode.window.showQuickPick(items, {
            placeHolder: 'Select a SWI-Prolog installation to use',
            ignoreFocusOut: true,
        });
        if (selected) {
            const config = vscode.workspace.getConfiguration('prolog');
            await this.createConfigurationBackup('manual_path_selection');
            await config.update('executablePath', selected.path, vscode.ConfigurationTarget.Global);
            vscode.window.showInformationMessage(`Configuration updated to use: ${selected.path}`);
        }
    }
}
exports.ConfigurationMigration = ConfigurationMigration;
//# sourceMappingURL=configurationMigration.js.map