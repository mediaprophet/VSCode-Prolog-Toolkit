import * as vscode from 'vscode';
export interface InstallationGuideOptions {
    showDetailedInstructions?: boolean;
    allowSkip?: boolean;
    context?: vscode.ExtensionContext;
}
export declare class InstallationGuide {
    private static instance;
    private installationChecker;
    private packageManager;
    private constructor();
    static getInstance(): InstallationGuide;
    /**
     * Show installation not found dialog with platform-specific guidance
     */
    showInstallationNotFoundDialog(options?: InstallationGuideOptions): Promise<string | undefined>;
    /**
     * Show comprehensive installation guide dialog
     */
    showInstallationGuideDialog(): Promise<void>;
    /**
     * Show path configuration dialog
     */
    showPathConfigurationDialog(): Promise<void>;
    /**
     * Show success dialog after successful installation/configuration
     */
    showSuccessDialog(path: string, version?: string): Promise<void>;
    /**
     * Run the setup wizard
     */
    runSetupWizard(): Promise<void>;
    /**
     * Show warning dialog when user chooses to skip installation
     */
    private showSkipWarningDialog;
    /**
     * Show feature test dialog
     */
    private showFeatureTestDialog;
    /**
     * Get platform display name
     */
    private getPlatformDisplayName;
    /**
     * Get installation information for platform
     */
    private getInstallationInfo;
    /**
     * Generate HTML for installation guide
     */
    private getInstallationGuideHtml;
    /**
     * Generate HTML for setup wizard
     */
    private getSetupWizardHtml;
    private performAutoDetection;
    private testSpecificPath;
    private savePathFromWizard;
    private runDiagnosticsFromWizard;
    private testInstallationAndReport;
    private testVersion;
    private testBasicQuery;
    private testFileLoading;
}
//# sourceMappingURL=installationGuide.d.ts.map