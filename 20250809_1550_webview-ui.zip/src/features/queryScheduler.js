"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.QueryScheduler = void 0;
const events_1 = require("events");
/**
 * Advanced query scheduling and queuing system
 */
class QueryScheduler extends events_1.EventEmitter {
    options;
    concurrencyManager;
    historyManager;
    scheduledQueries = new Map();
    schedulerInterval;
    dependencyGraph = new Map(); // queryId -> dependents
    conditionEvaluator = new Map();
    constructor(concurrencyManager, historyManager, options = {}) {
        super();
        this.concurrencyManager = concurrencyManager;
        this.historyManager = historyManager;
        this.options = {
            maxScheduledQueries: 1000,
            checkInterval: 1000, // Check every second
            enableRecurring: true,
            enableConditional: true,
            enableDependencies: true,
            defaultPriority: {
                level: 'normal',
                weight: 10
            },
            ...options,
        };
        this.startScheduler();
        this.setupConcurrencyManagerListeners();
    }
    /**
     * Schedule a query for execution
     */
    async scheduleQuery(id, cmd, params = {}, scheduleType = 'immediate', scheduleConfig = {}, priority = {}, metadata) {
        if (this.scheduledQueries.size >= this.options.maxScheduledQueries) {
            throw new Error('Maximum number of scheduled queries reached');
        }
        if (this.scheduledQueries.has(id)) {
            throw new Error(`Query with ID ${id} is already scheduled`);
        }
        const scheduledQuery = {
            id,
            cmd,
            params,
            scheduleType,
            scheduleConfig,
            priority: { ...this.options.defaultPriority, ...priority },
            createdAt: Date.now(),
            executionCount: 0,
            status: 'scheduled',
            ...(metadata !== undefined ? { metadata } : {}),
        };
        // Validate schedule configuration
        this.validateScheduleConfig(scheduledQuery);
        // Set up dependencies if specified
        if (scheduleConfig.dependencies && this.options.enableDependencies) {
            this.setupDependencies(id, scheduleConfig.dependencies);
        }
        // Set up condition evaluator if specified
        if (scheduleConfig.condition && this.options.enableConditional) {
            this.setupConditionEvaluator(id, scheduleConfig.condition);
        }
        this.scheduledQueries.set(id, scheduledQuery);
        this.emit('queryScheduled', scheduledQuery);
        console.log(`[QueryScheduler] Scheduled query ${id} (type: ${scheduleType})`);
        // If it's an immediate query, try to execute it right away
        if (scheduleType === 'immediate') {
            await this.tryExecuteQuery(scheduledQuery);
        }
    }
    /**
     * Cancel a scheduled query
     */
    async cancelScheduledQuery(queryId) {
        const scheduledQuery = this.scheduledQueries.get(queryId);
        if (!scheduledQuery) {
            return false;
        }
        // If the query is currently running, cancel it in the concurrency manager
        if (scheduledQuery.status === 'running') {
            this.concurrencyManager.cancelQuery(queryId);
        }
        scheduledQuery.status = 'cancelled';
        this.scheduledQueries.delete(queryId);
        // Clean up dependencies
        this.cleanupDependencies(queryId);
        this.emit('queryScheduleCancelled', queryId);
        console.log(`[QueryScheduler] Cancelled scheduled query ${queryId}`);
        return true;
    }
    /**
     * Pause a recurring query
     */
    async pauseRecurringQuery(queryId) {
        const scheduledQuery = this.scheduledQueries.get(queryId);
        if (!scheduledQuery || scheduledQuery.scheduleType !== 'recurring') {
            return false;
        }
        scheduledQuery.status = 'paused';
        this.emit('querySchedulePaused', queryId);
        console.log(`[QueryScheduler] Paused recurring query ${queryId}`);
        return true;
    }
    /**
     * Resume a paused recurring query
     */
    async resumeRecurringQuery(queryId) {
        const scheduledQuery = this.scheduledQueries.get(queryId);
        if (!scheduledQuery || scheduledQuery.status !== 'paused') {
            return false;
        }
        scheduledQuery.status = 'scheduled';
        this.emit('queryScheduleResumed', queryId);
        console.log(`[QueryScheduler] Resumed recurring query ${queryId}`);
        return true;
    }
    /**
     * Get all scheduled queries with optional filtering
     */
    getScheduledQueries(filter) {
        let queries = Array.from(this.scheduledQueries.values());
        if (filter?.status) {
            queries = queries.filter(q => filter.status.includes(q.status));
        }
        if (filter?.scheduleType) {
            queries = queries.filter(q => filter.scheduleType.includes(q.scheduleType));
        }
        if (filter?.tags) {
            queries = queries.filter(q => q.metadata?.tags && filter.tags.some(tag => q.metadata.tags.includes(tag)));
        }
        return queries.sort((a, b) => a.createdAt - b.createdAt);
    }
    /**
     * Get scheduler statistics
     */
    getStatistics() {
        const queries = Array.from(this.scheduledQueries.values());
        const nextExecution = queries
            .filter(q => q.scheduleType === 'delayed' && q.scheduleConfig.executeAt)
            .map(q => q.scheduleConfig.executeAt)
            .sort((a, b) => a - b)[0];
        return {
            totalScheduled: queries.length,
            activeScheduled: queries.filter(q => ['scheduled', 'running'].includes(q.status)).length,
            completedScheduled: queries.filter(q => q.status === 'completed').length,
            failedScheduled: queries.filter(q => q.status === 'failed').length,
            recurringQueries: queries.filter(q => q.scheduleType === 'recurring').length,
            conditionalQueries: queries.filter(q => q.scheduleType === 'conditional').length,
            dependentQueries: queries.filter(q => q.scheduleConfig.dependencies?.length).length,
            ...(nextExecution !== undefined ? { nextExecutionTime: nextExecution } : {}),
        };
    }
    /**
     * Register a custom condition evaluator
     */
    registerConditionEvaluator(queryId, evaluator) {
        this.conditionEvaluator.set(queryId, evaluator);
    }
    /**
     * Validate schedule configuration
     */
    validateScheduleConfig(query) {
        const { scheduleType, scheduleConfig } = query;
        switch (scheduleType) {
            case 'delayed': {
                if (!scheduleConfig.executeAt || scheduleConfig.executeAt <= Date.now()) {
                    throw new Error('Delayed queries must have a future executeAt timestamp');
                }
                break;
            }
            case 'recurring': {
                if (!this.options.enableRecurring) {
                    throw new Error('Recurring queries are disabled');
                }
                if (!scheduleConfig.interval || scheduleConfig.interval < 1000) {
                    throw new Error('Recurring queries must have an interval of at least 1000ms');
                }
                break;
            }
            case 'conditional': {
                if (!this.options.enableConditional) {
                    throw new Error('Conditional queries are disabled');
                }
                if (!scheduleConfig.condition) {
                    throw new Error('Conditional queries must have a condition');
                }
                break;
            }
        }
        if (scheduleConfig.dependencies && !this.options.enableDependencies) {
            throw new Error('Query dependencies are disabled');
        }
    }
    /**
     * Set up query dependencies
     */
    setupDependencies(queryId, dependencies) {
        for (const depId of dependencies) {
            if (!this.dependencyGraph.has(depId)) {
                this.dependencyGraph.set(depId, new Set());
            }
            this.dependencyGraph.get(depId).add(queryId);
        }
    }
    /**
     * Clean up dependencies for a query
     */
    cleanupDependencies(queryId) {
        // Remove this query as a dependent of others
        for (const [depId, dependents] of this.dependencyGraph.entries()) {
            dependents.delete(queryId);
            if (dependents.size === 0) {
                this.dependencyGraph.delete(depId);
            }
        }
        // Remove this query's own dependencies
        this.dependencyGraph.delete(queryId);
    }
    /**
     * Set up condition evaluator
     */
    setupConditionEvaluator(queryId, condition) {
        // Simple condition evaluator - in a real implementation, this would be more sophisticated
        try {
            const evaluator = new Function('return ' + condition);
            this.conditionEvaluator.set(queryId, evaluator);
        }
        catch (_error) {
            throw new Error(`Invalid condition expression: ${condition}`);
        }
    }
    /**
     * Start the scheduler loop
     */
    startScheduler() {
        this.schedulerInterval = setInterval(() => {
            this.processScheduledQueries();
        }, this.options.checkInterval);
    }
    /**
     * Process all scheduled queries
     */
    async processScheduledQueries() {
        const now = Date.now();
        const queries = Array.from(this.scheduledQueries.values());
        for (const query of queries) {
            if (query.status !== 'scheduled') {
                continue;
            }
            try {
                if (await this.shouldExecuteQuery(query, now)) {
                    await this.tryExecuteQuery(query);
                }
            }
            catch (error) {
                console.error(`[QueryScheduler] Error processing query ${query.id}:`, error);
                query.status = 'failed';
                this.emit('queryScheduleError', { queryId: query.id, error });
            }
        }
        // Clean up completed non-recurring queries
        this.cleanupCompletedQueries();
    }
    /**
     * Check if a query should be executed
     */
    async shouldExecuteQuery(query, now) {
        switch (query.scheduleType) {
            case 'immediate': {
                return true;
            }
            case 'delayed': {
                return query.scheduleConfig.executeAt <= now;
            }
            case 'recurring': {
                if (query.status === 'paused') {
                    return false;
                }
                if (!query.lastExecutedAt) {
                    return true; // First execution
                }
                const timeSinceLastExecution = now - query.lastExecutedAt;
                const shouldExecute = timeSinceLastExecution >= query.scheduleConfig.interval;
                // Check max executions limit
                if (shouldExecute && query.scheduleConfig.maxExecutions) {
                    return query.executionCount < query.scheduleConfig.maxExecutions;
                }
                return shouldExecute;
            }
            case 'conditional': {
                const evaluator = this.conditionEvaluator.get(query.id);
                if (!evaluator) {
                    return false;
                }
                try {
                    return evaluator();
                }
                catch (error) {
                    console.error(`[QueryScheduler] Condition evaluation error for ${query.id}:`, error);
                    return false;
                }
            }
            default: {
                return false;
            }
        }
    }
    /**
     * Try to execute a scheduled query
     */
    async tryExecuteQuery(query) {
        // Check dependencies
        if (query.scheduleConfig.dependencies &&
            !this.areDependenciesSatisfied(query.scheduleConfig.dependencies)) {
            return; // Dependencies not satisfied yet
        }
        try {
            query.status = 'running';
            query.lastExecutedAt = Date.now();
            query.executionCount++;
            this.emit('queryScheduleExecutionStarted', query);
            // Queue the query in the concurrency manager
            await this.concurrencyManager.queueQuery({
                id: query.id,
                cmd: query.cmd,
                params: query.params,
                priority: query.priority
            });
        }
        catch (error) {
            query.status = 'failed';
            this.emit('queryScheduleExecutionFailed', { query, error });
            console.error(`[QueryScheduler] Failed to execute query ${query.id}:`, error);
        }
    }
    /**
     * Check if all dependencies are satisfied
     */
    areDependenciesSatisfied(dependencies) {
        return dependencies.every(depId => {
            const depQuery = this.scheduledQueries.get(depId);
            return depQuery && depQuery.status === 'completed';
        });
    }
    /**
     * Set up listeners for concurrency manager events
     */
    setupConcurrencyManagerListeners() {
        this.concurrencyManager.on('queryCompleted', event => {
            this.handleQueryCompletion(event.queryId, event.success, event.error);
        });
        this.concurrencyManager.on('queryCancelled', event => {
            this.handleQueryCancellation(event.queryId);
        });
    }
    /**
     * Handle query completion from concurrency manager
     */
    handleQueryCompletion(queryId, success, error) {
        const query = this.scheduledQueries.get(queryId);
        if (!query) {
            return;
        }
        if (success) {
            // Handle recurring queries
            if (query.scheduleType === 'recurring') {
                // Check if we've reached max executions
                if (query.scheduleConfig.maxExecutions &&
                    query.executionCount >= query.scheduleConfig.maxExecutions) {
                    query.status = 'completed';
                    this.emit('queryScheduleCompleted', query);
                }
                else {
                    // Reset to scheduled for next execution
                    query.status = 'scheduled';
                    this.emit('queryScheduleRecurring', query);
                }
            }
            else {
                query.status = 'completed';
                this.emit('queryScheduleCompleted', query);
            }
            // Trigger dependent queries
            this.triggerDependentQueries(queryId);
        }
        else {
            query.status = 'failed';
            this.emit('queryScheduleFailed', { query, error });
        }
        // Add to history if history manager is available
        if (this.historyManager) {
            this.historyManager.addQuery({
                id: queryId,
                cmd: query.cmd,
                params: query.params,
                status: success ? 'completed' : 'error',
                startTime: query.lastExecutedAt,
                endTime: Date.now(),
                error: error,
                priority: query.priority.level,
                metadata: {
                    tags: query.metadata?.tags,
                    sessionId: 'scheduler',
                },
            });
        }
    }
    /**
     * Handle query cancellation from concurrency manager
     */
    handleQueryCancellation(queryId) {
        const query = this.scheduledQueries.get(queryId);
        if (query) {
            query.status = 'cancelled';
            this.emit('queryScheduleCancelled', queryId);
        }
    }
    /**
     * Trigger queries that depend on the completed query
     */
    triggerDependentQueries(completedQueryId) {
        const dependents = this.dependencyGraph.get(completedQueryId);
        if (!dependents) {
            return;
        }
        for (const dependentId of dependents) {
            const dependentQuery = this.scheduledQueries.get(dependentId);
            if (dependentQuery && dependentQuery.status === 'scheduled') {
                // Check if all dependencies are now satisfied
                if (this.areDependenciesSatisfied(dependentQuery.scheduleConfig.dependencies || [])) {
                    this.tryExecuteQuery(dependentQuery);
                }
            }
        }
    }
    /**
     * Clean up completed non-recurring queries
     */
    cleanupCompletedQueries() {
        const toRemove = [];
        for (const [id, query] of this.scheduledQueries.entries()) {
            if (['completed', 'failed', 'cancelled'].includes(query.status) &&
                query.scheduleType !== 'recurring') {
                // Keep completed queries for a while before cleanup
                const timeSinceCompletion = Date.now() - (query.lastExecutedAt || query.createdAt);
                if (timeSinceCompletion > 5 * 60 * 1000) {
                    // 5 minutes
                    toRemove.push(id);
                }
            }
        }
        for (const id of toRemove) {
            this.scheduledQueries.delete(id);
            this.cleanupDependencies(id);
            this.conditionEvaluator.delete(id);
        }
        if (toRemove.length > 0) {
            console.log(`[QueryScheduler] Cleaned up ${toRemove.length} completed queries`);
        }
    }
    /**
     * Dispose of the scheduler
     */
    dispose() {
        if (this.schedulerInterval) {
            clearInterval(this.schedulerInterval);
        }
        // Cancel all scheduled queries
        for (const [id] of this.scheduledQueries.entries()) {
            this.cancelScheduledQuery(id);
        }
        this.scheduledQueries.clear();
        this.dependencyGraph.clear();
        this.conditionEvaluator.clear();
        this.removeAllListeners();
        console.log('[QueryScheduler] Disposed');
    }
}
exports.QueryScheduler = QueryScheduler;
//# sourceMappingURL=queryScheduler.js.map