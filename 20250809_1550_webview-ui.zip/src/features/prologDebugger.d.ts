import { DebugProtocol } from '@vscode/debugprotocol';
import { EventEmitter } from 'events';
import { PrologDebugSession } from './prologDebugSession';
export interface ITraceCmds {
    continue: string[2];
    stepover: string[2];
    stepinto: string[2];
    stepout: string[2];
}
export interface LaunchRequestArguments extends DebugProtocol.LaunchRequestArguments {
    program?: string;
    args?: string[];
    cwd: string;
    runtimeExecutable?: string;
    runtimeArgs?: string[];
    env?: {
        [key: string]: string;
    };
    startupQuery?: string;
    stopOnEntry?: boolean;
    terminalDebuggerPort?: number;
    console?: string;
    traceCmds?: ITraceCmds;
}
export interface ITraceCmds {
    Run: string[];
    Stepin: string[];
    Stepover: string[];
    Stop: string[];
}
export interface IBreakPoint {
    sourceFile: string;
    line: number;
    id?: number;
}
export declare class PrologDebugger extends EventEmitter {
    private _prologProc;
    private _breakpoints;
    private _launchRequestArguments;
    private _debugSession;
    private _bpResponse;
    private _fbpResponse;
    private _soureLineLocations;
    constructor(launchRequestArguments: LaunchRequestArguments, debugSession: PrologDebugSession);
    private getSourceLineLocations;
    private fromStartCharToLineChar;
    private handleOutput;
    query(goal: string): void;
    private killPrologProc;
    private filterOffOutput;
    get pid(): number;
    initPrologDebugger(): void;
    private createPrologProc;
    private consult;
    setBreakpoints(breakpoints: DebugProtocol.SetBreakpointsArguments, bpResponse: DebugProtocol.SetBreakpointsResponse): void;
    setFunctionBreakpoints(args: DebugProtocol.SetFunctionBreakpointsArguments, response: DebugProtocol.SetFunctionBreakpointsResponse): void;
    startup(goal: string): void;
    dispose(): void;
}
//# sourceMappingURL=prologDebugger.d.ts.map