"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.defaultUIHandler = void 0;
exports.defaultUIHandler = {
    showErrorMessage: async (message, ...items) => {
        console.error(message);
        return undefined;
    },
    executeCommand: async (command, ...rest) => {
        console.log(`Command execution requested: ${command}`);
        return undefined;
    },
};
//# sourceMappingURL=uiHandler.js.map