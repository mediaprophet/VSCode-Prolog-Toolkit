"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.LocalizationManager = void 0;
exports.initializeLocalization = initializeLocalization;
exports.getLocalizationManager = getLocalizationManager;
exports.t = t;
exports.tp = tp;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
class LocalizationManager {
    currentLocale = 'en';
    fallbackLocale = 'en';
    strings = new Map();
    availableLocales = new Map();
    extensionPath;
    constructor(extensionPath) {
        this.extensionPath = extensionPath;
        this.initializeAvailableLocales();
        this.loadDefaultStrings();
    }
    /**
     * Initialize available locales
     */
    initializeAvailableLocales() {
        this.availableLocales.set('en', {
            code: 'en',
            name: 'English',
            nativeName: 'English',
            direction: 'ltr',
        });
        this.availableLocales.set('es', {
            code: 'es',
            name: 'Spanish',
            nativeName: 'Español',
            direction: 'ltr',
        });
        this.availableLocales.set('fr', {
            code: 'fr',
            name: 'French',
            nativeName: 'Français',
            direction: 'ltr',
        });
        this.availableLocales.set('de', {
            code: 'de',
            name: 'German',
            nativeName: 'Deutsch',
            direction: 'ltr',
        });
        this.availableLocales.set('it', {
            code: 'it',
            name: 'Italian',
            nativeName: 'Italiano',
            direction: 'ltr',
        });
        this.availableLocales.set('pt', {
            code: 'pt',
            name: 'Portuguese',
            nativeName: 'Português',
            direction: 'ltr',
        });
        this.availableLocales.set('ja', {
            code: 'ja',
            name: 'Japanese',
            nativeName: '日本語',
            direction: 'ltr',
        });
        this.availableLocales.set('zh', {
            code: 'zh',
            name: 'Chinese',
            nativeName: '中文',
            direction: 'ltr',
        });
    }
    /**
     * Load default English strings
     */
    loadDefaultStrings() {
        const defaultStrings = {
            // General UI
            general: {
                yes: 'Yes',
                no: 'No',
                ok: 'OK',
                cancel: 'Cancel',
                error: 'Error',
                warning: 'Warning',
                info: 'Information',
                success: 'Success',
                loading: 'Loading...',
                processing: 'Processing...',
                complete: 'Complete',
                failed: 'Failed',
            },
            // Query results
            query: {
                succeeded: 'Query succeeded',
                failed: 'Query failed',
                error: 'Query error',
                noResults: 'No results found',
                multipleResults: 'Multiple results found',
                solution: 'Solution',
                solutions: 'solutions',
                variable: 'Variable',
                variables: 'variables',
                binding: 'binding',
                bindings: 'bindings',
                noVariables: 'no variables',
                noBindings: 'no variable bindings',
                streamingResults: 'Streaming results',
                streamingComplete: 'Streaming complete',
                loadingMore: 'Loading more results...',
                outputTruncated: '... (output truncated)',
            },
            // Package management
            packages: {
                availablePacks: 'Available Packs',
                installedPacks: 'Installed Packs',
                outdatedPacks: 'Outdated Packs',
                packInstalled: 'Pack installed successfully',
                packUninstalled: 'Pack uninstalled successfully',
                packUpdated: 'Pack updated successfully',
                packNotFound: 'Pack not found',
                installationFailed: 'Installation failed',
                uninstallationFailed: 'Uninstallation failed',
                updateFailed: 'Update failed',
                searchResults: 'Search Results',
                noPacksFound: 'No packs found',
                packInfo: 'Pack Information',
                dependencies: 'Dependencies',
                conflicts: 'Conflicts',
                securityWarning: 'Security Warning',
                untrustedSource: 'This pack is from an untrusted source',
                proceedAnyway: 'Install Anyway',
                configuredServers: 'Configured Pack Servers',
                addServer: 'Add Server',
                removeServer: 'Remove Server',
                defaultServer: 'default',
            },
            // Error messages
            errors: {
                syntaxError: 'Syntax error in Prolog code',
                runtimeError: 'Runtime error occurred',
                systemError: 'System error occurred',
                networkError: 'Network error occurred',
                permissionError: 'Permission denied',
                resourceError: 'Resource limit exceeded',
                backendNotAvailable: 'Prolog backend is not available',
                backendTimeout: 'Backend request timed out',
                connectionFailed: 'Failed to connect to Prolog server',
                invalidCommand: 'Invalid or unrecognized command',
                missingArgument: 'Required argument is missing',
                invalidFilePath: 'Invalid file path specified',
                unknownError: 'An unknown error occurred',
            },
            // Error suggestions
            suggestions: {
                checkSyntax: 'Check your Prolog syntax for missing periods, unmatched parentheses, or incorrect operators',
                checkTypes: 'Check the types of your arguments using var/1, atom/1, number/1, etc.',
                checkPermissions: 'Check file permissions or predicate access rights',
                restartBackend: 'Try restarting the extension or check your SWI-Prolog installation',
                checkConnection: 'Check your internet connection and proxy settings',
                checkCommand: 'Check the command syntax. Use /help to see available commands',
                checkFilePath: 'Check if the file path exists and is accessible',
                simplifyQuery: 'Try simplifying your query or using call_with_time_limit/2',
                checkInstallation: 'Check your SWI-Prolog installation and version compatibility',
            },
            // Help system
            help: {
                helpFor: 'Help for',
                availableCommands: 'Available Commands',
                usage: 'Usage',
                examples: 'Examples',
                description: 'Description',
                parameters: 'Parameters',
                options: 'Options',
                seeAlso: 'See Also',
                documentation: 'Documentation',
                noHelpAvailable: 'No help available for this topic',
            },
            // Commands
            commands: {
                query: 'Execute a Prolog query',
                consult: 'Load a Prolog file',
                help: 'Get help on predicates or commands',
                pack: 'Manage Prolog packages',
                list: 'List items',
                install: 'Install a package',
                uninstall: 'Uninstall a package',
                update: 'Update packages',
                search: 'Search for packages',
                info: 'Get information about a package',
            },
            // Status messages
            status: {
                starting: 'Starting Prolog backend...',
                ready: 'Prolog backend is ready',
                stopping: 'Stopping Prolog backend...',
                stopped: 'Prolog backend stopped',
                restarting: 'Restarting Prolog backend...',
                connecting: 'Connecting to Prolog server...',
                connected: 'Connected to Prolog server',
                disconnected: 'Disconnected from Prolog server',
            },
            // Progress messages
            progress: {
                processing: 'Processing request...',
                loading: 'Loading data...',
                saving: 'Saving changes...',
                installing: 'Installing package...',
                uninstalling: 'Uninstalling package...',
                updating: 'Updating package...',
                searching: 'Searching packages...',
                analyzing: 'Analyzing results...',
            },
        };
        this.strings.set('en', defaultStrings);
    }
    /**
     * Set the current locale
     */
    async setLocale(locale) {
        if (!this.availableLocales.has(locale)) {
            console.warn(`Locale '${locale}' is not available`);
            return false;
        }
        this.currentLocale = locale;
        // Load locale strings if not already loaded
        if (!this.strings.has(locale) && locale !== 'en') {
            await this.loadLocaleStrings(locale);
        }
        return true;
    }
    /**
     * Load strings for a specific locale
     */
    async loadLocaleStrings(locale) {
        try {
            const localeFile = path.join(this.extensionPath, 'locales', `${locale}.json`);
            if (fs.existsSync(localeFile)) {
                const content = fs.readFileSync(localeFile, 'utf8');
                const strings = JSON.parse(content);
                this.strings.set(locale, strings);
            }
            else {
                console.warn(`Locale file not found: ${localeFile}`);
            }
        }
        catch (error) {
            console.error(`Failed to load locale strings for '${locale}':`, error);
        }
    }
    /**
     * Get localized string
     */
    getString(key, ...args) {
        const value = this.getStringValue(key, this.currentLocale) ||
            this.getStringValue(key, this.fallbackLocale) ||
            key;
        // Simple placeholder replacement
        if (args.length > 0) {
            return this.formatString(value, args);
        }
        return value;
    }
    /**
     * Get string value from nested object
     */
    getStringValue(key, locale) {
        const strings = this.strings.get(locale);
        if (!strings) {
            return undefined;
        }
        const keys = key.split('.');
        let current = strings;
        for (const k of keys) {
            if (current && typeof current === 'object' && k in current) {
                current = current[k];
            }
            else {
                return undefined;
            }
        }
        return typeof current === 'string' ? current : undefined;
    }
    /**
     * Format string with arguments
     */
    formatString(template, args) {
        return template.replace(/\{(\d+)\}/g, (match, index) => {
            const argIndex = parseInt(index, 10);
            return argIndex < args.length ? String(args[argIndex]) : match;
        });
    }
    /**
     * Get current locale
     */
    getCurrentLocale() {
        return this.currentLocale;
    }
    /**
     * Get available locales
     */
    getAvailableLocales() {
        return Array.from(this.availableLocales.values());
    }
    /**
     * Get locale info
     */
    getLocaleInfo(locale) {
        return this.availableLocales.get(locale);
    }
    /**
     * Check if locale is available
     */
    isLocaleAvailable(locale) {
        return this.availableLocales.has(locale);
    }
    /**
     * Get localized error message
     */
    getErrorMessage(errorCode, context) {
        const key = `errors.${errorCode.toLowerCase()}`;
        let message = this.getString(key);
        if (message === key) {
            // Fallback to generic error message
            message = this.getString('errors.unknownError');
        }
        if (context) {
            message = this.formatString(message, [context]);
        }
        return message;
    }
    /**
     * Get localized suggestion
     */
    getSuggestion(suggestionCode) {
        const key = `suggestions.${suggestionCode.toLowerCase()}`;
        return this.getString(key);
    }
    /**
     * Get pluralized string
     */
    getPlural(key, count, ...args) {
        const singularKey = `${key}`;
        const pluralKey = `${key}s`;
        const selectedKey = count === 1 ? singularKey : pluralKey;
        return this.getString(selectedKey, count, ...args);
    }
    /**
     * Format number according to locale
     */
    formatNumber(number) {
        try {
            return new Intl.NumberFormat(this.currentLocale).format(number);
        }
        catch {
            return number.toString();
        }
    }
    /**
     * Format date according to locale
     */
    formatDate(date) {
        try {
            return new Intl.DateTimeFormat(this.currentLocale).format(date);
        }
        catch {
            return date.toISOString();
        }
    }
    /**
     * Get text direction for current locale
     */
    getTextDirection() {
        const localeInfo = this.availableLocales.get(this.currentLocale);
        return localeInfo?.direction || 'ltr';
    }
    /**
     * Add custom strings for a locale
     */
    addStrings(locale, strings) {
        const existing = this.strings.get(locale) || {};
        const merged = this.mergeStrings(existing, strings);
        this.strings.set(locale, merged);
    }
    /**
     * Merge string objects recursively
     */
    mergeStrings(target, source) {
        const result = { ...target };
        for (const [key, value] of Object.entries(source)) {
            if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
                result[key] = this.mergeStrings(result[key] || {}, value);
            }
            else {
                result[key] = value;
            }
        }
        return result;
    }
    /**
     * Export strings for a locale (for translation)
     */
    exportStrings(locale) {
        return this.strings.get(locale);
    }
    /**
     * Get missing translations for a locale
     */
    getMissingTranslations(locale) {
        const baseStrings = this.strings.get(this.fallbackLocale);
        const localeStrings = this.strings.get(locale);
        if (!baseStrings || !localeStrings) {
            return [];
        }
        const missing = [];
        this.findMissingKeys(baseStrings, localeStrings, '', missing);
        return missing;
    }
    /**
     * Find missing keys recursively
     */
    findMissingKeys(base, target, prefix, missing) {
        for (const [key, value] of Object.entries(base)) {
            const fullKey = prefix ? `${prefix}.${key}` : key;
            if (!(key in target)) {
                missing.push(fullKey);
            }
            else if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
                if (typeof target[key] === 'object' &&
                    target[key] !== null &&
                    !Array.isArray(target[key])) {
                    this.findMissingKeys(value, target[key], fullKey, missing);
                }
                else {
                    missing.push(fullKey);
                }
            }
        }
    }
}
exports.LocalizationManager = LocalizationManager;
/**
 * Global localization manager instance
 */
let globalLocalizationManager;
/**
 * Initialize localization manager
 */
function initializeLocalization(extensionPath) {
    globalLocalizationManager = new LocalizationManager(extensionPath);
    return globalLocalizationManager;
}
/**
 * Get global localization manager
 */
function getLocalizationManager() {
    if (!globalLocalizationManager) {
        throw new Error('Localization manager not initialized');
    }
    return globalLocalizationManager;
}
/**
 * Convenience function to get localized string
 */
function t(key, ...args) {
    return getLocalizationManager().getString(key, ...args);
}
/**
 * Convenience function to get pluralized string
 */
function tp(key, count, ...args) {
    return getLocalizationManager().getPlural(key, count, ...args);
}
//# sourceMappingURL=localization.js.map