export interface LocalizationStrings {
    [key: string]: string | LocalizationStrings;
}
export interface LocaleInfo {
    code: string;
    name: string;
    nativeName: string;
    direction: 'ltr' | 'rtl';
}
export declare class LocalizationManager {
    private currentLocale;
    private fallbackLocale;
    private strings;
    private availableLocales;
    private extensionPath;
    constructor(extensionPath: string);
    /**
     * Initialize available locales
     */
    private initializeAvailableLocales;
    /**
     * Load default English strings
     */
    private loadDefaultStrings;
    /**
     * Set the current locale
     */
    setLocale(locale: string): Promise<boolean>;
    /**
     * Load strings for a specific locale
     */
    private loadLocaleStrings;
    /**
     * Get localized string
     */
    getString(key: string, ...args: any[]): string;
    /**
     * Get string value from nested object
     */
    private getStringValue;
    /**
     * Format string with arguments
     */
    private formatString;
    /**
     * Get current locale
     */
    getCurrentLocale(): string;
    /**
     * Get available locales
     */
    getAvailableLocales(): LocaleInfo[];
    /**
     * Get locale info
     */
    getLocaleInfo(locale: string): LocaleInfo | undefined;
    /**
     * Check if locale is available
     */
    isLocaleAvailable(locale: string): boolean;
    /**
     * Get localized error message
     */
    getErrorMessage(errorCode: string, context?: any): string;
    /**
     * Get localized suggestion
     */
    getSuggestion(suggestionCode: string): string;
    /**
     * Get pluralized string
     */
    getPlural(key: string, count: number, ...args: any[]): string;
    /**
     * Format number according to locale
     */
    formatNumber(number: number): string;
    /**
     * Format date according to locale
     */
    formatDate(date: Date): string;
    /**
     * Get text direction for current locale
     */
    getTextDirection(): 'ltr' | 'rtl';
    /**
     * Add custom strings for a locale
     */
    addStrings(locale: string, strings: LocalizationStrings): void;
    /**
     * Merge string objects recursively
     */
    private mergeStrings;
    /**
     * Export strings for a locale (for translation)
     */
    exportStrings(locale: string): LocalizationStrings | undefined;
    /**
     * Get missing translations for a locale
     */
    getMissingTranslations(locale: string): string[];
    /**
     * Find missing keys recursively
     */
    private findMissingKeys;
}
/**
 * Initialize localization manager
 */
export declare function initializeLocalization(extensionPath: string): LocalizationManager;
/**
 * Get global localization manager
 */
export declare function getLocalizationManager(): LocalizationManager;
/**
 * Convenience function to get localized string
 */
export declare function t(key: string, ...args: any[]): string;
/**
 * Convenience function to get pluralized string
 */
export declare function tp(key: string, count: number, ...args: any[]): string;
//# sourceMappingURL=localization.d.ts.map