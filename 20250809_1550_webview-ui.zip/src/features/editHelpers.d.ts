import { Disposable } from 'vscode';
export declare function loadEditHelpers(subscriptions: Disposable[]): void;
//# sourceMappingURL=editHelpers.d.ts.map