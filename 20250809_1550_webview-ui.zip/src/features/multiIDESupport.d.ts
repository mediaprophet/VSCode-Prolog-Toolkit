/**
 * Multi-IDE Support for Prolog LSP
 * Provides configuration and setup for various IDEs and editors
 */
export declare class MultiIDESupport {
    private static readonly SUPPORTED_IDES;
    /**
     * Generate LSP configuration files for different IDEs
     */
    static generateIDEConfigurations(workspaceRoot: string): Promise<void>;
    private static generateVSCodeConfig;
    private static generateCocNvimConfig;
    private static generateNeovimConfig;
    private static generateVimLspConfig;
    private static generateEmacsConfig;
    private static generateSublimeConfig;
    private static generateIntelliJConfig;
    private static generateEclipseConfig;
    private static generateTheiaConfig;
    private static generateSetupScripts;
    private static generateIDEDocumentation;
    /**
     * Detect available IDEs on the system
     */
    static detectAvailableIDEs(): Promise<string[]>;
    /**
     * Generate IDE-specific launch configurations
     */
    static generateLaunchConfigurations(workspaceRoot: string): void;
}
//# sourceMappingURL=multiIDESupport.d.ts.map