import { Router, Request } from 'express';
import { PrologBackend } from '../prologBackend';
export interface AuthenticatedRequest extends Request {
    user?: {
        id: string;
        role: string;
        permissions: string[];
    };
}
/**
 * Create API routes for Prolog operations
 */
export declare function apiRoutes(prologBackend: PrologBackend): Router;
//# sourceMappingURL=apiRoutes.d.ts.map