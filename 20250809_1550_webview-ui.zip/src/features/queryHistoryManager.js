"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Persistent query history storage and management system
 */
/**
 * DEPRECATED: All logic has been migrated to modular orchestrator and modules.
 * This file now only exports types and interfaces for backward compatibility.
 * Use QueryHistoryOrchestrator and related modules instead.
 */
//# sourceMappingURL=queryHistoryManager.js.map