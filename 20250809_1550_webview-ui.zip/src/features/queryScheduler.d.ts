import { EventEmitter } from 'events';
import { QueryPriority } from '../types/backend';
import { ConcurrencyManagerOrchestrator } from './concurrencyManager/ConcurrencyManagerOrchestrator';
import { QueryHistoryOrchestrator } from './queryHistoryManager/QueryHistoryOrchestrator';
export interface ScheduledQuery {
    id: string;
    cmd: string;
    params: Record<string, unknown>;
    scheduleType: 'immediate' | 'delayed' | 'recurring' | 'conditional';
    scheduleConfig: {
        executeAt?: number;
        interval?: number;
        maxExecutions?: number;
        condition?: string;
        dependencies?: string[];
    };
    priority: QueryPriority;
    createdAt: number;
    lastExecutedAt?: number;
    executionCount: number;
    status: 'scheduled' | 'running' | 'completed' | 'failed' | 'cancelled' | 'paused';
    metadata?: {
        tags?: string[];
        description?: string;
        createdBy?: string;
    };
}
export interface SchedulerOptions {
    maxScheduledQueries: number;
    checkInterval: number;
    enableRecurring: boolean;
    enableConditional: boolean;
    enableDependencies: boolean;
    defaultPriority: QueryPriority;
}
export interface SchedulerStats {
    totalScheduled: number;
    activeScheduled: number;
    completedScheduled: number;
    failedScheduled: number;
    recurringQueries: number;
    conditionalQueries: number;
    dependentQueries: number;
    nextExecutionTime?: number;
}
/**
 * Advanced query scheduling and queuing system
 */
export declare class QueryScheduler extends EventEmitter {
    private options;
    private concurrencyManager;
    private historyManager;
    private scheduledQueries;
    private schedulerInterval?;
    private dependencyGraph;
    private conditionEvaluator;
    constructor(concurrencyManager: ConcurrencyManagerOrchestrator, historyManager?: QueryHistoryOrchestrator, options?: Partial<SchedulerOptions>);
    /**
     * Schedule a query for execution
     */
    scheduleQuery(id: string, cmd: string, params?: Record<string, unknown>, scheduleType?: ScheduledQuery['scheduleType'], scheduleConfig?: ScheduledQuery['scheduleConfig'], priority?: Partial<QueryPriority>, metadata?: ScheduledQuery['metadata']): Promise<void>;
    /**
     * Cancel a scheduled query
     */
    cancelScheduledQuery(queryId: string): Promise<boolean>;
    /**
     * Pause a recurring query
     */
    pauseRecurringQuery(queryId: string): Promise<boolean>;
    /**
     * Resume a paused recurring query
     */
    resumeRecurringQuery(queryId: string): Promise<boolean>;
    /**
     * Get all scheduled queries with optional filtering
     */
    getScheduledQueries(filter?: {
        status?: ScheduledQuery['status'][];
        scheduleType?: ScheduledQuery['scheduleType'][];
        tags?: string[];
    }): ScheduledQuery[];
    /**
     * Get scheduler statistics
     */
    getStatistics(): SchedulerStats;
    /**
     * Register a custom condition evaluator
     */
    registerConditionEvaluator(queryId: string, evaluator: () => boolean): void;
    /**
     * Validate schedule configuration
     */
    private validateScheduleConfig;
    /**
     * Set up query dependencies
     */
    private setupDependencies;
    /**
     * Clean up dependencies for a query
     */
    private cleanupDependencies;
    /**
     * Set up condition evaluator
     */
    private setupConditionEvaluator;
    /**
     * Start the scheduler loop
     */
    private startScheduler;
    /**
     * Process all scheduled queries
     */
    private processScheduledQueries;
    /**
     * Check if a query should be executed
     */
    private shouldExecuteQuery;
    /**
     * Try to execute a scheduled query
     */
    private tryExecuteQuery;
    /**
     * Check if all dependencies are satisfied
     */
    private areDependenciesSatisfied;
    /**
     * Set up listeners for concurrency manager events
     */
    private setupConcurrencyManagerListeners;
    /**
     * Handle query completion from concurrency manager
     */
    private handleQueryCompletion;
    /**
     * Handle query cancellation from concurrency manager
     */
    private handleQueryCancellation;
    /**
     * Trigger queries that depend on the completed query
     */
    private triggerDependentQueries;
    /**
     * Clean up completed non-recurring queries
     */
    private cleanupCompletedQueries;
    /**
     * Dispose of the scheduler
     */
    dispose(): void;
}
//# sourceMappingURL=queryScheduler.d.ts.map