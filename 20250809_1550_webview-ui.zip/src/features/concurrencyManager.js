"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Advanced concurrency manager with resource quotas and priority queues
 */
/**
 * DEPRECATED: All logic has been migrated to modular orchestrator and modules.
 * This file now only exports types and interfaces for backward compatibility.
 * Use ConcurrencyManagerOrchestrator and related modules instead.
 */
//# sourceMappingURL=concurrencyManager.js.map