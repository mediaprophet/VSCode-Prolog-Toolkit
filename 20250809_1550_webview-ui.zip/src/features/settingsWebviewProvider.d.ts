import * as vscode from 'vscode';
export declare class SettingsWebviewProvider implements vscode.WebviewViewProvider {
    private readonly _extensionUri;
    static readonly viewType = "prologSettings";
    private _view?;
    private installationChecker;
    private installationGuide;
    constructor(_extensionUri: vscode.Uri);
    resolveWebviewView(webviewView: vscode.WebviewView, context: vscode.WebviewViewResolveContext, _token: vscode.CancellationToken): void;
    private _updateSetting;
    private _resetSettings;
    private _exportSettings;
    private _importSettings;
    private _validateSetting;
    private _sendCurrentSettings;
    private _checkInstallation;
    private _autoDetectPath;
    private _testInstallation;
    private _getHtmlForWebview;
}
//# sourceMappingURL=settingsWebviewProvider.d.ts.map