import type { ExecutableDetectionResult } from '../utils/executableFinder.js';
export interface InstallationStatus {
    isInstalled: boolean;
    path?: string;
    version?: string;
    issues?: string[];
    permissions?: {
        readable: boolean;
        writable: boolean;
        executable: boolean;
    };
    detectionMethod?: string;
    platformInfo?: {
        platform: string;
        architecture: string;
        osVersion: string;
    };
}
export declare class InstallationChecker {
    /**
     * Return a list of common SWI-Prolog installation paths for the current OS.
     * This is used for migration and validation of outdated configurations.
     */
    static detectCommonInstallPaths(): string[];
    private static instance;
    private executableFinder;
    static getInstance(): InstallationChecker;
    constructor();
    /**
     * Check SWI-Prolog installation status.
     * This is the primary method for verifying the SWI-Prolog installation.
     */
    checkSwiplInstallation(): Promise<InstallationStatus>;
    /**
     * Find SWI-Prolog executable using the ExecutableFinder.
     */
    findSwiplExecutable(): Promise<string | null>;
    /**
     * Validate that a given path points to a valid SWI-Prolog executable.
     * Delegates to ExecutableFinder.
     */
    validateSwiplPath(execPath: string): Promise<boolean>;
    /**
     * Get detailed validation information for an executable path.
     * Delegates to ExecutableFinder.
     */
    validateSwiplPathDetailed(execPath: string): Promise<ExecutableDetectionResult>;
    /**
     * Get SWI-Prolog version from executable.
     * This is a convenience method that delegates to ExecutableFinder.
     */
    getSwiplVersion(execPath: string): Promise<string | null>;
    /**
     * Check if the current configuration is valid and update if needed
     */
    validateAndUpdateConfiguration(): Promise<{
        updated: boolean;
        oldPath?: string;
        newPath?: string;
    }>;
    /**
     * Get detailed system information for troubleshooting
     */
    getSystemInfo(): {
        platform: string;
        arch: string;
        pathEnv: string[];
    };
    /**
     * Check if SWI-Prolog version meets minimum requirements.
     * This logic is now more robust and handles different version formats.
     */
    checkVersionCompatibility(version: string): {
        compatible: boolean;
        message?: string;
    };
    /**
     * Perform comprehensive installation diagnostics.
     * This is the main entry point for gathering detailed troubleshooting information.
     */
    performDiagnostics(): Promise<{
        installation: InstallationStatus;
        system: {
            platform: string;
            arch: string;
            pathEnv: string[];
            platformInfo: any;
        };
        configuration: {
            current: string;
            valid: boolean;
            detailedValidation?: ExecutableDetectionResult;
        };
        recommendations: string[];
        permissionIssues?: string[];
    }>;
}
//# sourceMappingURL=installationChecker.d.ts.map