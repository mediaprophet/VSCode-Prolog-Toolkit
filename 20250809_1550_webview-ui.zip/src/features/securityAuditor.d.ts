import { EventEmitter } from 'events';
export interface SecurityEvent {
    id: string;
    type: 'authentication_success' | 'authentication_failure' | 'authorization_denied' | 'quota_exceeded' | 'suspicious_query_blocked' | 'rate_limit_exceeded' | 'resource_limit_exceeded' | 'dangerous_predicate_blocked' | 'sandbox_violation';
    userId?: string;
    userRole?: string;
    ipAddress?: string;
    userAgent?: string;
    timestamp: Date;
    severity: 'low' | 'medium' | 'high' | 'critical';
    message: string;
    details: {
        query?: string;
        endpoint?: string;
        resource?: string;
        limit?: number;
        actual?: number;
        predicate?: string;
        violation?: string;
        [key: string]: any;
    };
    metadata?: {
        sessionId?: string;
        requestId?: string;
        duration?: number;
        [key: string]: any;
    };
}
export interface SecurityAlert {
    id: string;
    type: 'threshold_exceeded' | 'pattern_detected' | 'anomaly_detected';
    severity: 'medium' | 'high' | 'critical';
    message: string;
    events: SecurityEvent[];
    timestamp: Date;
    acknowledged: boolean;
    acknowledgedBy?: string;
    acknowledgedAt?: Date;
}
export interface AuditConfig {
    enabled: boolean;
    logLevel: 'none' | 'basic' | 'detailed';
    includeResults: boolean;
    retention: number;
    format: 'json' | 'text';
    outputPath: string;
    alerting: {
        enabled: boolean;
        thresholds: {
            failed_auth_attempts: number;
            quota_violations: number;
            blocked_queries: number;
            time_window: number;
        };
        notifications: ('log' | 'webhook' | 'email')[];
        webhookUrl?: string;
        emailConfig?: {
            smtp: string;
            from: string;
            to: string[];
        };
    };
}
/**
 * Security Auditor for comprehensive security event logging and monitoring
 */
export declare class SecurityAuditor extends EventEmitter {
    private config;
    private events;
    private alerts;
    private eventCounts;
    private logStream?;
    constructor(config: AuditConfig);
    /**
     * Log a security event
     */
    logSecurityEvent(event: Omit<SecurityEvent, 'id' | 'timestamp'>): void;
    /**
     * Log authentication success
     */
    logAuthenticationSuccess(userId: string, userRole: string, ipAddress?: string, userAgent?: string): void;
    /**
     * Log authentication failure
     */
    logAuthenticationFailure(reason: string, ipAddress?: string, userAgent?: string, details?: any): void;
    /**
     * Log authorization denied
     */
    logAuthorizationDenied(userId: string, resource: string, requiredPermission: string, ipAddress?: string): void;
    /**
     * Log quota exceeded
     */
    logQuotaExceeded(userId: string, quotaType: string, limit: number, actual: number): void;
    /**
     * Log suspicious query blocked
     */
    logSuspiciousQueryBlocked(userId: string, query: string, reason: string, predicate?: string): void;
    /**
     * Log rate limit exceeded
     */
    logRateLimitExceeded(userId: string, endpoint: string, limit: number, ipAddress?: string): void;
    /**
     * Log resource limit exceeded
     */
    logResourceLimitExceeded(userId: string, resource: string, limit: number, actual: number): void;
    /**
     * Log dangerous predicate blocked
     */
    logDangerousPredicateBlocked(userId: string, predicate: string, query: string): void;
    /**
     * Log sandbox violation
     */
    logSandboxViolation(userId: string, violation: string, query: string): void;
    /**
     * Get security events with filtering
     */
    getSecurityEvents(filter?: {
        type?: SecurityEvent['type'];
        userId?: string;
        severity?: SecurityEvent['severity'];
        startDate?: Date;
        endDate?: Date;
        limit?: number;
        offset?: number;
    }): {
        events: SecurityEvent[];
        total: number;
    };
    /**
     * Get security alerts
     */
    getSecurityAlerts(filter?: {
        acknowledged?: boolean;
        severity?: SecurityAlert['severity'];
        limit?: number;
    }): SecurityAlert[];
    /**
     * Acknowledge a security alert
     */
    acknowledgeAlert(alertId: string, acknowledgedBy: string): boolean;
    /**
     * Get security statistics
     */
    getSecurityStatistics(timeWindow?: number): {
        totalEvents: number;
        eventsByType: {
            [type: string]: number;
        };
        eventsBySeverity: {
            [severity: string]: number;
        };
        topUsers: {
            userId: string;
            eventCount: number;
        }[];
        alertsGenerated: number;
        unacknowledgedAlerts: number;
    };
    /**
     * Export security events to file
     */
    exportEvents(filePath: string, filter?: Parameters<typeof this.getSecurityEvents>[0]): Promise<void>;
    /**
     * Setup log stream for file output
     */
    private setupLogStream;
    /**
     * Write event to log
     */
    private writeEventLog;
    /**
     * Format log entry
     */
    private formatLogEntry;
    /**
     * Check alert thresholds
     */
    private checkAlertThresholds;
    /**
     * Check specific threshold
     */
    private checkThreshold;
    /**
     * Generate security alert
     */
    private generateAlert;
    /**
     * Send alert notifications
     */
    private sendAlertNotifications;
    /**
     * Send webhook notification
     */
    private sendWebhookNotification;
    /**
     * Send email notification (placeholder)
     */
    private sendEmailNotification;
    /**
     * Generate unique event ID
     */
    private generateEventId;
    /**
     * Cleanup old events based on retention policy
     */
    private cleanupOldEvents;
    /**
     * Setup cleanup interval
     */
    private setupCleanupInterval;
    /**
     * Shutdown auditor
     */
    shutdown(): Promise<void>;
}
/**
 * Default audit configuration
 */
export declare const defaultAuditConfig: AuditConfig;
//# sourceMappingURL=securityAuditor.d.ts.map