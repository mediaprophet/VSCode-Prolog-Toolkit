"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrologDebugSession = void 0;
const debugadapter_1 = require("@vscode/debugadapter");
const path = __importStar(require("path"));
const process_promises_1 = require("process-promises");
const DebuggerController_1 = require("./debugger/DebuggerController");
// Extends the DebugSession class, providing the implementation for a Prolog debugger
class PrologDebugSession extends debugadapter_1.DebugSession {
    static SCOPEREF = 1;
    static THREAD_ID = 100;
    _debuggerController;
    _runtimeExecutable;
    // private _runtimeArgs: string[];
    _startupQuery;
    _startFile;
    _cwd;
    _stopOnEntry;
    _traceCmds;
    _currentVariables = [];
    _stackFrames = [];
    _debugging;
    constructor() {
        super();
        this.setDebuggerColumnsStartAt1(true);
        this.setDebuggerLinesStartAt1(true);
        this.setDebuggerPathFormat('native');
    }
    // Implements the initialization logic for the debugger
    initializeRequest(response, _args) {
        // Configure the response body with supported features and options
        response.body = {
            supportsConfigurationDoneRequest: true,
            supportTerminateDebuggee: true,
            supportsConditionalBreakpoints: true,
            supportsHitConditionalBreakpoints: true,
            supportsFunctionBreakpoints: true,
            supportsEvaluateForHovers: true,
            supportsExceptionOptions: true,
            supportsExceptionInfoRequest: true,
            // Define exception breakpoint filters with associated labels
            exceptionBreakpointFilters: [
                {
                    filter: 'Notice',
                    label: 'Notices',
                },
                {
                    filter: 'Warning',
                    label: 'Warnings',
                },
                {
                    filter: 'Error',
                    label: 'Errors',
                },
                {
                    filter: 'Exception',
                    label: 'Exceptions',
                },
                {
                    filter: '*',
                    label: 'Everything',
                    default: true,
                },
            ],
        };
        // Send the initialized response back to the client
        // ...existing code...
        this.sendResponse(response);
    }
    //Handles the 'attach' request from the debugger client
    attachRequest(response, _args) {
        // Send an error response indicating that attach requests are not supported
        this.sendErrorResponse(response, new Error('Attach requests are not supported'));
        // Shutdown the debugger session
        this.shutdown();
    }
    // Adds a stack frame to the list of stack frames during debugging
    addStackFrame(frame) {
        // Construct a new StackFrame object with information from the provided frame
        if (frame.file && frame.name) {
            this._stackFrames.unshift(new debugadapter_1.StackFrame(frame.id, `(${frame.level})${frame.name}`, new debugadapter_1.Source(path.basename(frame.file), // Extract the base name of the file
            frame.file), this.convertDebuggerLineToClient(frame.line), // Convert debugger line to client line
            this.convertDebuggerColumnToClient(frame.column) // Convert debugger column to client column
            ));
        }
    }
    //Sets the current variables in the debugger session
    setCurrentVariables(vars) {
        this._currentVariables = []; // Clear existing variables in _currentVariables array
        // Pop elements from the provided vars array and push them into _currentVariables
        while (vars.length > 0) {
            const variable = vars.pop();
            if (variable?.name) {
                this._currentVariables.push({ ...variable, variablesReference: 0 });
            }
        }
    }
    // Handles the 'launch' request from the debugger client
    launchRequest(response, args, _request) {
        const richArgs = args; // Cast arguments to LaunchRequestArguments for access to specific properties
        // Set various parameters from the launch arguments or use defaults
        this._startupQuery = richArgs.startupQuery || 'start';
        this._startFile = richArgs.program ? path.resolve(richArgs.program) : '';
        this._cwd = richArgs.cwd;
        this._runtimeExecutable = richArgs.runtimeExecutable || 'swipl';
        // this._runtimeArgs = args.runtimeArgs || null;
        this._stopOnEntry = typeof richArgs.stopOnEntry === 'boolean' ? richArgs.stopOnEntry : true;
        this._traceCmds = richArgs.traceCmds || {};
        this._debuggerController = new DebuggerController_1.DebuggerController({
            runtimeExecutable: this._runtimeExecutable,
            runtimeArgs: richArgs.runtimeArgs ?? [],
            cwd: this._cwd,
            env: richArgs.env ?? {},
        });
        this.sendResponse(response); // Send the launch response back to the client
        this.sendEvent(new debugadapter_1.InitializedEvent()); // Send an 'Initialized' event to the client, indicating that the debugger is ready
    }
    // Handles the 'threads' request from the debugger client
    threadsRequest(response) {
        // Configure the response body with information about the threads
        response.body = {
            threads: [new debugadapter_1.Thread(PrologDebugSession.THREAD_ID, 'thread 1')],
        };
        this.sendResponse(response); // Send the threads response back to the client
    }
    // Handles the 'setBreakpoints' request from the debugger client
    setBreakPointsRequest(response, args) {
        // Check if the debugger is currently in a debugging session
        if (this._debugging) {
            // Display a message indicating that breakpoints set during debugging will take effect in the next debugging process
            this.debugOutput('Breakpoints set during debugging would take effect in next debugging process.');
            return; // Return without setting breakpoints during an active debugging session
        }
        this._debuggerController.breakpointManager.setBreakpoints(args.source?.path || '', (args.breakpoints || []));
        // TODO: Send response after protocol communication
        this.sendResponse(response);
    }
    // Handles the 'setExceptionBreakpoints' request from the debugger client
    setExceptionBreakPointsRequest(response, _args) {
        // Use empty array/object for runtimeArgs/env to avoid type errors
        this._debuggerController = new DebuggerController_1.DebuggerController({
            runtimeExecutable: this._runtimeExecutable,
            runtimeArgs: [],
            cwd: this._cwd,
            env: {},
        });
        // TODO: Wire up event listeners for protocolAdapter, processManager, etc.
        this.sendResponse(response);
    }
    // Handles the 'setFunctionBreakpoints' request from the debugger client
    setFunctionBreakPointsRequest(response, _args) {
        // Delegate the task of setting function breakpoints to the Prolog debugger
        if (this._debuggerController) {
            const preds = (_args.breakpoints || []).map(bp => bp.name);
            this._debuggerController.breakpointManager.setFunctionBreakpoints(preds);
            // TODO: Send response after protocol communication
            this.sendResponse(response);
        }
    }
    // Handles the 'configurationDone' request from the debugger client
    configurationDoneRequest(response, _args) {
        this.sendResponse(response); // Send a response back to the client
        // TODO: Use DebuggerController to start the process and send startup commands
        this._debugging = true; // Set the debugging flag to true
    }
    // Evaluates the expression to retrieve the value of a variable
    evaluateExpression(exp) {
        const vars = this._currentVariables;
        // Iterate through the current variables
        for (let i = 0; i < vars.length; i++) {
            // Check if the variable name matches the provided expression
            if (vars[i]?.name === exp) {
                return vars[i]?.value; // Return the value of the variable
            }
        }
        return null; // Return null if the variable is not found
    }
    // Handles the 'evaluate' request from the debugger client
    evaluateRequest(response, args) {
        const val = this.evaluateExpression(args.expression); // Evaluate the expression to retrieve the value
        // If a value is found, send the result back to the client
        if (val) {
            response.body = {
                result: val,
                variablesReference: 0,
            };
            this.sendResponse(response);
            return;
        }
        else {
            if (args.context === 'repl') {
                const vars = this._currentVariables;
                let exp = args.expression.trim();
                if (exp.startsWith(':')) {
                    // Workaround for input from stdin
                    // TODO: Use DebuggerController to send input to process
                }
                else {
                    // Replace variable references in the expression with their values
                    for (let i = 0; i < vars.length; i++) {
                        const variable = vars[i];
                        if (variable && variable.name && variable.value) {
                            const re = new RegExp('\\b' + variable.name + '\\b', 'g');
                            exp = exp.replace(re, variable.value || '');
                        }
                    }
                    this.debugOutput(args.expression);
                    this.evaluate(exp); // Evaluate the modified expression
                }
                response.body = { result: '', variablesReference: 0 };
            }
            this.sendResponse(response); // Send the response back to the client
            return;
        }
    }
    // Handles the 'stackTrace' request from the debugger client
    stackTraceRequest(response, _args) {
        // Configure the response body with information about the stack frames
        response.body = {
            stackFrames: this._stackFrames,
        };
        this.sendResponse(response); // Send the stack trace response back to the client
    }
    // Handles the 'variables' request from the debugger client
    variablesRequest(response, _args) {
        const variables = new Array();
        // Copy variables from _currentVariables to the response
        for (let i = 0; i < this._currentVariables.length; i++) {
            const variable = this._currentVariables[i];
            if (variable) {
                variables.push(variable);
            }
        }
        // Configure the response body with information about the variables
        response.body = {
            variables: variables,
        };
        this.sendResponse(response); // Send the variables response back to the client
    }
    //Handles the 'scopes' request from the debugger client
    scopesRequest(response, _args) {
        const scopes = new Array();
        scopes.push(new debugadapter_1.Scope('Local', PrologDebugSession.SCOPEREF++, false)); // Add a Local scope to the response
        // Configure the response body with information about the scopes
        response.body = {
            scopes: scopes,
        };
        this.sendResponse(response); // Send the scopes response back to the client
    }
    // Handles the 'continue' request from the debugger client
    continueRequest(response, _args) {
        // TODO: Use DebuggerController to send continue command
        this.sendResponse(response); // Send the continue response back to the client
    }
    // Handles the 'next' request from the debugger client
    nextRequest(response, _args) {
        // TODO: Use DebuggerController to send next/stepover command
        this.sendResponse(response); // Send the next response back to the client
    }
    // Handles the 'stepIn' request from the debugger client
    stepInRequest(response, _args) {
        // TODO: Use DebuggerController to send stepIn command
        this.sendResponse(response); // Send the step-in response back to the client
    }
    // Handles the 'stepOut' request from the debugger client
    stepOutRequest(response, _args) {
        // TODO: Use DebuggerController to send stepOut command
        this.sendResponse(response); // Send the step-out response back to the client
    }
    // Handles the 'disconnect' request from the debugger client
    disconnectRequest(response, _args) {
        this._debugging = false;
        if (this._debuggerController) {
            this._debuggerController.killProcess();
        }
        this.shutdown();
        this.sendResponse(response);
    }
    // Handles the 'restart' request from the debugger client
    restartRequest(response, _args) {
        this._debugging = false;
        if (this._debuggerController) {
            this._debuggerController.killProcess();
        }
        this.shutdown();
        this.sendResponse(response);
    }
    // Sends an error response back to the debugger client
    sendErrorResponse(response) {
        // Check if the second argument is an instance of Error
        if (arguments[1] instanceof Error) {
            // Extract error information from the second and third arguments
            const error = arguments[1];
            const dest = arguments[2];
            // Determine the error code
            let code;
            if (typeof error.code === 'number') {
                code = error.code;
            }
            else if (typeof error.errno === 'number') {
                code = error.errno;
            }
            else {
                // Default to 0 if no valid code is found
                code = 0;
            }
            super.sendErrorResponse(response, code, error.message, dest); // Forward the error response to the superclass method
        }
        else {
            // If the second argument is not an instance of Error, forward the response as is
            super.sendErrorResponse(response, arguments[1], arguments[2], arguments[3], arguments[4]);
        }
    }
    // Sends a debug output event with the specified message to the debugger client
    debugOutput(msg) {
        // Send a debug output event with the specified message
        this.sendEvent(new debugadapter_1.OutputEvent(msg));
    }
    // Evaluates the specified Prolog expression by spawning a new process
    evaluate(expression) {
        // Get the runtime executable, program arguments, and input for the Prolog process
        const exec = this._runtimeExecutable;
        const args = ['-q', `${this._startFile}`];
        const input = `
    call((${expression})).
    halt.
    `;
        // Configure spawn options with the current working directory
        const spawnOptions = {
            cwd: this._cwd,
        };
        // Spawn a new process for Prolog execution
        (0, process_promises_1.spawn)(exec, args, spawnOptions)
            // If the process has a valid PID, write input to its stdin and end the input stream
            .on('process', (proc) => {
            if (proc.pid) {
                proc.stdin.write(input);
                proc.stdin.end();
            }
        })
            .on('stdout', (data) => {
            // Handle standard output by sending it as debug output
            this.debugOutput('\n' + data);
        })
            .on('stderr', (err) => {
            // Handle standard error by sending it as debug output
            this.debugOutput('\n' + err);
        })
            .catch((err) => {
            // Handle any errors by sending the error message as debug output
            this.debugOutput(err.message);
        });
    }
}
exports.PrologDebugSession = PrologDebugSession;
debugadapter_1.DebugSession.run(PrologDebugSession); //start of the Prolog debug session
//# sourceMappingURL=prologDebugSession.js.map