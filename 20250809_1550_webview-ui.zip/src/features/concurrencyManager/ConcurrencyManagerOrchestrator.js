"use strict";
// Orchestrator for Concurrency Management
// Composes resource, queue, and event modules for robust, testable concurrency management
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConcurrencyManagerOrchestrator = void 0;
const events_1 = require("events");
const ConcurrencyEvents_1 = require("./ConcurrencyEvents");
const ConcurrencyLogic_1 = require("./ConcurrencyLogic");
const ConcurrencyQueue_1 = require("./ConcurrencyQueue");
const ConcurrencyResource_1 = require("./ConcurrencyResource");
class ConcurrencyManagerOrchestrator extends events_1.EventEmitter {
    resource;
    queue;
    logic;
    events;
    constructor(quota = {}) {
        super();
        this.resource = new ConcurrencyResource_1.ConcurrencyResource(quota);
        this.queue = new ConcurrencyQueue_1.ConcurrencyQueue(this.resource);
        this.logic = new ConcurrencyLogic_1.ConcurrencyLogic(this.resource, this.queue);
        this.events = new ConcurrencyEvents_1.ConcurrencyEvents(this.queue, this.resource);
        this.registerEventHandlers();
    }
    registerEventHandlers() {
        this.events.on('queryQueued', (data) => this.emit('queryQueued', data));
        this.events.on('queryStarted', (data) => this.emit('queryStarted', data));
        this.events.on('queryCompleted', (data) => this.emit('queryCompleted', data));
        this.events.on('error', (err) => this.emit('error', err));
        // ...add more as needed
    }
    // Expose orchestrated API
    async queueQuery(query) {
        return this.logic.queueQuery(query);
    }
    cancelQuery(queryId) {
        return this.logic.cancelQuery(queryId);
    }
    getStatus() {
        return this.logic.getStatus();
    }
    updateResourceQuota(newQuota) {
        this.logic.updateResourceQuota(newQuota);
    }
}
exports.ConcurrencyManagerOrchestrator = ConcurrencyManagerOrchestrator;
//# sourceMappingURL=ConcurrencyManagerOrchestrator.js.map