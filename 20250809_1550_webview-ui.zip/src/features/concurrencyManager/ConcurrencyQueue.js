"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConcurrencyQueue = void 0;
const events_1 = require("events");
class ConcurrencyQueue extends events_1.EventEmitter {
    resource;
    queue = [];
    running = new Set();
    processing = false;
    constructor(resource) {
        super();
        this.resource = resource;
    }
    async queueQuery(query) {
        return new Promise((resolve, reject) => {
            const q = { ...query, resolve, reject };
            this.queue.push(q);
            this.queue.sort((a, b) => b.priority.weight - a.priority.weight);
            this.resource.setQueueSize(this.queue.length);
            this.emit('queryQueued', q);
            this.processQueue();
        });
    }
    cancelQuery(queryId) {
        const idx = this.queue.findIndex(q => q.id === queryId);
        if (idx !== -1) {
            const [q] = this.queue.splice(idx, 1);
            this.resource.setQueueSize(this.queue.length);
            if (q) {
                q.reject(new Error('Query cancelled'));
                this.emit('queryCancelled', q);
            }
            return true;
        }
        return false;
    }
    async processQueue() {
        if (this.processing)
            return;
        this.processing = true;
        try {
            while (this.queue.length > 0) {
                const q = this.queue[0];
                if (!q || !this.resource.canRunQuery(q))
                    break;
                this.queue.shift();
                this.resource.setQueueSize(this.queue.length);
                this.running.add(q.id);
                this.resource.incrementUsage(q.resourceRequirements);
                this.emit('queryStarted', q);
                try {
                    const result = await this.executeQuery(q);
                    q.resolve(result);
                    this.emit('queryCompleted', { ...q, result });
                }
                catch (err) {
                    q.reject(err);
                    this.emit('error', err);
                }
                finally {
                    this.running.delete(q.id);
                    this.resource.decrementUsage(q.resourceRequirements);
                }
            }
        }
        finally {
            this.processing = false;
        }
    }
    async executeQuery(q) {
        // TODO: Replace with actual query execution logic
        await new Promise(res => setTimeout(res, q.estimatedDuration || 100));
        return { success: true, id: q.id };
    }
}
exports.ConcurrencyQueue = ConcurrencyQueue;
//# sourceMappingURL=ConcurrencyQueue.js.map