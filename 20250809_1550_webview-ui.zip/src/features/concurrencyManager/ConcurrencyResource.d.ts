import { EventEmitter } from 'events';
export interface ResourceUsage {
    activeConcurrentQueries: number;
    memoryUsageMB: number;
    cpuUsagePercent: number;
    queueSize: number;
    lastUpdated: number;
}
export interface ResourceQuota {
    maxConcurrentQueries: number;
    maxMemoryUsageMB: number;
    maxCpuUsagePercent: number;
    maxQueryDurationMs: number;
    maxQueueSize: number;
}
export declare class ConcurrencyResource extends EventEmitter {
    private quota;
    private usage;
    constructor(quota?: Partial<ResourceQuota>);
    /**
     * Dynamically scale resource quotas based on observed usage or external signals.
     * Example: If usage is consistently high, increase quotas; if low, decrease.
     * Accepts a scaling policy callback or uses a default heuristic.
     */
    autoScaleQuota(policy?: (usage: ResourceUsage, quota: Partial<ResourceQuota>) => Partial<ResourceQuota>): void;
    getStatus(): {
        quota: Partial<ResourceQuota>;
        activeConcurrentQueries: number;
        memoryUsageMB: number;
        cpuUsagePercent: number;
        queueSize: number;
        lastUpdated: number;
    };
    updateResourceQuota(newQuota: Partial<ResourceQuota>): void;
    incrementUsage({ memoryMB, cpuPercent }?: {
        memoryMB?: number;
        cpuPercent?: number;
    }): void;
    decrementUsage({ memoryMB, cpuPercent }?: {
        memoryMB?: number;
        cpuPercent?: number;
    }): void;
    setQueueSize(size: number): void;
    estimateMemoryUsage(query: any): number;
    estimateCpuUsage(query: any): number;
    canRunQuery(query: any): boolean;
}
//# sourceMappingURL=ConcurrencyResource.d.ts.map