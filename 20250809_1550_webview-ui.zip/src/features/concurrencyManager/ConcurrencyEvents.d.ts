import { EventEmitter } from 'events';
import { ConcurrencyQueue } from './ConcurrencyQueue';
import { ConcurrencyResource } from './ConcurrencyResource';
export declare class ConcurrencyEvents extends EventEmitter {
    private queue;
    private resource;
    constructor(queue: ConcurrencyQueue, resource: ConcurrencyResource);
}
//# sourceMappingURL=ConcurrencyEvents.d.ts.map