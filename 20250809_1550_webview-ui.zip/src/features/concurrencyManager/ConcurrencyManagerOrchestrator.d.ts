import { EventEmitter } from 'events';
import { ResourceQuota } from '../concurrencyManager';
export declare class ConcurrencyManagerOrchestrator extends EventEmitter {
    private resource;
    private queue;
    private logic;
    private events;
    constructor(quota?: Partial<ResourceQuota>);
    private registerEventHandlers;
    queueQuery(query: any): Promise<unknown>;
    cancelQuery(queryId: string): boolean;
    getStatus(): {
        quota: Partial<import("./ConcurrencyResource").ResourceQuota>;
        activeConcurrentQueries: number;
        memoryUsageMB: number;
        cpuUsagePercent: number;
        queueSize: number;
        lastUpdated: number;
    };
    updateResourceQuota(newQuota: Partial<ResourceQuota>): void;
}
//# sourceMappingURL=ConcurrencyManagerOrchestrator.d.ts.map