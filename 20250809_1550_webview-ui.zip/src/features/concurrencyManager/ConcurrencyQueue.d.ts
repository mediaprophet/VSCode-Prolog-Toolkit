import { ConcurrencyResource } from './ConcurrencyResource';
import { EventEmitter } from 'events';
interface QueuedQuery {
    id: string;
    cmd: string;
    params: Record<string, unknown>;
    priority: {
        level: 'low' | 'normal' | 'high' | 'critical';
        weight: number;
        timeout: number;
    };
    queuedAt: number;
    estimatedDuration?: number;
    resourceRequirements?: {
        memoryMB?: number;
        cpuPercent?: number;
    };
    resolve: (value: unknown) => void;
    reject: (error: unknown) => void;
}
export declare class ConcurrencyQueue extends EventEmitter {
    private resource;
    private queue;
    private running;
    private processing;
    constructor(resource: ConcurrencyResource);
    queueQuery(query: Omit<QueuedQuery, 'resolve' | 'reject'>): Promise<unknown>;
    cancelQuery(queryId: string): boolean;
    private processQueue;
    private executeQuery;
}
export {};
//# sourceMappingURL=ConcurrencyQueue.d.ts.map