"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConcurrencyEvents = void 0;
// Handles all event emission and subscription for concurrency management
const events_1 = require("events");
class ConcurrencyEvents extends events_1.EventEmitter {
    queue;
    resource;
    constructor(queue, resource) {
        super();
        this.queue = queue;
        this.resource = resource;
        // Example: Register for queue/resource events and re-emit as needed
        if (typeof queue.on === 'function') {
            queue.on('queryQueued', (data) => this.emit('queryQueued', data));
            queue.on('queryStarted', (data) => this.emit('queryStarted', data));
            queue.on('queryCompleted', (data) => this.emit('queryCompleted', data));
            queue.on('error', (err) => this.emit('error', err));
        }
        if (typeof resource.on === 'function') {
            resource.on('resourceUpdated', (data) => this.emit('resourceUpdated', data));
        }
    }
}
exports.ConcurrencyEvents = ConcurrencyEvents;
//# sourceMappingURL=ConcurrencyEvents.js.map