import { ConcurrencyQueue } from './ConcurrencyQueue';
import { ConcurrencyResource } from './ConcurrencyResource';
export declare class ConcurrencyLogic {
    private resource;
    private queue;
    constructor(resource: ConcurrencyResource, queue: ConcurrencyQueue);
    queueQuery(query: Omit<any, 'resolve' | 'reject'>): Promise<unknown>;
    cancelQuery(queryId: string): boolean;
    getStatus(): {
        quota: Partial<import("./ConcurrencyResource").ResourceQuota>;
        activeConcurrentQueries: number;
        memoryUsageMB: number;
        cpuUsagePercent: number;
        queueSize: number;
        lastUpdated: number;
    };
    updateResourceQuota(newQuota: Partial<any>): void;
}
//# sourceMappingURL=ConcurrencyLogic.d.ts.map