import { CancellationToken, Location, Position, ReferenceContext, ReferenceProvider, TextDocument } from 'vscode';
export declare class PrologReferenceProvider implements ReferenceProvider {
    constructor();
    provideReferences(doc: TextDocument, position: Position, _context: ReferenceContext, _token: CancellationToken): Location[];
}
//# sourceMappingURL=referenceProvider.d.ts.map