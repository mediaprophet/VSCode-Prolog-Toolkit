/**
 * Package manager information interface
 */
export interface PackageManagerInfo {
    name: string;
    displayName: string;
    checkCommand: string;
    installCommand: string;
    packageName: string;
    isAvailable: boolean;
    version?: string;
    priority: number;
}
/**
 * Installation result interface
 */
export interface InstallationResult {
    success: boolean;
    packageManager: string;
    command: string;
    output?: string;
    error?: string;
    requiresElevation?: boolean;
}
/**
 * Package manager integration for SWI-Prolog installation
 */
export declare class PackageManagerIntegration {
    private static instance;
    private platform;
    private availableManagers;
    private detectionCache;
    static getInstance(): PackageManagerIntegration;
    constructor();
    /**
     * Initialize platform-specific package managers
     */
    private initializePackageManagers;
    /**
     * Initialize Windows package managers
     */
    private initializeWindowsManagers;
    /**
     * Initialize macOS package managers
     */
    private initializeMacOSManagers;
    /**
     * Initialize Linux package managers
     */
    private initializeLinuxManagers;
    /**
     * Detect available package managers on the system
     */
    detectAvailableManagers(): Promise<PackageManagerInfo[]>;
    /**
     * Check if a specific package manager is available
     */
    private checkPackageManagerAvailability;
    /**
     * Check if SWI-Prolog is already installed via package managers
     */
    checkExistingInstallation(): Promise<{
        isInstalled: boolean;
        packageManager?: string;
        version?: string;
        packageName?: string;
    }>;
    /**
     * Check if a package is installed via a specific package manager
     */
    private checkPackageInstallation;
    /**
     * Install SWI-Prolog using the best available package manager
     */
    installSwiplProlog(preferredManager?: string): Promise<InstallationResult>;
    /**
     * Execute the installation using a specific package manager
     */
    private executeInstallation;
    /**
     * Show installation dialog with package manager options
     */
    showInstallationDialog(): Promise<InstallationResult | null>;
    /**
     * Get installation suggestions for the current platform
     */
    getInstallationSuggestions(): Promise<string[]>;
    /**
     * Clear detection cache (useful for testing or after system changes)
     */
    clearCache(): void;
    /**
     * Get all configured package managers for the current platform
     */
    getConfiguredManagers(): PackageManagerInfo[];
    /**
     * Get platform-specific package manager recommendations
     */
    getRecommendedManagers(): string[];
}
//# sourceMappingURL=packageManagerIntegration.d.ts.map