"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RunTrigger = void 0;
/**
 * Enum for different triggers that can run the linter
 */
var RunTrigger;
(function (RunTrigger) {
    RunTrigger[RunTrigger["onType"] = 0] = "onType";
    RunTrigger[RunTrigger["onSave"] = 1] = "onSave";
    RunTrigger[RunTrigger["never"] = 2] = "never";
})(RunTrigger || (exports.RunTrigger = RunTrigger = {}));
//# sourceMappingURL=interfaces.js.map