import { Diagnostic, TextDocument } from 'vscode';
import { IDiagnosticInfo, IDiagnosticParser } from './interfaces';
/**
 * Handles parsing of Prolog compiler output into diagnostic information
 */
export declare class DiagnosticParser implements IDiagnosticParser {
    private readonly swiRegex;
    /**
     * Parse a single issue string from linter output
     */
    parseIssue(issue: string, filePathIds: {
        [id: string]: string;
    }): IDiagnosticInfo | null;
    /**
     * Parse Prolog output and extract diagnostic information
     */
    parsePrologOutput(output: string, errorOutput: string, textDocument: TextDocument): IDiagnosticInfo[];
    /**
     * Process standard output for different dialects
     */
    private processStdout;
    /**
     * Process standard error for different dialects
     */
    private processStderr;
    /**
     * Process SWI-Prolog stderr output
     */
    private processSwiStderr;
    /**
     * Process ECLiPSe stderr output
     */
    private processEclStderr;
    /**
     * Convert IDiagnosticInfo to VS Code Diagnostic
     */
    convertToDiagnostic(info: IDiagnosticInfo): Diagnostic;
    /**
     * Group diagnostics by file name
     */
    groupDiagnosticsByFile(diagnostics: IDiagnosticInfo[]): {
        [fileName: string]: IDiagnosticInfo[];
    };
}
//# sourceMappingURL=diagnosticParser.d.ts.map