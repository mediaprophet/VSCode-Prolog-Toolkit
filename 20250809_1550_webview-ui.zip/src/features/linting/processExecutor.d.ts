import { TextDocument } from 'vscode';
import { ILinterConfiguration, IProcessExecutor, IProcessResult, RunTrigger } from './interfaces';
/**
 * Handles execution of Prolog processes with dialect-specific configurations
 */
export declare class ProcessExecutor implements IProcessExecutor {
    private context;
    constructor(context: any);
    /**
     * Execute Prolog process for linting a document
     */
    executeProlog(document: TextDocument, config: ILinterConfiguration): Promise<IProcessResult>;
    /**
     * Build arguments for different Prolog dialects and triggers
     */
    buildArgumentsForDialect(trigger: RunTrigger, fileName: string, documentText: string): {
        args: string[];
        goals?: string;
    };
    /**
     * Get execution options for the current workspace
     */
    private getExecutionOptions;
    /**
     * Check if the dialect is supported
     */
    isDialectSupported(dialect: string): boolean;
    /**
     * Get supported dialects
     */
    getSupportedDialects(): string[];
}
//# sourceMappingURL=processExecutor.d.ts.map