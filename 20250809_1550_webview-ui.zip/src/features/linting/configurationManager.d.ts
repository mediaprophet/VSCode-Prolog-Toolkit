import { IConfigurationManager, ILinterConfiguration, RunTrigger } from './interfaces';
/**
 * Manages linter configuration, executable path resolution, and settings
 */
export declare class ConfigurationManager implements IConfigurationManager {
    private _configuration;
    /**
     * Load configuration settings from VS Code workspace
     */
    loadConfiguration(): Promise<ILinterConfiguration>;
    /**
     * Resolve the executable path with enhanced validation and permission checking
     */
    resolveExecutablePath(): Promise<string>;
    /**
     * Determine the trigger type for the linter
     */
    private determineTrigger;
    /**
     * Get the current delay setting
     */
    getDelay(): number;
    /**
     * Get the current trigger setting
     */
    getTrigger(): RunTrigger;
    /**
     * Check if output is enabled
     */
    isOutputEnabled(): boolean;
    /**
     * Get current configuration (readonly)
     */
    getCurrentConfiguration(): ILinterConfiguration | null;
    /**
     * Reload configuration when settings change
     */
    reloadConfiguration(): Promise<ILinterConfiguration>;
}
//# sourceMappingURL=configurationManager.d.ts.map