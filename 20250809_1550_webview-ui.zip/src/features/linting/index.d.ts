export * from './interfaces';
export * from './configurationManager';
export * from './processExecutor';
export * from './diagnosticParser';
export * from './codeActionProvider';
export * from './navigationProvider';
export * from './commandManager';
export { default as PrologLinter } from './prologLinter';
export { default } from './prologLinter';
//# sourceMappingURL=index.d.ts.map