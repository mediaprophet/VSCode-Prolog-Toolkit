import type { DiagnosticCollection, OutputChannel } from 'vscode';
import { Diagnostic } from 'vscode';
import type { INavigationProvider } from './interfaces.js';
/**
 * Provides navigation functionality for linting errors and warnings
 */
export declare class NavigationProvider implements INavigationProvider {
    private diagnosticCollection;
    private sortedDiagIndex;
    private outputChannel;
    constructor(diagnosticCollection: DiagnosticCollection, outputChannel: OutputChannel);
    /**
     * Navigate to the next error or warning line
     */
    gotoNextError(): void;
    /**
     * Navigate to the previous error or warning line
     */
    gotoPrevError(): void;
    /**
     * Navigate to the error or warning line based on direction
     * @param direction 0: next, 1: previous
     */
    gotoErrorLine(direction: number): void;
    /**
     * Update sorted diagnostic indices for a document
     */
    updateSortedDiagnosticIndex(documentUri: string, diagnostics: Diagnostic[]): void;
    /**
     * Display diagnostic message in output channel
     */
    private displayDiagnosticMessage;
    /**
     * Show message in output channel
     */
    private showMessage;
    /**
     * Display all diagnostics for a document in output channel
     */
    displayAllDiagnostics(documentPath: string, diagnostics: Diagnostic[]): void;
    /**
     * Get diagnostic count for a document
     */
    getDiagnosticCount(documentUri: string): {
        errors: number;
        warnings: number;
        total: number;
    };
    /**
     * Clear navigation state for a document
     */
    clearNavigationState(documentUri: string): void;
    /**
     * Check if navigation is available for current document
     */
    isNavigationAvailable(): boolean;
}
//# sourceMappingURL=navigationProvider.d.ts.map