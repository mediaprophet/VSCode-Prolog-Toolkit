"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcessExecutor = void 0;
const jsesc_1 = __importDefault(require("jsesc"));
const path = __importStar(require("path"));
const process_promises_1 = require("process-promises");
const vscode_1 = require("vscode");
const platformUtils_1 = require("../../utils/platformUtils");
const utils_1 = require("../../utils/utils");
const interfaces_1 = require("./interfaces");
/**
 * Handles execution of Prolog processes with dialect-specific configurations
 */
class ProcessExecutor {
    context; // Extension context
    constructor(context) {
        this.context = context;
    }
    /**
     * Execute Prolog process for linting a document
     */
    async executeProlog(document, config) {
        // Configure options for executing Prolog
        const options = vscode_1.workspace.workspaceFolders?.[0]?.uri.fsPath
            ? { cwd: vscode_1.workspace.workspaceFolders[0].uri.fsPath }
            : undefined;
        const docTxt = document.getText();
        const docTxtEsced = (0, jsesc_1.default)(docTxt, { quotes: 'double' });
        const fname = (0, jsesc_1.default)(platformUtils_1.PlatformUtils.toAbsolute(document.fileName));
        // Build arguments based on dialect and trigger
        const { args, goals } = this.buildArgumentsForDialect(config.trigger, fname, docTxtEsced);
        return new Promise((resolve, reject) => {
            let stdoutData = '';
            let stderrData = '';
            // Execute the Prolog process
            (0, process_promises_1.spawn)(config.executable, args, options)
                .on('process', process => {
                // Handle the Prolog process
                if (process.pid) {
                    if (config.trigger === interfaces_1.RunTrigger.onType && goals) {
                        process.stdin.write(goals);
                        process.stdin.end();
                    }
                }
            })
                .on('stdout', (out) => {
                stdoutData += out;
            })
                .on('stderr', (err) => {
                stderrData += err;
            })
                .then(_result => {
                resolve({
                    stdout: stdoutData,
                    stderr: stderrData,
                    exitCode: 0,
                });
            })
                .catch(error => {
                if (error.code === 'ENOENT') {
                    reject(new Error('PROLOG_EXECUTABLE_NOT_FOUND'));
                }
                else {
                    reject(error);
                }
            });
        });
    }
    /**
     * Build arguments for different Prolog dialects and triggers
     */
    buildArgumentsForDialect(trigger, fileName, documentText) {
        let args = [];
        let goals = '';
        // Determine Prolog dialect and set arguments accordingly
        switch (utils_1.PrologExecUtils.DIALECT) {
            case 'swi': {
                if (trigger === interfaces_1.RunTrigger.onSave) {
                    args = ['-g', 'halt', fileName];
                }
                if (trigger === interfaces_1.RunTrigger.onType) {
                    args = ['-q'];
                    goals = `
            open_string("${documentText}", S),
            load_files('${fileName}', [stream(S),if(true)]).
            list_undefined.
          `;
                }
                break;
            }
            case 'ecl': {
                const dir = (0, jsesc_1.default)(path.resolve(`${this.context.extensionPath}/out/src/features`));
                if (trigger === interfaces_1.RunTrigger.onSave) {
                    const fdir = path.dirname(fileName);
                    const file = path.basename(fileName);
                    goals = `(cd("${dir}"),
          use_module('load_modules'),
          cd("${fdir}"),
          load_modules_from_file('${file}'),
          compile('${file}', [debug:off]),halt)`;
                    args = ['-e', goals];
                }
                if (trigger === interfaces_1.RunTrigger.onType) {
                    goals = `(cd("${dir}"),
          use_module(load_modules),
          load_modules_from_text("${documentText}"),
          open(string("${documentText}"), read, S),
          compile(stream(S), [debug:off]),
          close(S),halt)`;
                    args = ['-e', goals];
                }
                break;
            }
            default:
                break;
        }
        return { args, goals: trigger === interfaces_1.RunTrigger.onType ? goals : undefined };
    }
    /**
     * Get execution options for the current workspace
     */
    getExecutionOptions() {
        return vscode_1.workspace.workspaceFolders?.[0]?.uri.fsPath
            ? { cwd: vscode_1.workspace.workspaceFolders[0].uri.fsPath }
            : undefined;
    }
    /**
     * Check if the dialect is supported
     */
    isDialectSupported(dialect) {
        return ['swi', 'ecl'].includes(dialect);
    }
    /**
     * Get supported dialects
     */
    getSupportedDialects() {
        return ['swi', 'ecl'];
    }
}
exports.ProcessExecutor = ProcessExecutor;
//# sourceMappingURL=processExecutor.js.map