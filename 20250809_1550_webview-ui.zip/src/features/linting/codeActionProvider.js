"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CodeActionProvider = void 0;
const utils_1 = require("../../utils/utils");
/**
 * Provides code actions for Prolog linting diagnostics
 */
class CodeActionProvider {
    commandAddDynamicId;
    commandAddUseModuleId;
    constructor() {
        this.commandAddDynamicId = 'prolog.addDynamicDirective';
        this.commandAddUseModuleId = 'prolog.addUseModule';
    }
    /**
     * Provide code actions for diagnostics
     */
    provideCodeActions(document, range, context, _token) {
        const codeActions = [];
        // Iterate through each diagnostic in the context
        context.diagnostics.forEach(diagnostic => {
            const regex = /Predicate (.+) not defined/;
            const match = diagnostic.message.match(regex);
            // Check if a match is found in the diagnostic message
            if (match && match[1]) {
                let pred = match[1];
                // Get modules associated with the predicate using utility function
                const modules = utils_1.SnippetUtils.getPredModules(pred);
                // Check if modules are found for the predicate
                if (modules.length > 0) {
                    // Generate code actions for each module and add them to the array
                    modules.forEach(module => {
                        codeActions.push({
                            title: "Add ':- use_module(library(" + module + '), [' + pred + "]).'",
                            command: this.commandAddUseModuleId,
                            arguments: [document, pred, module, document.uri, diagnostic.range],
                        });
                    });
                }
                // Extract module information from the document
                const moduleMatch = document.getText().match(/:-\s*module\((\w+),/);
                let currentModule = '';
                if (moduleMatch) {
                    currentModule = moduleMatch[1];
                }
                // Handle predicates with namespace (module)
                if (pred.indexOf(':') > -1) {
                    const [mod, pred1] = pred.split(':');
                    if (mod === currentModule) {
                        pred = pred1;
                    }
                }
                // Generate code action for adding 'dynamic' directive and add it to the array
                codeActions.push({
                    title: "Add ':- dynamic " + pred + ".'",
                    command: this.commandAddDynamicId,
                    arguments: [document, pred, document.uri, diagnostic.range],
                });
            }
        });
        return codeActions;
    }
    /**
     * Get command IDs used by this provider
     */
    getCommandIds() {
        return {
            addDynamic: this.commandAddDynamicId,
            addUseModule: this.commandAddUseModuleId,
        };
    }
    /**
     * Check if a diagnostic is handled by this provider
     */
    canHandleDiagnostic(message) {
        return /Predicate .+ not defined/.test(message);
    }
    /**
     * Extract predicate information from diagnostic message
     */
    extractPredicateFromDiagnostic(message) {
        const regex = /Predicate (.+) not defined/;
        const match = message.match(regex);
        return match && match[1] ? match[1] : null;
    }
    /**
     * Get available modules for a predicate
     */
    getAvailableModules(predicate) {
        return utils_1.SnippetUtils.getPredModules(predicate);
    }
    /**
     * Extract current module from document
     */
    extractCurrentModule(document) {
        const moduleMatch = document.getText().match(/:-\s*module\((\w+),/);
        return moduleMatch && moduleMatch[1] ? moduleMatch[1] : null;
    }
    /**
     * Normalize predicate name (remove module prefix if it matches current module)
     */
    normalizePredicate(predicate, currentModule) {
        if (!currentModule || predicate.indexOf(':') === -1) {
            return predicate;
        }
        const [mod, pred] = predicate.split(':');
        return mod === currentModule ? pred : predicate;
    }
}
exports.CodeActionProvider = CodeActionProvider;
//# sourceMappingURL=codeActionProvider.js.map