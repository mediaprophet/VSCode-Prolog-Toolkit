import { CancellationToken, CodeActionContext, CodeActionProvider, Command, DiagnosticCollection, ExtensionContext, Range, TextDocument } from 'vscode';
/**
 * Main Prolog Linter class that orchestrates all linting functionality
 * Now refactored into a modular architecture with separated concerns
 */
export default class PrologLinter implements CodeActionProvider {
    private context;
    private configurationManager;
    private processExecutor;
    private diagnosticParser;
    private codeActionProvider;
    private navigationProvider;
    private commandManager;
    private diagnosticCollection;
    private diagnostics;
    private outputChannel;
    private documentListener;
    private openDocumentListener;
    private timer;
    constructor(context: ExtensionContext);
    /**
     * Initialize the output channel
     */
    private initializeOutputChannel;
    /**
     * Implementation of CodeActionProvider interface method
     */
    provideCodeActions(document: TextDocument, range: Range, context: CodeActionContext, token: CancellationToken): Command[] | Promise<Command[]>;
    /**
     * Perform linting of a Prolog file
     */
    private doPlint;
    /**
     * Handle linting errors with enhanced error messages and installation guidance
     */
    private handleLintingError;
    /**
     * Load configuration settings and set up listeners
     */
    private loadConfiguration;
    /**
     * Trigger linting based on configuration
     */
    private triggerLinter;
    /**
     * Activate the linter
     */
    activate(): void;
    /**
     * Output message to console
     */
    private outputMsg;
    /**
     * Navigate to next error line
     */
    nextErrLine(): void;
    /**
     * Navigate to previous error line
     */
    prevErrLine(): void;
    /**
     * Get diagnostic collection for external use
     */
    getDiagnosticCollection(): DiagnosticCollection;
    /**
     * Check if navigation is available
     */
    isNavigationAvailable(): boolean;
    /**
     * Get diagnostic count for current document
     */
    getDiagnosticCount(): {
        errors: number;
        warnings: number;
        total: number;
    };
    /**
     * Cleanup method to dispose of resources when the extension is deactivated
     */
    dispose(): void;
}
//# sourceMappingURL=prologLinter.d.ts.map