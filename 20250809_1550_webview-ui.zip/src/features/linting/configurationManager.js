"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigurationManager = void 0;
const vscode_1 = require("vscode");
const which = __importStar(require("which"));
const executableFinder_1 = require("../../utils/executableFinder");
const platformUtils_1 = require("../../utils/platformUtils");
const interfaces_1 = require("./interfaces");
/**
 * Manages linter configuration, executable path resolution, and settings
 */
class ConfigurationManager {
    _configuration = null;
    /**
     * Load configuration settings from VS Code workspace
     */
    async loadConfiguration() {
        const section = vscode_1.workspace.getConfiguration('prolog');
        if (!section) {
            throw new Error('Prolog configuration section not found');
        }
        const executable = await this.resolveExecutablePath();
        const trigger = this.determineTrigger();
        const delay = section.get('linter.delay', 500);
        const enableOutput = section.get('linter.enableMsgInOutput', false);
        this._configuration = {
            executable,
            trigger,
            delay,
            enableOutput,
        };
        return this._configuration;
    }
    /**
     * Resolve the executable path with enhanced validation and permission checking
     */
    async resolveExecutablePath() {
        const section = vscode_1.workspace.getConfiguration('prolog');
        const configuredPath = section.get('executablePath', platformUtils_1.PlatformUtils.getDefaultExecutablePath());
        // First try the configured path
        if (configuredPath && configuredPath !== platformUtils_1.PlatformUtils.getDefaultExecutablePath()) {
            const normalizedPath = platformUtils_1.PlatformUtils.normalizePath(configuredPath);
            // Check if the configured path exists and has proper permissions
            if (await platformUtils_1.PlatformUtils.pathExists(normalizedPath)) {
                if (await platformUtils_1.PlatformUtils.isExecutable(normalizedPath)) {
                    return normalizedPath;
                }
                else {
                    // Path exists but is not executable - this will be handled by the main linter
                    console.warn(`[ConfigurationManager] Path exists but lacks execute permissions: ${normalizedPath}`);
                }
            }
        }
        // Try to find executable using comprehensive detection
        const executableFinder = new executableFinder_1.ExecutableFinder();
        const detectionResult = await executableFinder.findSwiplExecutable();
        if (detectionResult.found && detectionResult.path) {
            // Check permissions on the found executable
            if (detectionResult.permissions?.executable) {
                return detectionResult.path;
            }
            else {
                // Found executable but has permission issues
                console.warn(`[ConfigurationManager] Found executable with permission issues: ${detectionResult.path}`);
                return detectionResult.path; // Return the path anyway, the spawn will fail with a better error
            }
        }
        // Fallback to the configured path or default, even if it might not work
        try {
            const fallbackPath = which.sync(configuredPath);
            return fallbackPath;
        }
        catch (_e) {
            return platformUtils_1.PlatformUtils.normalizePath(configuredPath);
        }
    }
    /**
     * Determine the trigger type for the linter
     */
    determineTrigger() {
        // TODO: Refactor trigger logic to use new modular config if needed
        return interfaces_1.RunTrigger.never;
    }
    /**
     * Get the current delay setting
     */
    getDelay() {
        return this._configuration?.delay ?? 500;
    }
    /**
     * Get the current trigger setting
     */
    getTrigger() {
        return this._configuration?.trigger ?? interfaces_1.RunTrigger.never;
    }
    /**
     * Check if output is enabled
     */
    isOutputEnabled() {
        return this._configuration?.enableOutput ?? false;
    }
    /**
     * Get current configuration (readonly)
     */
    getCurrentConfiguration() {
        return this._configuration;
    }
    /**
     * Reload configuration when settings change
     */
    async reloadConfiguration() {
        this._configuration = null;
        return this.loadConfiguration();
    }
}
exports.ConfigurationManager = ConfigurationManager;
//# sourceMappingURL=configurationManager.js.map