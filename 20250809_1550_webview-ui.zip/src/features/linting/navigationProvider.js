"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.NavigationProvider = void 0;
const vscode_1 = require("vscode");
const path = __importStar(require("path"));
/**
 * Provides navigation functionality for linting errors and warnings
 */
class NavigationProvider {
    diagnosticCollection;
    sortedDiagIndex = {};
    outputChannel;
    constructor(diagnosticCollection, outputChannel) {
        this.diagnosticCollection = diagnosticCollection;
        this.outputChannel = outputChannel;
    }
    /**
     * Navigate to the next error or warning line
     */
    gotoNextError() {
        this.gotoErrorLine(0);
    }
    /**
     * Navigate to the previous error or warning line
     */
    gotoPrevError() {
        this.gotoErrorLine(1);
    }
    /**
     * Navigate to the error or warning line based on direction
     * @param direction 0: next, 1: previous
     */
    gotoErrorLine(direction) {
        const editor = vscode_1.window.activeTextEditor;
        if (!editor) {
            this.showMessage('No active editor found');
            return;
        }
        const diagnostics = this.diagnosticCollection.get(editor.document.uri);
        // If there are no diagnostics, display a message and return
        if (!diagnostics || diagnostics.length === 0) {
            this.showMessage('No errors or warnings :)');
            return;
        }
        this.outputChannel.clear();
        const activeLine = editor.selection.active.line;
        let position = undefined;
        let selectedIndex;
        const sortedIndices = this.sortedDiagIndex[editor.document.uri.fsPath];
        if (!sortedIndices || sortedIndices.length === 0) {
            this.showMessage('No diagnostic index found for this document');
            return;
        }
        // Determine the navigation direction (next or previous)
        if (direction === 0) {
            // Next error
            selectedIndex = 0;
            // If the active line is greater than or equal to the last diagnostic's start line,
            // navigate to the start of the first diagnostic; otherwise, find the next diagnostic
            const lastIndex = sortedIndices[sortedIndices.length - 1];
            if (lastIndex !== undefined && diagnostics[lastIndex] && activeLine >= diagnostics[lastIndex].range.start.line) {
                const firstIndex = sortedIndices[0];
                if (firstIndex !== undefined && diagnostics[firstIndex]) {
                    position = diagnostics[firstIndex].range.start;
                    selectedIndex = 0;
                }
            }
            else {
                // Find the next diagnostic based on the active line
                while (selectedIndex < sortedIndices.length) {
                    const currentIndex = sortedIndices[selectedIndex];
                    if (currentIndex === undefined || !diagnostics[currentIndex] || diagnostics[currentIndex].range.start.line > activeLine) {
                        break;
                    }
                    selectedIndex++;
                }
                if (selectedIndex >= sortedIndices.length) {
                    selectedIndex = 0;
                }
                const targetIndex = sortedIndices[selectedIndex];
                if (targetIndex !== undefined && diagnostics[targetIndex]) {
                    position = diagnostics[targetIndex].range.start;
                }
            }
        }
        else {
            // Previous error
            selectedIndex = sortedIndices.length - 1;
            // If the active line is less than or equal to the first diagnostic's start line,
            // navigate to the start of the last diagnostic; otherwise, find the previous diagnostic
            const firstIndex = sortedIndices[0];
            if (firstIndex !== undefined && diagnostics[firstIndex] && activeLine <= diagnostics[firstIndex].range.start.line) {
                const lastIndex = sortedIndices[selectedIndex];
                if (lastIndex !== undefined && diagnostics[lastIndex]) {
                    position = diagnostics[lastIndex].range.start;
                }
            }
            else {
                // Find the previous diagnostic based on the active line
                while (selectedIndex >= 0) {
                    const currentIndex = sortedIndices[selectedIndex];
                    if (currentIndex === undefined || !diagnostics[currentIndex] || diagnostics[currentIndex].range.start.line < activeLine) {
                        break;
                    }
                    selectedIndex--;
                }
                if (selectedIndex < 0) {
                    selectedIndex = sortedIndices.length - 1;
                }
                const targetIndex = sortedIndices[selectedIndex];
                if (targetIndex !== undefined && diagnostics[targetIndex]) {
                    position = diagnostics[targetIndex].range.start;
                }
            }
        }
        // Check if we have a valid position
        if (!position) {
            this.showMessage('Unable to navigate to diagnostic position');
            return;
        }
        // Reveal the range of the diagnostic in the editor
        const finalIndex = sortedIndices[selectedIndex];
        if (finalIndex !== undefined && diagnostics[finalIndex]) {
            editor.revealRange(diagnostics[finalIndex].range, vscode_1.TextEditorRevealType.InCenter);
        }
        // Display the diagnostic message in the output channel
        this.displayDiagnosticMessage(diagnostics, position);
        // Set the editor selection to the diagnostic's start position
        editor.selection = new vscode_1.Selection(position, position);
        this.outputChannel.show(true);
    }
    /**
     * Update sorted diagnostic indices for a document
     */
    updateSortedDiagnosticIndex(documentUri, diagnostics) {
        const index = diagnostics
            .map((diag, i) => {
            return [diag.range.start.line, i];
        })
            .sort((a, b) => {
            return a[0] - b[0];
        });
        this.sortedDiagIndex[documentUri] = index.map(item => item[1]);
    }
    /**
     * Display diagnostic message in output channel
     */
    displayDiagnosticMessage(diagnostics, position) {
        diagnostics.forEach(item => {
            if (item.range.start.line === position.line) {
                const severity = item.severity === vscode_1.DiagnosticSeverity.Error ? 'ERROR:\t\t' : 'Warning:\t';
                this.outputChannel.append(severity + item.message + '\n');
            }
        });
    }
    /**
     * Show message in output channel
     */
    showMessage(message) {
        this.outputChannel.clear();
        this.outputChannel.append(message + '\n');
        this.outputChannel.show(true);
    }
    /**
     * Display all diagnostics for a document in output channel
     */
    displayAllDiagnostics(documentPath, diagnostics) {
        if (!diagnostics || diagnostics.length === 0) {
            return;
        }
        const sortedIndices = this.sortedDiagIndex[documentPath];
        if (!sortedIndices) {
            return;
        }
        this.outputChannel.clear();
        for (let i = 0; i < sortedIndices.length; i++) {
            const diagIndex = sortedIndices[i];
            if (diagIndex !== undefined && diagIndex < diagnostics.length) {
                const diag = diagnostics[diagIndex];
                if (diag) {
                    const severity = diag.severity === vscode_1.DiagnosticSeverity.Error ? 'ERROR' : 'Warning';
                    const msg = `${path.basename(documentPath)}:${diag.range.start.line + 1}:\t${severity}:\t${diag.message}\n`;
                    this.outputChannel.append(msg);
                }
            }
        }
        if (sortedIndices.length > 0) {
            this.outputChannel.show(true);
        }
    }
    /**
     * Get diagnostic count for a document
     */
    getDiagnosticCount(documentUri) {
        const editor = vscode_1.window.activeTextEditor;
        if (!editor) {
            return { errors: 0, warnings: 0, total: 0 };
        }
        const diagnostics = this.diagnosticCollection.get(editor.document.uri);
        if (!diagnostics) {
            return { errors: 0, warnings: 0, total: 0 };
        }
        let errors = 0;
        let warnings = 0;
        diagnostics.forEach(diagnostic => {
            if (diagnostic.severity === vscode_1.DiagnosticSeverity.Error) {
                errors++;
            }
            else if (diagnostic.severity === vscode_1.DiagnosticSeverity.Warning) {
                warnings++;
            }
        });
        return { errors, warnings, total: errors + warnings };
    }
    /**
     * Clear navigation state for a document
     */
    clearNavigationState(documentUri) {
        delete this.sortedDiagIndex[documentUri];
    }
    /**
     * Check if navigation is available for current document
     */
    isNavigationAvailable() {
        const editor = vscode_1.window.activeTextEditor;
        if (!editor) {
            return false;
        }
        const diagnostics = this.diagnosticCollection.get(editor.document.uri);
        return diagnostics !== undefined && diagnostics.length > 0;
    }
}
exports.NavigationProvider = NavigationProvider;
//# sourceMappingURL=navigationProvider.js.map