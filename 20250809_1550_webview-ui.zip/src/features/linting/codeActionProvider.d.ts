import { type CancellationToken, type CodeActionContext, type Command, type Range, type TextDocument } from 'vscode';
import { type ICodeActionProvider } from './interfaces';
/**
 * Provides code actions for Prolog linting diagnostics
 */
export declare class CodeActionProvider implements ICodeActionProvider {
    private commandAddDynamicId;
    private commandAddUseModuleId;
    constructor();
    /**
     * Provide code actions for diagnostics
     */
    provideCodeActions(document: TextDocument, range: Range, context: CodeActionContext, _token: CancellationToken): Command[] | Promise<Command[]>;
    /**
     * Get command IDs used by this provider
     */
    getCommandIds(): {
        addDynamic: string;
        addUseModule: string;
    };
    /**
     * Check if a diagnostic is handled by this provider
     */
    canHandleDiagnostic(message: string): boolean;
    /**
     * Extract predicate information from diagnostic message
     */
    extractPredicateFromDiagnostic(message: string): string | null;
    /**
     * Get available modules for a predicate
     */
    getAvailableModules(predicate: string): string[];
    /**
     * Extract current module from document
     */
    extractCurrentModule(document: TextDocument): string | null;
    /**
     * Normalize predicate name (remove module prefix if it matches current module)
     */
    normalizePredicate(predicate: string, currentModule: string | null): string;
}
//# sourceMappingURL=codeActionProvider.d.ts.map