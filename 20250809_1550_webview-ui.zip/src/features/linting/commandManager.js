"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CommandManager = void 0;
const vscode_1 = require("vscode");
/**
 * Manages VS Code commands for Prolog linting functionality
 */
class CommandManager {
    commandAddDynamic;
    commandAddUseModule;
    commandAddDynamicId;
    commandAddUseModuleId;
    constructor() {
        this.commandAddDynamicId = 'prolog.addDynamicDirective';
        this.commandAddUseModuleId = 'prolog.addUseModule';
    }
    /**
     * Register all commands
     */
    registerCommands() {
        // Register command to dynamically declare a predicate as dynamic in Prolog code
        this.commandAddDynamic = vscode_1.commands.registerCommand(this.commandAddDynamicId, this.addDynamicDirective, this);
        // Register command to include a Prolog module in the code
        this.commandAddUseModule = vscode_1.commands.registerCommand(this.commandAddUseModuleId, this.addUseModule, this);
    }
    /**
     * Dispose of all registered commands
     */
    dispose() {
        if (this.commandAddDynamic) {
            this.commandAddDynamic.dispose();
        }
        if (this.commandAddUseModule) {
            this.commandAddUseModule.dispose();
        }
    }
    /**
     * Add a dynamic directive to the document
     */
    async addDynamicDirective(doc, predicate, uri, range) {
        const edit = new vscode_1.WorkspaceEdit();
        const line = this.getDirectiveLines(doc, 'dynamic', range)[0];
        const text = doc.lineAt(line || 0).text;
        let pos;
        // Check if an existing 'dynamic' declaration is present
        if (/:-\s+\(?dynamic/.test(text)) {
            // If present, find the start character of the list and position the cursor after it
            const startChar = text.indexOf('dynamic') + 7;
            pos = new vscode_1.Position(line || 0, startChar);
            edit.insert(uri, pos, ' ' + predicate + ',');
        }
        else {
            // If not present, insert a new 'dynamic' declaration with the specified predicate
            pos = new vscode_1.Position(line || 0, 0);
            edit.insert(uri, pos, ':- dynamic ' + predicate + '.\n');
        }
        // Apply the WorkspaceEdit to the document
        try {
            const result = await Promise.resolve(vscode_1.workspace.applyEdit(edit));
            return result;
        }
        catch (e) {
            console.log('Error in add dynamic declaration: ' + e);
            return false;
        }
    }
    /**
     * Add a "use_module" directive to the document
     */
    async addUseModule(doc, predicate, module, uri, range) {
        const edit = new vscode_1.WorkspaceEdit();
        const lines = this.getDirectiveLines(doc, 'use_module', range);
        const pred = predicate.match(/(.+)\/\d+/)?.[1] || predicate;
        const re = new RegExp('^:-\\s+use_module\\s*\\(\\s*.+\\b' + module + '\\b');
        let directiveLine = -1;
        let pos;
        // Iterate through the lines to find an existing 'use_module' directive with the specified module
        lines.forEach(line => {
            if (re.test(doc.lineAt(line).text)) {
                directiveLine = line;
            }
        });
        // If an existing directive is found, add the predicate to the existing list
        if (directiveLine >= 0) {
            let line = directiveLine;
            // Move down to find the position where the predicate should be added
            while (doc.lineAt(line).text.indexOf('[') < 0)
                line++;
            // Find the start character of the list and position the cursor after it
            const startChar = doc.lineAt(line).text.indexOf('[');
            pos = new vscode_1.Position(line, startChar + 1);
            edit.insert(uri, pos, predicate + ',');
        }
        else {
            // If no existing directive is found, add a new 'use_module' directive
            pos = new vscode_1.Position(lines[lines.length - 1], 0);
            edit.insert(uri, pos, `:- use_module(library(${module}), [${predicate}]).\n`);
        }
        // Apply the WorkspaceEdit to the document
        try {
            const result = await Promise.resolve(vscode_1.workspace.applyEdit(edit));
            return result;
        }
        catch (e) {
            console.log('Error in add use_module declaration: ' + e);
            return false;
        }
    }
    /**
     * Get lines where a directive should be added based on predicate and range
     */
    getDirectiveLines(doc, declarativePredicate, range) {
        const textlines = doc.getText().split('\n');
        const re = new RegExp('^\\s*:-\\s+\\(?\\s*' + declarativePredicate + '\\b');
        let lines = [];
        let line = 0;
        while (line < textlines.length) {
            if (re.test(textlines[line] || '')) {
                lines = lines.concat(line);
            }
            line++;
        }
        // If lines with the directive are found, return the array of line numbers
        if (lines.length > 0) {
            return lines;
        }
        line = -1;
        // Find the first line starting with ":-"
        textlines.filter((item, index) => {
            if (/^\s*:-/.test(item)) {
                line = index;
                return true;
            }
        });
        // Continue iterating to find the end of the directive or the end of the document
        while (line >= 0 && line < textlines.length && !/.+\.(\s*%.*)*/.test(textlines[line] || '')) {
            line++;
        }
        // If the line is before the specified range, return an array with the next line
        if (line >= 0 && line < range.start.line) {
            return [++line];
        }
        line = 0;
        // Check for the presence of a comment block at the beginning of the document
        let inComment = /\s*\/\*/.test(textlines[0]);
        // Continue iterating until the end of the comment block is found
        while (inComment && line < textlines.length) {
            if (/\*\//.test(textlines[line] || '')) {
                inComment = false;
                line++;
                break;
            }
            line++;
        }
        // Return an array with the line number after the comment block
        return [line];
    }
    /**
     * Get command IDs
     */
    getCommandIds() {
        return {
            addDynamic: this.commandAddDynamicId,
            addUseModule: this.commandAddUseModuleId,
        };
    }
    /**
     * Check if a directive exists in the document
     */
    hasDirective(doc, directive) {
        const text = doc.getText();
        const regex = new RegExp(`:-\\s*${directive}\\b`);
        return regex.test(text);
    }
    /**
     * Find existing use_module directives for a module
     */
    findUseModuleDirectives(doc, module) {
        const lines = [];
        const textlines = doc.getText().split('\n');
        const regex = new RegExp(`:-\\s*use_module\\s*\\([^)]*\\b${module}\\b`);
        textlines.forEach((line, index) => {
            if (regex.test(line)) {
                lines.push(index);
            }
        });
        return lines;
    }
    /**
     * Extract predicates from a use_module directive line
     */
    extractPredicatesFromUseModule(lineText) {
        const match = lineText.match(/\[([^\]]+)\]/);
        if (!match) {
            return [];
        }
        return match[1]
            .split(',')
            .map(pred => pred.trim())
            .filter(pred => pred.length > 0);
    }
    /**
     * Check if a predicate is already in a use_module directive
     */
    isPredicateInUseModule(doc, module, predicate) {
        const lines = this.findUseModuleDirectives(doc, module);
        for (const lineIndex of lines) {
            const lineText = doc.lineAt(lineIndex).text;
            const predicates = this.extractPredicatesFromUseModule(lineText);
            if (predicates.includes(predicate)) {
                return true;
            }
        }
        return false;
    }
}
exports.CommandManager = CommandManager;
//# sourceMappingURL=commandManager.js.map