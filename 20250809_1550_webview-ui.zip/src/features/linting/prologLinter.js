"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const vscode_1 = require("vscode");
const installationGuide_1 = require("../installationGuide");
const configurationManager_1 = require("./configurationManager");
const processExecutor_1 = require("./processExecutor");
const diagnosticParser_1 = require("./diagnosticParser");
const codeActionProvider_1 = require("./codeActionProvider");
const navigationProvider_1 = require("./navigationProvider");
const commandManager_1 = require("./commandManager");
const interfaces_1 = require("./interfaces");
/**
 * Main Prolog Linter class that orchestrates all linting functionality
 * Now refactored into a modular architecture with separated concerns
 */
class PrologLinter {
    context;
    // Core modules
    configurationManager;
    processExecutor;
    diagnosticParser;
    codeActionProvider;
    navigationProvider;
    commandManager;
    // VS Code integration
    diagnosticCollection;
    diagnostics = {};
    outputChannel = null;
    // Document listeners
    documentListener;
    openDocumentListener;
    timer = null;
    constructor(context) {
        this.context = context;
        // Initialize all modules
        this.configurationManager = new configurationManager_1.ConfigurationManager();
        this.processExecutor = new processExecutor_1.ProcessExecutor(context);
        this.diagnosticParser = new diagnosticParser_1.DiagnosticParser();
        this.codeActionProvider = new codeActionProvider_1.CodeActionProvider();
        // Initialize output channel
        this.initializeOutputChannel();
        // Initialize navigation and command managers (they need the diagnostic collection)
        this.diagnosticCollection = vscode_1.languages.createDiagnosticCollection();
        this.navigationProvider = new navigationProvider_1.NavigationProvider(this.diagnosticCollection, this.outputChannel);
        this.commandManager = new commandManager_1.CommandManager();
    }
    /**
     * Initialize the output channel
     */
    initializeOutputChannel() {
        if (this.outputChannel === null) {
            this.outputChannel = vscode_1.window.createOutputChannel('PrologLinter');
            this.outputChannel.clear();
        }
    }
    /**
     * Implementation of CodeActionProvider interface method
     */
    provideCodeActions(document, range, context, token) {
        return this.codeActionProvider.provideCodeActions(document, range, context, token);
    }
    /**
     * Perform linting of a Prolog file
     */
    async doPlint(textDocument) {
        // Check if the language of the document is Prolog
        if (textDocument.languageId !== 'prolog') {
            return;
        }
        // Clear existing diagnostics
        this.diagnostics = {};
        this.diagnosticCollection.delete(textDocument.uri);
        try {
            // Load configuration
            const config = await this.configurationManager.loadConfiguration();
            // Clear output if enabled
            if (config.enableOutput && this.outputChannel) {
                this.outputChannel.clear();
            }
            // Execute Prolog process
            const result = await this.processExecutor.executeProlog(textDocument, config);
            // Parse diagnostics
            const diagnosticInfos = this.diagnosticParser.parsePrologOutput(result.stdout, result.stderr, textDocument);
            // Convert to VS Code diagnostics and group by file
            const groupedDiagnostics = this.diagnosticParser.groupDiagnosticsByFile(diagnosticInfos);
            // Update diagnostic collection
            for (const [fileName, infos] of Object.entries(groupedDiagnostics)) {
                const diagnostics = infos.map(info => this.diagnosticParser.convertToDiagnostic(info));
                this.diagnostics[fileName] = diagnostics;
                this.diagnosticCollection.set(vscode_1.Uri.file(fileName), diagnostics);
                // Update navigation provider
                this.navigationProvider.updateSortedDiagnosticIndex(fileName, diagnostics);
                // Display diagnostics in output if enabled
                if (config.enableOutput && this.outputChannel) {
                    this.navigationProvider.displayAllDiagnostics(fileName, diagnostics);
                }
            }
        }
        catch (error) {
            await this.handleLintingError(error);
        }
    }
    /**
     * Handle linting errors with enhanced error messages and installation guidance
     */
    async handleLintingError(error) {
        let message = null;
        if (error.message === 'PROLOG_EXECUTABLE_NOT_FOUND' || error.code === 'ENOENT') {
            message =
                "Cannot lint the prolog file. The Prolog executable was not found. Use the 'prolog.executablePath' setting to configure";
            // Show enhanced error message with installation guidance
            const action = await vscode_1.window.showErrorMessage('SWI-Prolog executable not found. The linter requires SWI-Prolog to check your code for errors and warnings.', 'Install SWI-Prolog', 'Setup Wizard', 'Configure Path', 'Dismiss');
            const installationGuide = installationGuide_1.InstallationGuide.getInstance();
            switch (action) {
                case 'Install SWI-Prolog': {
                    await installationGuide.showInstallationGuideDialog();
                    break;
                }
                case 'Setup Wizard': {
                    await vscode_1.commands.executeCommand('prolog.setupWizard');
                    break;
                }
                case 'Configure Path': {
                    await vscode_1.commands.executeCommand('workbench.action.openSettings', 'prolog.executablePath');
                    break;
                }
                default:
                    break;
            }
        }
        else {
            message = error.message
                ? error.message
                : `Failed to run prolog executable. Reason is unknown.`;
        }
        this.outputMsg(message);
    }
    /**
     * Load configuration settings and set up listeners
     */
    async loadConfiguration() {
        try {
            const config = await this.configurationManager.loadConfiguration();
            // Dispose existing listeners
            if (this.documentListener) {
                this.documentListener.dispose();
            }
            if (this.openDocumentListener) {
                this.openDocumentListener.dispose();
            }
            // Set up open document listener
            this.openDocumentListener = vscode_1.workspace.onDidOpenTextDocument(e => {
                this.triggerLinter(e);
            });
            // Set up document change/save listeners based on trigger
            if (config.trigger === interfaces_1.RunTrigger.onType) {
                this.documentListener = vscode_1.workspace.onDidChangeTextDocument(e => {
                    this.triggerLinter(e.document);
                });
            }
            else if (config.trigger === interfaces_1.RunTrigger.onSave) {
                if (this.timer) {
                    clearTimeout(this.timer);
                }
                this.documentListener = vscode_1.workspace.onDidSaveTextDocument(this.doPlint, this);
            }
            // Trigger linting for existing documents
            vscode_1.workspace.textDocuments.forEach(this.triggerLinter, this);
        }
        catch (error) {
            console.error('Failed to load linter configuration:', error);
            this.outputMsg(`Configuration error: ${error.message || error}`);
        }
    }
    /**
     * Trigger linting based on configuration
     */
    triggerLinter(textDocument) {
        // Check if the document is a Prolog source file
        if (textDocument.languageId !== 'prolog') {
            return;
        }
        const config = this.configurationManager.getCurrentConfiguration();
        if (!config) {
            return;
        }
        // If the linter is set to trigger on type with delay, use a timer
        if (config.trigger === interfaces_1.RunTrigger.onType) {
            if (this.timer) {
                clearTimeout(this.timer);
            }
            this.timer = setTimeout(() => {
                this.doPlint(textDocument);
            }, config.delay);
        }
        else if (config.trigger !== interfaces_1.RunTrigger.never) {
            // Trigger linting immediately for onSave
            this.doPlint(textDocument);
        }
    }
    /**
     * Activate the linter
     */
    activate() {
        const subscriptions = this.context.subscriptions;
        // Register commands
        this.commandManager.registerCommands();
        // Register configuration change listener
        vscode_1.workspace.onDidChangeConfiguration(() => this.loadConfiguration(), this, subscriptions);
        // Load initial configuration
        this.loadConfiguration();
        // Register listeners based on trigger
        vscode_1.workspace.onDidCloseTextDocument(textDocument => {
            this.diagnosticCollection.delete(textDocument.uri);
            this.navigationProvider.clearNavigationState(textDocument.uri.fsPath);
        }, null, subscriptions);
    }
    /**
     * Output message to console
     */
    outputMsg(msg) {
        if (this.outputChannel) {
            this.outputChannel.append(msg + '\n');
            this.outputChannel.show(true);
        }
    }
    /**
     * Navigate to next error line
     */
    nextErrLine() {
        this.navigationProvider.gotoNextError();
    }
    /**
     * Navigate to previous error line
     */
    prevErrLine() {
        this.navigationProvider.gotoPrevError();
    }
    /**
     * Get diagnostic collection for external use
     */
    getDiagnosticCollection() {
        return this.diagnosticCollection;
    }
    /**
     * Check if navigation is available
     */
    isNavigationAvailable() {
        return this.navigationProvider.isNavigationAvailable();
    }
    /**
     * Get diagnostic count for current document
     */
    getDiagnosticCount() {
        const editor = vscode_1.window.activeTextEditor;
        if (!editor) {
            return { errors: 0, warnings: 0, total: 0 };
        }
        return this.navigationProvider.getDiagnosticCount(editor.document.uri.fsPath);
    }
    /**
     * Cleanup method to dispose of resources when the extension is deactivated
     */
    dispose() {
        if (this.documentListener) {
            this.documentListener.dispose();
        }
        if (this.openDocumentListener) {
            this.openDocumentListener.dispose();
        }
        if (this.diagnosticCollection) {
            this.diagnosticCollection.clear();
            this.diagnosticCollection.dispose();
        }
        if (this.commandManager) {
            this.commandManager.dispose();
        }
        if (this.timer) {
            clearTimeout(this.timer);
        }
    }
}
exports.default = PrologLinter;
//# sourceMappingURL=prologLinter.js.map