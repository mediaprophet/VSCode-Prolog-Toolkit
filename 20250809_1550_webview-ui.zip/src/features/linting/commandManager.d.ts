import { Range, TextDocument, Uri } from 'vscode';
import { ICommandManager } from './interfaces';
/**
 * Manages VS Code commands for Prolog linting functionality
 */
export declare class CommandManager implements ICommandManager {
    private commandAddDynamic;
    private commandAddUseModule;
    private commandAddDynamicId;
    private commandAddUseModuleId;
    constructor();
    /**
     * Register all commands
     */
    registerCommands(): void;
    /**
     * Dispose of all registered commands
     */
    dispose(): void;
    /**
     * Add a dynamic directive to the document
     */
    addDynamicDirective(doc: TextDocument, predicate: string, uri: Uri, range: Range): Promise<boolean>;
    /**
     * Add a "use_module" directive to the document
     */
    addUseModule(doc: TextDocument, predicate: string, module: string, uri: Uri, range: Range): Promise<boolean>;
    /**
     * Get lines where a directive should be added based on predicate and range
     */
    private getDirectiveLines;
    /**
     * Get command IDs
     */
    getCommandIds(): {
        addDynamic: string;
        addUseModule: string;
    };
    /**
     * Check if a directive exists in the document
     */
    hasDirective(doc: TextDocument, directive: string): boolean;
    /**
     * Find existing use_module directives for a module
     */
    findUseModuleDirectives(doc: TextDocument, module: string): number[];
    /**
     * Extract predicates from a use_module directive line
     */
    extractPredicatesFromUseModule(lineText: string): string[];
    /**
     * Check if a predicate is already in a use_module directive
     */
    isPredicateInUseModule(doc: TextDocument, module: string, predicate: string): boolean;
}
//# sourceMappingURL=commandManager.d.ts.map