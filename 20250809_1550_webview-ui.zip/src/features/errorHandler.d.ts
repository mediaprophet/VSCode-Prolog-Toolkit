export interface PrologError {
    code: string;
    type: 'syntax' | 'runtime' | 'system' | 'network' | 'permission' | 'resource' | 'user';
    message: string;
    details?: string;
    suggestion?: string;
    documentation?: string;
    line?: number;
    column?: number;
    file?: string;
    context?: string;
    severity: 'error' | 'warning' | 'info';
}
export interface ErrorContext {
    command?: string;
    query?: string;
    file?: string;
    operation?: string;
    userInput?: string;
}
export declare class ErrorHandler {
    private errorCodes;
    private locale;
    constructor(locale?: string);
    /**
     * Initialize common error codes and their descriptions
     */
    private initializeErrorCodes;
    /**
     * Process and format an error for display
     */
    handleError(error: unknown, context?: ErrorContext): PrologError;
    /**
     * Parse various error formats into standardized PrologError
     */
    private parseError;
    /**
     * Parse string error messages
     */
    private parseStringError;
    /**
     * Parse Error objects
     */
    private parseErrorObject;
    /**
     * Parse Prolog error terms
     */
    private parsePrologErrorTerm;
    /**
     * Parse formal Prolog errors
     */
    private parseFormalError;
    /**
     * Parse HTTP errors
     */
    private parseHttpError;
    /**
     * Parse structured error objects
     */
    private parseStructuredError;
    /**
     * Create a standardized error object
     */
    private createError;
    /**
     * Create a generic error for unknown error types
     */
    private createGenericError;
    /**
     * Format error for display in chat
     */
    formatError(error: PrologError): string;
    /**
     * Get appropriate icon for error type
     */
    private getErrorIcon;
    /**
     * Log error for debugging
     */
    private logError;
    /**
     * Show error notification to user
     */
    showErrorNotification(error: PrologError): void;
    /**
     * Add or update error code definition
     */
    addErrorCode(code: string, definition: Partial<PrologError>): void;
    /**
     * Get all registered error codes
     */
    getErrorCodes(): Map<string, Partial<PrologError>>;
    /**
     * Set locale for error messages
     */
    setLocale(locale: string): void;
    /**
     * Create user-friendly error message for common mistakes
     */
    createUserFriendlyError(userInput: string, originalError: unknown): PrologError;
}
/**
 * Default error handler instance
 */
export declare const defaultErrorHandler: ErrorHandler;
/**
 * Create error handler with specific locale
 */
export declare function createErrorHandler(locale: string): ErrorHandler;
//# sourceMappingURL=errorHandler.d.ts.map