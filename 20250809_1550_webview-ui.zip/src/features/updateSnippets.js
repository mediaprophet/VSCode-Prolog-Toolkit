"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrologCompletionProvider = exports.SnippetUpdaterController = exports.SnippetUpdater = void 0;
const fs = __importStar(require("fs"));
const vscode_1 = require("vscode");
const positionUtils_1 = require("../utils/positionUtils");
const utils_1 = require("../utils/utils");
// Class responsible for updating snippets based on prolog files
class SnippetUpdater {
    // Update snippets based on new predicates create by the user in the document
    updateSnippet() {
        // Get the currently active text editor
        const editor = vscode_1.window.activeTextEditor;
        if (!editor) {
            return;
        }
        const doc = editor.document;
        // Update only if the document is a prolog file
        if (doc.languageId === 'prolog') {
            // Retrieve predicates from the document and check against existing snippets
            const predicats = this._getPredicat(doc);
            const already = [];
            const description = [];
            // Extract existing snippets' names for comparison
            Object.keys(utils_1.SnippetUtils.snippets ?? {}).forEach(elem => {
                if (elem.includes(':')) {
                    if (elem.includes(':-')) {
                        already.push(elem.replace(':- ', ''));
                    }
                    else {
                        const split = elem.split(':');
                        if (split.length > 1 && typeof split[1] === 'string') {
                            already.push(split[1]);
                        }
                    }
                }
                else {
                    already.push(elem);
                }
                if (utils_1.SnippetUtils.snippets?.[elem]?.description && typeof utils_1.SnippetUtils.snippets[elem].description === 'string' && utils_1.SnippetUtils.snippets[elem].description.includes('\ncustom predicate\n')) {
                    description.push(false);
                }
                else {
                    description.push(true);
                }
            });
            // Update snippets based on new predicates in the document
            predicats.forEach(elem => {
                const num = elem[1].split(',').length;
                const snippetKey = elem[0] + '/' + num.toString();
                if (!already.includes(snippetKey)) {
                    if (elem[2] == null) {
                        utils_1.SnippetUtils.snippets[snippetKey] = {
                            prefix: elem[0],
                            body: [''],
                            description: elem[0].toString() + '(' + elem[1].toString() + ')\ncustom predicate\n\n',
                        };
                    }
                    else {
                        utils_1.SnippetUtils.snippets[snippetKey] = {
                            prefix: elem[0],
                            body: [''],
                            description: elem[0].toString() + '(' + elem[1].toString() + ')\n' + elem[2] + '\n',
                        };
                    }
                }
                else if (elem[2] != null) {
                    const idx = already.indexOf(snippetKey);
                    const keyToDelete = Object.keys(utils_1.SnippetUtils.snippets)[idx];
                    if (keyToDelete !== undefined) {
                        delete utils_1.SnippetUtils.snippets[keyToDelete];
                    }
                    utils_1.SnippetUtils.snippets[snippetKey] = {
                        prefix: elem[0],
                        body: [''],
                        description: elem[0].toString() + '(' + elem[1].toString() + ')\n' + elem[2] + '\n',
                    };
                }
            });
            // Generate predicate modules based on the updated context
            utils_1.SnippetUtils.genPredicateModules();
        }
    }
    // Extracts predicates from the given TextDocument
    _getPredicat(doc) {
        const docContent = doc.getText(); // Get the content of the document
        const regexp = /(^\s*)([a-z][a-zA-Z0-9_]*)\(([a-zA-Z0-9_\-, ]*)\)(?=.*(:-|=>|-->).*)/gm; // Regular expression for matching Prolog predicates
        const regexpModule = /^\s*:-\s*use_module\(([a-z][a-zA-Z0-9_/]*)\s*(,|\)\s*\.)/gm; // Regular expression for matching Prolog use_module directives
        const regexpComment = /^\s*(%(?!!)|%!|\*(?!\/)|\/\*\*)(\s*)(.*)/gm; // Regular expression for matching Prolog comments
        const arrayModule = [...docContent.matchAll(regexpModule)]; // Extract all use_module directives from the document
        const prolog = doc.fileName.split('.')[1]; // Get the Prolog extension from the document's file name
        let predicats = [];
        // Loop through each use_module directive
        for (let i = 0; i < arrayModule.length; i++) {
            // Read the content of the referenced module
            let text = '';
            try {
                const wsFolders = vscode_1.workspace.workspaceFolders;
                const moduleArr = arrayModule[i];
                const moduleName = Array.isArray(moduleArr) && moduleArr.length > 1 ? moduleArr[1] : undefined;
                if (wsFolders && wsFolders.length > 0 && wsFolders[0]?.uri?.fsPath && typeof moduleName === 'string') {
                    text = fs.readFileSync(wsFolders[0].uri.fsPath + '/' + moduleName + '.' + prolog, 'utf8');
                }
            }
            catch (error) {
                console.error('Error reading file:', error);
            }
            // Extract predicates from the referenced module's content
            const array2 = [...text.matchAll(regexp)];
            array2.forEach(elem => {
                if (!elem || typeof elem.index !== 'number' || typeof elem[1] !== 'string')
                    return;
                const pos = positionUtils_1.PositionUtils.findLineColForByte(text, elem.index + elem[1].length);
                let nbline = pos ? pos.line - 1 : -1;
                const lines = text.split(/\n|\r/);
                let verif = true;
                let comment = '';
                while (verif && nbline > -1) {
                    const res = lines[nbline]?.matchAll(regexpComment).next();
                    if (res && res.value) {
                        if (res.value[1] !== '*/' && res.value[1] !== '/**') {
                            if (comment === '' && typeof res.value[3] === 'string') {
                                comment = res.value[3];
                            }
                            else if (res.value[3]) {
                                comment = res.value[3] + '\n' + comment;
                            }
                        }
                        if (res.value[1] === '%!' || res.value[1] === '/**') {
                            verif = false;
                        }
                        nbline = nbline - 1;
                    }
                    else {
                        comment = null;
                        verif = false;
                    }
                }
                predicats.push([elem[2], elem[3], comment ?? '']);
            });
        }
        // Extract predicates from the current document
        const array = [...docContent.matchAll(regexp)];
        // Search for definition comments
        array.forEach(elem => {
            if (!elem || typeof elem.index !== 'number' || typeof elem[1] !== 'string')
                return;
            const pos = positionUtils_1.PositionUtils.findLineColForByte(docContent, elem.index + elem[1].length);
            let nbline = pos ? pos.line - 1 : -1;
            const lines = docContent.split('\n');
            let verif = true;
            let comment = '';
            while (verif && nbline > -1) {
                const res = lines[nbline]?.matchAll(regexpComment).next();
                if (res && res.value) {
                    if (res.value[1] !== '*/' && res.value[1] !== '/**') {
                        if (comment === '' && typeof res.value[3] === 'string') {
                            comment = res.value[3];
                        }
                        else if (res.value[3]) {
                            comment = res.value[3] + '\n' + comment;
                        }
                    }
                    if (res.value[1] === '%!' || res.value[1] === '/**') {
                        verif = false;
                    }
                    nbline = nbline - 1;
                }
                else {
                    comment = null;
                    verif = false;
                }
            }
            predicats.push([elem[2], elem[3], comment ?? '']);
        });
        // Filter out a specific predicate named "test"
        predicats = predicats.filter(function (predicat) {
            return predicat[0] != 'test';
        });
        return predicats;
    }
    dispose() {
        // No resources to dispose
    }
}
exports.SnippetUpdater = SnippetUpdater;
// Class responsible for managing the SnippetUpdater and subscribing to relevant events
class SnippetUpdaterController {
    snippetUpdater;
    _disposable;
    constructor(snippetUpdater) {
        this.snippetUpdater = snippetUpdater;
        this.snippetUpdater.updateSnippet(); // Update snippets initially
        // subscribe to selection change and editor activation events
        const subscriptions = [];
        vscode_1.workspace.onDidSaveTextDocument(this._onEvent, this, subscriptions);
        vscode_1.window.onDidChangeActiveTextEditor(this._onEvent, this, subscriptions);
        // update the counter for the current file
        this.snippetUpdater.updateSnippet();
        // create a combined disposable from both event subscriptions
        this._disposable = vscode_1.Disposable.from(...subscriptions);
    }
    dispose() {
        this._disposable.dispose();
    }
    _onEvent() {
        this.snippetUpdater.updateSnippet();
    }
}
exports.SnippetUpdaterController = SnippetUpdaterController;
class PrologCompletionProvider {
    // Provides completion items for Prolog code (auto completion)
    provideCompletionItems(document, position, token, context) {
        // Array to store completion items
        const snippetCompletion = [];
        // Iterate through new snippets and create completion items
        // Removed legacy Utils.newsnippets usage (no longer present in utils)
        return snippetCompletion; // Return the array of completion items
    }
}
exports.PrologCompletionProvider = PrologCompletionProvider;
//# sourceMappingURL=updateSnippets.js.map