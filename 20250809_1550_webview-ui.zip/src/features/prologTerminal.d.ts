import { Disposable } from 'vscode';
export default class PrologTerminal {
    private static _terminal;
    private static _document;
    private static _platform;
    private static _shellInfo;
    constructor();
    static init(): Disposable;
    /**
     * Detect the default shell for the current platform
     */
    private static detectShell;
    /**
     * Detect Windows shell (PowerShell, Command Prompt, WSL)
     */
    private static detectWindowsShell;
    /**
     * Detect macOS shell (zsh, bash)
     */
    private static detectMacOSShell;
    /**
     * Detect Linux shell (bash, zsh, fish, etc.)
     */
    private static detectLinuxShell;
    /**
     * Test if a command is available
     */
    private static testCommand;
    /**
     * Get platform-specific terminal configuration
     */
    private static getTerminalConfig;
    /**
     * Escape command arguments for the detected shell
     */
    private static escapeForShell;
    private static createPrologTerm;
    /**
     * Send initial setup commands to configure the terminal environment
     */
    private static sendInitialSetupCommands;
    /**
     * Handle terminal creation errors with enhanced error messages and recovery options
     */
    private static handleTerminalCreationError;
    static sendString(text: string): Promise<void>;
    static loadDocument(): Promise<void>;
    static queryGoalUnderCursor(): void;
}
//# sourceMappingURL=prologTerminal.d.ts.map