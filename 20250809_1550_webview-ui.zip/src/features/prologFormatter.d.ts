import { CancellationToken, DocumentFormattingEditProvider, DocumentRangeFormattingEditProvider, FormattingOptions, ProviderResult, Range, TextDocument, TextEdit } from 'vscode';
export declare class PrologFormatter implements DocumentRangeFormattingEditProvider, DocumentFormattingEditProvider {
    private _section;
    private _tabSize;
    private _insertSpaces;
    private _tabDistance;
    private _executable;
    private _args;
    private _outputChannel;
    private _textEdits;
    private _startChars;
    constructor();
    /**
     * Initialize executable with enhanced detection and permission checking
     */
    private initializeExecutable;
    private handleExecutableError;
    provideDocumentRangeFormattingEdits(doc: TextDocument, range: Range, _options: FormattingOptions, _token: CancellationToken): ProviderResult<TextEdit[]>;
    provideDocumentFormattingEdits(document: TextDocument, _options: FormattingOptions, _token: CancellationToken): ProviderResult<TextEdit[]>;
    private getClauseString;
    private formatClause;
    private formatNested;
}
//# sourceMappingURL=prologFormatter.d.ts.map