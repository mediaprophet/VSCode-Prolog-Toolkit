"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Session and State Management System
 * Supports multiple concurrent sessions for different agents or users
 * with state persistence and resource isolation
 */
/**
 * DEPRECATED: All logic has been migrated to modular orchestrator and modules.
 * This file now only exports types and interfaces for backward compatibility.
 * Use SessionManagerOrchestrator and related modules instead.
 */
//# sourceMappingURL=sessionManager.js.map