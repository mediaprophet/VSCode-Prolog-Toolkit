"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OutputFilter = void 0;
class OutputFilter {
    // Predefined regex patterns to filter off specific types of output
    static filterPatterns = [
        /^$/, // Empty line
        /^TermToBeEvaluated/,
        /^EvalTermAtom/,
        /^EvalVarNames/,
        /^E =/,
        /^true\./,
    ];
    static shouldFilter(data) {
        const filtered = OutputFilter.filterPatterns.some(reg => reg.test(data));
        if (filtered) {
            console.log('[OutputFilter] Filtered output:', data);
        }
        return filtered;
    }
    static routeOutput(data, type, logFn) {
        if (!OutputFilter.shouldFilter(data)) {
            try {
                logFn(data, type);
                console.log(`[OutputFilter] Routed output [${type}]:`, data);
            }
            catch (err) {
                console.error(`[OutputFilter] Error routing output [${type}]:`, err, data);
            }
        }
        else {
            // Optionally warn on unexpected output types
            if (!['stdout', 'stderr', 'debug', 'user'].includes(type)) {
                console.warn(`[OutputFilter] Unknown output type: ${type}`, data);
            }
        }
    }
}
exports.OutputFilter = OutputFilter;
//# sourceMappingURL=OutputFilter.js.map