export type OutputType = 'stdout' | 'stderr' | 'debug' | 'user';
export declare class OutputFilter {
    private static readonly filterPatterns;
    static shouldFilter(data: string): boolean;
    static routeOutput(data: string, type: OutputType, logFn: (msg: string, type: OutputType) => void): void;
}
//# sourceMappingURL=OutputFilter.d.ts.map