import { BreakpointManager } from './BreakpointManager';
import { OutputFilter } from './OutputFilter';
import { ProcessManager, PrologProcessOptions } from './ProcessManager';
import { ProtocolAdapter } from './ProtocolAdapter';
import { StackFrameManager } from './StackFrameManager';
import { VariableManager } from './VariableManager';
export declare class DebuggerController {
    readonly processManager: ProcessManager;
    readonly protocolAdapter: ProtocolAdapter;
    readonly breakpointManager: BreakpointManager;
    readonly stackFrameManager: StackFrameManager;
    readonly variableManager: VariableManager;
    readonly outputFilter: typeof OutputFilter;
    constructor(options: PrologProcessOptions);
    startProcess(): Promise<void>;
    killProcess(): void;
}
//# sourceMappingURL=DebuggerController.d.ts.map