export interface IVariable {
    name: string;
    value: string;
    variablesReference?: number;
    type?: string;
    evaluateName?: string;
    children?: IVariable[];
}
export declare class VariableManager {
    private _variables;
    setVariables(vars: IVariable[]): void;
    getVariables(): IVariable[];
    clearVariables(): void;
    findVariable(name: string): IVariable | undefined;
    evaluate(expression: string): string | null;
    getChildren(variable: IVariable): IVariable[];
}
//# sourceMappingURL=VariableManager.d.ts.map