import { EventEmitter } from 'events';
export type ProtocolMessage = Record<string, any>;
export interface ProtocolAdapterEvents {
    breakpoints: (data: any) => void;
    functionBreakpoints: (data: any) => void;
    frame: (data: any) => void;
    variables: (data: any) => void;
    error: (err: Error) => void;
    unknown: (data: any) => void;
}
export declare class ProtocolAdapter extends EventEmitter {
    constructor();
    /**
     * Parse and dispatch a protocol message string.
     * Emits events for recognized message types, or 'unknown' for unrecognized.
     */
    handleProtocolData(data: string): void;
    /**
     * Handle protocol data with timeout and retry logic.
     * @param data The protocol message string
     * @param timeoutMs Timeout in ms
     * @param maxRetries Number of retries
     */
    handleProtocolDataWithRetry(data: string, timeoutMs?: number, maxRetries?: number): Promise<void>;
}
//# sourceMappingURL=ProtocolAdapter.d.ts.map