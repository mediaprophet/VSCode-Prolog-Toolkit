"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VariableManager = void 0;
class VariableManager {
    _variables = [];
    setVariables(vars) {
        try {
            this._variables = vars;
        }
        catch (err) {
            console.error('[VariableManager] Error setting variables:', err, vars);
        }
    }
    getVariables() {
        return this._variables;
    }
    clearVariables() {
        this._variables = [];
    }
    findVariable(name) {
        try {
            return this._variables.find(v => v.name === name);
        }
        catch (err) {
            console.error('[VariableManager] Error finding variable:', err, name);
            return undefined;
        }
    }
    evaluate(expression) {
        const variable = this.findVariable(expression);
        return variable ? variable.value : null;
    }
    // Support for complex terms and nested structures
    getChildren(variable) {
        return variable.children || [];
    }
}
exports.VariableManager = VariableManager;
//# sourceMappingURL=VariableManager.js.map