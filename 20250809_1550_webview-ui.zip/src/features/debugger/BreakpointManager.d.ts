import { DebugProtocol } from '@vscode/debugprotocol';
export interface IBreakPoint {
    sourceFile: string;
    line: number;
    column?: number;
    condition?: string;
    hitCondition?: string;
    id?: number | undefined;
}
export declare class BreakpointManager {
    private _breakpoints;
    private _functionBreakpoints;
    private _sourceLineLocations;
    setBreakpoints(source: string, breakpoints: DebugProtocol.Breakpoint[]): void;
    getBreakpoints(): IBreakPoint[];
    clearBreakpoints(): void;
    setFunctionBreakpoints(predicates: string[]): void;
    getFunctionBreakpoints(): string[];
    clearFunctionBreakpoints(): void;
    saveBreakpoints(filePath: string): void;
    loadBreakpoints(filePath: string): void;
    private getSourceLineLocations;
    fromStartCharToLineChar(source: string, startChar: number): {
        file: string;
        line: number;
        startChar: number;
    };
}
//# sourceMappingURL=BreakpointManager.d.ts.map