"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DebuggerController = void 0;
const BreakpointManager_1 = require("./BreakpointManager");
const OutputFilter_1 = require("./OutputFilter");
const ProcessManager_1 = require("./ProcessManager");
const ProtocolAdapter_1 = require("./ProtocolAdapter");
const StackFrameManager_1 = require("./StackFrameManager");
const VariableManager_1 = require("./VariableManager");
class DebuggerController {
    processManager;
    protocolAdapter;
    breakpointManager;
    stackFrameManager;
    variableManager;
    outputFilter;
    constructor(options) {
        this.processManager = new ProcessManager_1.ProcessManager(options);
        this.protocolAdapter = new ProtocolAdapter_1.ProtocolAdapter();
        this.breakpointManager = new BreakpointManager_1.BreakpointManager();
        this.stackFrameManager = new StackFrameManager_1.StackFrameManager();
        this.variableManager = new VariableManager_1.VariableManager();
        this.outputFilter = OutputFilter_1.OutputFilter;
    }
    // Example: expose a clean API for the debug session
    startProcess() {
        return this.processManager.start();
    }
    killProcess() {
        this.processManager.kill();
    }
}
exports.DebuggerController = DebuggerController;
//# sourceMappingURL=DebuggerController.js.map