"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcessManager = void 0;
const events_1 = require("events");
const process_promises_1 = require("process-promises");
const platformUtils_1 = require("../../utils/platformUtils");
class ProcessManager extends events_1.EventEmitter {
    _prologProc = null;
    _options;
    _retryCount = 0;
    constructor(options) {
        super();
        this._options = options;
    }
    async start() {
        this.kill();
        const maxRetries = this._options.maxRetries ?? 2;
        const timeoutMs = this._options.timeoutMs ?? 10000;
        let lastError = null;
        for (this._retryCount = 0; this._retryCount <= maxRetries; this._retryCount++) {
            try {
                const exec = platformUtils_1.PlatformUtils.normalizePath(this._options.runtimeExecutable || 'swipl');
                const args = (this._options.runtimeArgs || []).concat('-q');
                const spawnOpts = {
                    cwd: platformUtils_1.PlatformUtils.normalizePath(this._options.cwd),
                    env: this._options.env || process.env,
                };
                let timeoutHandle;
                const procPromise = new Promise((resolve, reject) => {
                    let started = false;
                    (0, process_promises_1.spawn)(exec, args, spawnOpts)
                        .on('process', (proc) => {
                        this._prologProc = proc;
                        this.emit('process', proc);
                        started = true;
                        console.log(`[ProcessManager] Prolog process started (pid: ${proc.pid})`);
                        resolve();
                    })
                        .on('stdout', (data) => {
                        this.emit('stdout', data);
                        console.log(`[ProcessManager] stdout: ${data}`);
                    })
                        .on('stderr', (err) => {
                        this.emit('stderr', err);
                        console.error(`[ProcessManager] stderr: ${err}`);
                    })
                        .on('exit', (code) => {
                        this.emit('exit', code);
                        console.log(`[ProcessManager] Prolog process exited with code: ${code}`);
                    })
                        .then(() => { })
                        .catch((error) => {
                        const errObj = error instanceof Error ? error : new Error(String(error));
                        this.emit('error', errObj);
                        console.error('[ProcessManager] Error starting process:', errObj);
                        reject(errObj);
                    });
                    timeoutHandle = setTimeout(() => {
                        if (!started) {
                            const err = new Error(`[ProcessManager] Prolog process start timed out after ${timeoutMs}ms`);
                            this.emit('error', err);
                            console.error(err);
                            reject(err);
                        }
                    }, timeoutMs);
                });
                await procPromise;
                if (timeoutHandle)
                    clearTimeout(timeoutHandle);
                return;
            }
            catch (err) {
                lastError = err instanceof Error ? err : new Error(String(err));
                if (this._retryCount < maxRetries) {
                    console.warn(`[ProcessManager] Retry ${this._retryCount + 1} of ${maxRetries} after error:`, lastError);
                }
            }
        }
        if (lastError) {
            this.emit('error', lastError);
            console.error('[ProcessManager] All retries failed:', lastError);
        }
    }
    kill() {
        if (this._prologProc && typeof this._prologProc.kill === 'function') {
            this._prologProc.kill();
            this._prologProc = null;
        }
    }
    get pid() {
        return this._prologProc ? this._prologProc.pid : 0;
    }
    get process() {
        return this._prologProc;
    }
}
exports.ProcessManager = ProcessManager;
//# sourceMappingURL=ProcessManager.js.map