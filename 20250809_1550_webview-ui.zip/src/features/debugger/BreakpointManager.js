"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.BreakpointManager = void 0;
const fs = __importStar(require("fs"));
class BreakpointManager {
    _breakpoints = [];
    _functionBreakpoints = [];
    _sourceLineLocations = {};
    setBreakpoints(source, breakpoints) {
        this._breakpoints = breakpoints
            .filter(bp => typeof bp.line === 'number')
            .map(bp => ({
            sourceFile: source,
            line: bp.line,
            column: bp.column,
            condition: bp.condition,
            hitCondition: bp.hitCondition,
            id: bp.id,
        }));
    }
    getBreakpoints() {
        return this._breakpoints;
    }
    clearBreakpoints() {
        this._breakpoints = [];
    }
    setFunctionBreakpoints(predicates) {
        this._functionBreakpoints = predicates;
    }
    getFunctionBreakpoints() {
        return this._functionBreakpoints;
    }
    clearFunctionBreakpoints() {
        this._functionBreakpoints = [];
    }
    // Persistence (could be extended to use workspace storage)
    saveBreakpoints(filePath) {
        try {
            fs.writeFileSync(filePath, JSON.stringify(this._breakpoints, null, 2));
            console.log(`[BreakpointManager] Breakpoints saved to ${filePath}`);
        }
        catch (err) {
            console.error(`[BreakpointManager] Error saving breakpoints to ${filePath}:`, err);
        }
    }
    loadBreakpoints(filePath) {
        try {
            if (fs.existsSync(filePath)) {
                const data = fs.readFileSync(filePath, 'utf-8');
                this._breakpoints = JSON.parse(data);
                console.log(`[BreakpointManager] Breakpoints loaded from ${filePath}`);
            }
        }
        catch (err) {
            console.error(`[BreakpointManager] Error loading breakpoints from ${filePath}:`, err);
        }
    }
    // Source mapping utilities
    getSourceLineLocations(source) {
        if (this._sourceLineLocations[source]) {
            return;
        }
        try {
            const lines = fs.readFileSync(source).toString().split('\n');
            const lengths = lines.map(line => line.length + 1);
            lengths.unshift(0);
            for (let i = 1; i < lengths.length; i++) {
                if (typeof lengths[i] === 'number' && typeof lengths[i - 1] === 'number') {
                    lengths[i] = (lengths[i] ?? 0) + (lengths[i - 1] ?? 0);
                }
            }
            this._sourceLineLocations[source] = lengths;
        }
        catch (err) {
            console.error(`[BreakpointManager] Error reading source file for line locations: ${source}`, err);
        }
    }
    fromStartCharToLineChar(source, startChar) {
        this.getSourceLineLocations(source);
        let i = 0;
        const locations = this._sourceLineLocations[source];
        if (!locations) {
            return { file: source, line: 1, startChar };
        }
        for (; Array.isArray(locations ?? []) && typeof (locations?.[i]) === 'number' && locations?.[i] !== undefined && locations?.[i] < startChar; i++)
            ;
        return {
            file: source,
            line: i + 1,
            startChar: startChar - (locations[i] ?? 0),
        };
    }
}
exports.BreakpointManager = BreakpointManager;
//# sourceMappingURL=BreakpointManager.js.map