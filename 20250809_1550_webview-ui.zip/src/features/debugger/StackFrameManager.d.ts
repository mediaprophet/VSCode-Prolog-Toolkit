export interface IStackFrame {
    id: number;
    level: number;
    name: string;
    file: string;
    line: number;
    column: number;
}
export declare class StackFrameManager {
    private _stackFrames;
    addStackFrame(frame: IStackFrame): void;
    getStackFrames(): IStackFrame[];
    clearStackFrames(): void;
    getCurrentFrame(): IStackFrame | undefined;
    highlightSource(frame: IStackFrame): {
        file: string;
        line: number;
        column: number;
    };
}
//# sourceMappingURL=StackFrameManager.d.ts.map