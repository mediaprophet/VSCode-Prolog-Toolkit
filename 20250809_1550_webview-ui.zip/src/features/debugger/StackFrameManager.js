"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StackFrameManager = void 0;
class StackFrameManager {
    _stackFrames = [];
    addStackFrame(frame) {
        try {
            this._stackFrames.unshift(frame);
        }
        catch (err) {
            console.error('[StackFrameManager] Error adding stack frame:', err, frame);
        }
    }
    getStackFrames() {
        return this._stackFrames;
    }
    clearStackFrames() {
        this._stackFrames = [];
    }
    getCurrentFrame() {
        return this._stackFrames[0];
    }
    highlightSource(frame) {
        return {
            file: frame.file,
            line: frame.line,
            column: frame.column,
        };
    }
}
exports.StackFrameManager = StackFrameManager;
//# sourceMappingURL=StackFrameManager.js.map