import { EventEmitter } from 'events';
export interface PrologProcessOptions {
    runtimeExecutable?: string;
    runtimeArgs?: string[];
    cwd: string;
    env?: {
        [key: string]: string;
    };
    timeoutMs?: number;
    maxRetries?: number;
}
export interface PrologProcessEvents {
    stdout: (data: string) => void;
    stderr: (data: string) => void;
    exit: (code?: number) => void;
    error: (err: Error) => void;
    process: (proc: any) => void;
}
export declare class ProcessManager extends EventEmitter {
    private _prologProc;
    private _options;
    private _retryCount;
    constructor(options: PrologProcessOptions);
    start(): Promise<void>;
    kill(): void;
    get pid(): number;
    get process(): any;
}
//# sourceMappingURL=ProcessManager.d.ts.map