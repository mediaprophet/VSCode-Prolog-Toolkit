'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadEditHelpers = loadEditHelpers;
const vscode_1 = require("vscode");
// automatic indentation on change
function loadEditHelpers(subscriptions) {
    subscriptions.push(vscode_1.languages.setLanguageConfiguration('prolog', {
        indentationRules: {
            decreaseIndentPattern: /(\s*\)|\s*\])$/,
            increaseIndentPattern: /(.*:-\s*|.*-->\s*|.*:->\s*|.*:<-\s*|.+\[|.+\()$/,
        },
        wordPattern: /(-?\d*\.\d\w*)|([^`~!@%^&*()\-=+[{}\\|;:'",./<>??\s]+)/g,
        onEnterRules: [
            // {
            //   beforeText: /.+:-|:- begin_tests.+\.$/,
            //   action: { indentAction: IndentAction.Indent }
            // },
            {
                beforeText: /(^\s*|.*%.+)$/,
                action: { indentAction: vscode_1.IndentAction.None },
            },
            {
                beforeText: /.+\.$/,
                action: { indentAction: vscode_1.IndentAction.Outdent },
            },
            {
                beforeText: /.+\([^)]*$/,
                action: { indentAction: vscode_1.IndentAction.Indent },
            },
            // {
            //   beforeText: /.+\[[^\]]*$/,
            //   action: { indentAction: IndentAction.Indent }
            // },
            {
                // e.g. /** | */
                beforeText: /^\s*\/\*\*(?!\/)([^*]|\*(?!\/))*$/,
                afterText: /^\s*\*\/$/,
                action: {
                    indentAction: vscode_1.IndentAction.IndentOutdent,
                    appendText: ' * ',
                },
            },
            {
                // e.g. /** ...|
                beforeText: /^\s*\/\*\*(?!\/)([^*]|\*(?!\/))*$/,
                action: { indentAction: vscode_1.IndentAction.None, appendText: ' * ' },
            },
            {
                // e.g.  * ...|
                beforeText: /^(\t|( ))* \*( ([^*]|\*(?!\/))*)?$/,
                action: { indentAction: vscode_1.IndentAction.None, appendText: '* ' },
            },
            {
                // e.g.  */|
                beforeText: /^(\t|( ))* \*\/\s*$/,
                action: { indentAction: vscode_1.IndentAction.None, removeText: 1 },
            },
            {
                // e.g.  *-----*/|
                beforeText: /^(\t|( ))* \*[^/]*\*\/\s*$/,
                action: { indentAction: vscode_1.IndentAction.None, removeText: 1 },
            },
        ],
    }));
}
//# sourceMappingURL=editHelpers.js.map