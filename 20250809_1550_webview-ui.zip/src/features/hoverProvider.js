'use strict';
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const cp = __importStar(require("child_process"));
const vscode_1 = require("vscode");
const utils_1 = require("../utils/utils");
class PrologHoverProvider {
    // escape markdown syntax tokens: http://daringfireball.net/projects/markdown/syntax#backslash
    // Helper function to escape markdown syntax tokens
    textToMarkedString(text) {
        return text.replace(/[\\`*_{}[\]()#+\-.!]/g, '\\$&');
    }
    // Implement the provideHover method required by HoverProvider interface
    provideHover(doc, position, _token) {
        const wordRange = doc.getWordRangeAtPosition(position); // Get the range of the word at the given position
        // Return early if no word range is found
        if (!wordRange) {
            return undefined;
        }
        const pred = utils_1.SnippetUtils.getPredicateUnderCursor(doc, position); // Get the predicate under the cursor using utility function
        // Return early if no predicate is found
        if (!pred) {
            return undefined;
        }
        // Return early if the predicate arity is less than or equal to 0
        if (pred.arity <= 0) {
            return undefined;
        }
        const contents = new vscode_1.MarkdownString('', true); // Create a MarkdownString to hold the hover contents
        // Switch based on the Prolog dialect (e.g., "swi" or "ecl")
        switch (utils_1.PrologExecUtils.DIALECT) {
            case 'swi': {
                // Extract module and predicate information for SWI-Prolog
                const pi = pred.pi.indexOf(':') > -1 ? pred.pi.split(':')[1] : pred.pi;
                if (!pi) {
                    return undefined;
                }
                const modules = utils_1.SnippetUtils.getPredModules(pi);
                // Check if there are no modules associated with the predicate
                if (modules.length === 0) {
                    const desc = utils_1.SnippetUtils.getPredDescriptions(pi);
                    // Append code block with either the description or the predicate itself
                    if (desc == '') {
                        contents.appendCodeblock(pi, 'prolog');
                    }
                    else {
                        contents.appendCodeblock(desc, 'prolog');
                    }
                }
                else {
                    // Iterate through modules and append information to contents
                    if (modules.length > 0) {
                        modules.forEach(module => {
                            contents.appendText(module + ':' + pi + '\n');
                            const desc = utils_1.SnippetUtils.getPredDescriptions(module + ':' + pi);
                            contents.appendCodeblock(desc, 'prolog');
                        });
                    }
                }
                break;
            }
            case 'ecl':
                // Execute a help command for ECLiPSe Prolog and append result to contents
                if (utils_1.PrologExecUtils.RUNTIMEPATH) {
                    const pro = cp.spawnSync(utils_1.PrologExecUtils.RUNTIMEPATH, ['-e', `help(${pred.pi})`]);
                    // Check if the command execution was successful
                    if (pro.status === 0 && pro.output) {
                        const outputStr = pro.output.toString();
                        if (outputStr) {
                            contents.appendCodeblock(outputStr
                                .trim()
                                .replace(/^\W*\n/, '')
                                .replace(/\n{3,}/g, '\n\n')
                                .replace(/  +/g, '  '), 'prolog');
                        }
                    }
                    else {
                        return undefined;
                    }
                }
                else {
                    return undefined;
                }
                break;
            default:
                // Handle other Prolog dialects if needed
                return undefined;
        }
        // Return a new Hover instance with the contents and word range
        return new vscode_1.Hover(contents, wordRange);
    }
}
exports.default = PrologHoverProvider;
//# sourceMappingURL=hoverProvider.js.map