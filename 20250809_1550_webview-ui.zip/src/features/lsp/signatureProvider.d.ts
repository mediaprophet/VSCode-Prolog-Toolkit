import { TextDocument } from 'vscode-languageserver-textdocument';
import { SignatureHelp, Position } from 'vscode-languageserver/node';
import { SignatureProvider, LSPContext } from './types';
export declare class PrologSignatureProvider implements SignatureProvider {
    provideSignatureHelp(document: TextDocument, position: Position, context: LSPContext): Promise<SignatureHelp | null>;
    private countParameters;
    private getPredicateSignature;
    private getCustomPredicateSignature;
}
//# sourceMappingURL=signatureProvider.d.ts.map