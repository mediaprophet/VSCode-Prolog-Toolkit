import { TextDocument } from 'vscode-languageserver-textdocument';
import { TextEdit, Range } from 'vscode-languageserver/node';
import { FormattingProvider, LSPContext, PrologSettings } from './types';
export declare class PrologFormattingProvider implements FormattingProvider {
    formatDocument(document: TextDocument, context: LSPContext): Promise<TextEdit[]>;
    formatRange(document: TextDocument, range: Range, context: LSPContext): Promise<TextEdit[]>;
    private formatPrologLine;
    private formatComment;
    private addSpacesAfterCommas;
    private formatOperators;
    private containsUnescapedQuotes;
    private formatOperatorsPreservingStrings;
    private formatIndentation;
    private isRuleHead;
    private isRuleBody;
    private isContinuationLine;
    private looksLikeFact;
    private cleanupWhitespace;
    formatClause(clause: string, settings: PrologSettings): string;
    formatTerm(term: string, settings: PrologSettings): string;
    formatGoal(goal: string, settings: PrologSettings): string;
    organizeImports(document: TextDocument): TextEdit[];
}
//# sourceMappingURL=formattingProvider.d.ts.map