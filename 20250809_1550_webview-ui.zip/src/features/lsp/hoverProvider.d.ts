import { TextDocument } from 'vscode-languageserver-textdocument';
import { Hover, Position } from 'vscode-languageserver/node';
import { HoverProvider, LSPContext } from './types';
export declare class PrologHoverProvider implements HoverProvider {
    provideHover(document: TextDocument, position: Position, context: LSPContext): Promise<Hover | null>;
    private getWordAtPosition;
    private formatHelpAsMarkdown;
    private getStaticHelp;
}
//# sourceMappingURL=hoverProvider.d.ts.map