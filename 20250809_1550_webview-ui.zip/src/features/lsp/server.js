"use strict";
// src/features/lsp/server.ts
// Main entry point for the Prolog LSP server, modular provider registration
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.prologBackend = exports.documents = exports.connection = void 0;
const vscode_languageserver_textdocument_1 = require("vscode-languageserver-textdocument");
const node_1 = require("vscode-languageserver/node");
const prologBackend_1 = require("../../prologBackend");
const configurationManager_1 = require("./configurationManager");
const Providers = __importStar(require("./index"));
const types_1 = require("./types");
const connection = (0, node_1.createConnection)(node_1.ProposedFeatures.all);
exports.connection = connection;
const documents = new node_1.TextDocuments(vscode_languageserver_textdocument_1.TextDocument);
exports.documents = documents;
const configurationManager = new configurationManager_1.ConfigurationManager(connection);
// State
let hasWorkspaceFolderCapability = false;
let prologBackend = null;
exports.prologBackend = prologBackend;
const createLSPContext = () => ({
    prologBackend,
    getDocumentSettings: (resource) => configurationManager.getDocumentSettings(resource),
    getGlobalSettings: () => configurationManager.getGlobalSettings(),
    documents: new Map(documents.all().map(doc => [doc.uri, doc])),
    hasConfigurationCapability: configurationManager.getHasConfigurationCapability(),
    hasWorkspaceFolderCapability,
});
connection.onInitialize((params) => {
    const capabilities = params.capabilities;
    const hasConfigurationCapability = !!(capabilities.workspace && !!capabilities.workspace.configuration);
    configurationManager.setConfigurationCapability(hasConfigurationCapability);
    hasWorkspaceFolderCapability = !!(capabilities.workspace && !!capabilities.workspace.workspaceFolders);
    return {
        capabilities: Providers.getServerCapabilities(node_1.CodeActionKind, types_1.semanticTokensLegend, hasWorkspaceFolderCapability)
    };
});
connection.onInitialized(() => {
    configurationManager.registerForConfigurationChanges();
    if (hasWorkspaceFolderCapability) {
        connection.workspace.onDidChangeWorkspaceFolders(_event => {
            connection.console.log('Workspace folder change event received.');
        });
    }
    initializePrologBackend();
});
async function initializePrologBackend() {
    try {
        const settings = await configurationManager.getGlobalSettings();
        exports.prologBackend = prologBackend = new prologBackend_1.PrologBackend({
            swiplPath: settings.executablePath,
            port: 3061,
            streamingEnabled: true,
            maxResultsPerChunk: 50,
        });
        prologBackend.on('ready', () => connection.console.log('Prolog backend ready for LSP server'));
        prologBackend.on('error', (error) => connection.console.error(`Prolog backend error: ${error}`));
        prologBackend.start();
    }
    catch (error) {
        connection.console.error(`Failed to initialize Prolog backend: ${error}`);
    }
}
// Register all providers
Providers.registerAll(connection, documents, createLSPContext);
documents.listen(connection);
connection.listen();
//# sourceMappingURL=server.js.map