import { TextDocument } from 'vscode-languageserver-textdocument';
import { DocumentSymbol, SymbolInformation, SymbolKind } from 'vscode-languageserver/node';
import { SymbolProvider, LSPContext } from './types';
export declare class PrologSymbolProvider implements SymbolProvider {
    provideDocumentSymbols(document: TextDocument, context: LSPContext): Promise<DocumentSymbol[]>;
    provideWorkspaceSymbols(query: string, documents: TextDocument[], context: LSPContext): Promise<SymbolInformation[]>;
    private countArity;
    private getContainerName;
    getSymbolsByKind(document: TextDocument, kind: SymbolKind, context: LSPContext): Promise<DocumentSymbol[]>;
    getPredicates(document: TextDocument, context: LSPContext): Promise<DocumentSymbol[]>;
    getDirectives(document: TextDocument, context: LSPContext): Promise<DocumentSymbol[]>;
    getModules(document: TextDocument, context: LSPContext): Promise<DocumentSymbol[]>;
    findSymbolAtPosition(document: TextDocument, line: number, character: number): DocumentSymbol | null;
}
//# sourceMappingURL=symbolProvider.d.ts.map