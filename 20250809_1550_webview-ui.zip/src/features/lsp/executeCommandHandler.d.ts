import { ExecuteCommandHandler, LSPContext } from './types';
export declare class PrologExecuteCommandHandler implements ExecuteCommandHandler {
    executeCommand(command: string, args: any[], context: LSPContext): Promise<any>;
    private executeQuery;
    private consultFile;
    private getHelp;
    private runN3Diagnostics;
    private formatDocument;
    private organizeImports;
    private formatPrologDocument;
    private formatPrologLine;
    private organizeImportsInDocument;
}
//# sourceMappingURL=executeCommandHandler.d.ts.map