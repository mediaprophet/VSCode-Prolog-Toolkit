import { TextDocument } from 'vscode-languageserver-textdocument';
import { CodeAction, Diagnostic, Range } from 'vscode-languageserver/node';
import { CodeActionProvider, LSPContext } from './types';
export declare class PrologCodeActionsProvider implements CodeActionProvider {
    provideCodeActions(document: TextDocument, range: Range, diagnostics: Diagnostic[], context: LSPContext): Promise<CodeAction[]>;
    private isN3Context;
}
//# sourceMappingURL=codeActionsProvider.d.ts.map