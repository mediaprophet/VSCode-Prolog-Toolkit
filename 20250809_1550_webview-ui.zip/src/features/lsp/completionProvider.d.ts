import { TextDocument } from 'vscode-languageserver-textdocument';
import { CompletionItem, Position } from 'vscode-languageserver/node';
import { CompletionProvider, LSPContext } from './types';
export declare class PrologCompletionProvider implements CompletionProvider {
    provideCompletions(document: TextDocument, position: Position, context: LSPContext): Promise<CompletionItem[]>;
    private getBuiltinPredicateCompletions;
    private isN3Context;
    private getN3Completions;
    private getDynamicCompletions;
    private getCompletionItemKind;
}
//# sourceMappingURL=completionProvider.d.ts.map