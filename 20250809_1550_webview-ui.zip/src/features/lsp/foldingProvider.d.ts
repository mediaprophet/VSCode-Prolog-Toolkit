import { TextDocument } from 'vscode-languageserver-textdocument';
import { FoldingRange, FoldingRangeKind } from 'vscode-languageserver/node';
import { FoldingProvider, LSPContext } from './types';
export declare class PrologFoldingProvider implements FoldingProvider {
    provideFoldingRanges(document: TextDocument, context: LSPContext): Promise<FoldingRange[]>;
    private startsBlockComment;
    private endsBlockComment;
    private isRuleHead;
    private endsRule;
    private extractPredicateName;
    private isModuleDeclaration;
    private findModuleEnd;
    private isDCGRule;
    private findDCGRuleEnd;
    private startsListConstruct;
    private findListConstructEnd;
    private cleanupRanges;
    private rangesOverlap;
    private getRangeSize;
    getFoldableRegions(document: TextDocument, kind?: FoldingRangeKind, context?: LSPContext): Promise<FoldingRange[]>;
    getCommentBlocks(document: TextDocument, context: LSPContext): Promise<FoldingRange[]>;
    getPredicateGroups(document: TextDocument, context: LSPContext): Promise<FoldingRange[]>;
    isLineInFoldableRegion(line: number, ranges: FoldingRange[]): boolean;
}
//# sourceMappingURL=foldingProvider.d.ts.map