import { TextDocument } from 'vscode-languageserver-textdocument';
import { Location, DocumentHighlight, Position } from 'vscode-languageserver/node';
import { ReferencesProvider, LSPContext } from './types';
export declare class PrologReferencesProvider implements ReferencesProvider {
    private definitionProvider;
    constructor();
    provideReferences(document: TextDocument, position: Position, includeDeclaration: boolean, context: LSPContext): Promise<Location[]>;
    provideDocumentHighlights(document: TextDocument, position: Position, context: LSPContext): Promise<DocumentHighlight[]>;
    private getWordAtPosition;
    private findReferencesInDocument;
    private isPredicateDeclaration;
    private getHighlightKind;
    private escapeRegex;
    findReferencesInDocuments(documents: TextDocument[], predicate: string, includeDeclaration?: boolean): Promise<Location[]>;
    findUnusedPredicates(document: TextDocument): string[];
    findUndefinedPredicates(document: TextDocument): string[];
}
//# sourceMappingURL=referencesProvider.d.ts.map