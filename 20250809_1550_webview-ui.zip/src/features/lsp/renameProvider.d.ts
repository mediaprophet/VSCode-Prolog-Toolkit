import { TextDocument } from 'vscode-languageserver-textdocument';
import { WorkspaceEdit, Range, Position } from 'vscode-languageserver/node';
import { RenameProvider, LSPContext } from './types';
export declare class PrologRenameProvider implements RenameProvider {
    prepareRename(document: TextDocument, position: Position, context: LSPContext): Promise<Range | null>;
    provideRename(document: TextDocument, position: Position, newName: string, context: LSPContext): Promise<WorkspaceEdit | null>;
    private getWordAtPosition;
    private isValidPredicateName;
    private findAndReplacePredicateOccurrences;
    private shouldRenameOccurrence;
    private isInsideString;
    private escapeRegex;
    provideWorkspaceRename(documents: TextDocument[], originalDocument: TextDocument, position: Position, newName: string, context: LSPContext): Promise<WorkspaceEdit | null>;
    checkRenameSafety(document: TextDocument, oldName: string, newName: string): {
        safe: boolean;
        conflicts: string[];
    };
    private findExistingPredicates;
    private isBuiltinPredicate;
    private followsNamingConventions;
    getRenamePreview(document: TextDocument, oldName: string, newName: string): Array<{
        line: number;
        oldText: string;
        newText: string;
    }>;
}
//# sourceMappingURL=renameProvider.d.ts.map