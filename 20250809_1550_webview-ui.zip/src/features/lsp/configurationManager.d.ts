import { createConnection } from 'vscode-languageserver/node';
import { PrologSettings } from './types';
export declare class ConfigurationManager {
    private globalSettings;
    private documentSettings;
    private hasConfigurationCapability;
    private connection;
    constructor(connection: ReturnType<typeof createConnection>);
    setConfigurationCapability(hasCapability: boolean): void;
    getHasConfigurationCapability(): boolean;
    registerForConfigurationChanges(): void;
    onDidChangeConfiguration(change: any): void;
    getDocumentSettings(resource: string): Promise<PrologSettings>;
    getGlobalSettings(): Promise<PrologSettings>;
    clearDocumentSettings(uri: string): void;
    clearAllDocumentSettings(): void;
}
//# sourceMappingURL=configurationManager.d.ts.map