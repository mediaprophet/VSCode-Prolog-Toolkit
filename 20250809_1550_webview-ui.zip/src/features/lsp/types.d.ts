import { TextDocument, Diagnostic, CompletionItem, Hover, CodeAction, Definition, DocumentSymbol, SymbolInformation, Location, DocumentHighlight, SignatureHelp, TextEdit, WorkspaceEdit, Range, FoldingRange, SemanticTokens, SemanticTokensLegend, Position } from 'vscode-languageserver/node';
import { PrologBackend } from '../../prologBackend';
export interface PrologSettings {
    executablePath: string;
    dialect: 'swi' | 'ecl';
    linter: {
        run: 'onSave' | 'onType' | 'never';
        delay: number;
        enableMsgInOutput: boolean;
    };
    format: {
        addSpace: boolean;
    };
    terminal: {
        runtimeArgs: string[];
    };
}
export declare const defaultSettings: PrologSettings;
export interface LSPContext {
    prologBackend: PrologBackend | null;
    getDocumentSettings: (resource: string) => Promise<PrologSettings>;
    getGlobalSettings: () => Promise<PrologSettings>;
    documents: Map<string, TextDocument>;
    hasConfigurationCapability: boolean;
    hasWorkspaceFolderCapability: boolean;
}
export interface ValidationProvider {
    validateTextDocument(textDocument: TextDocument, context: LSPContext): Promise<Diagnostic[]>;
}
export interface CompletionProvider {
    provideCompletions(document: TextDocument, position: Position, context: LSPContext): Promise<CompletionItem[]>;
}
export interface HoverProvider {
    provideHover(document: TextDocument, position: Position, context: LSPContext): Promise<Hover | null>;
}
export interface CodeActionProvider {
    provideCodeActions(document: TextDocument, range: Range, diagnostics: Diagnostic[], context: LSPContext): Promise<CodeAction[]>;
}
export interface DefinitionProvider {
    provideDefinition(document: TextDocument, position: Position, context: LSPContext): Promise<Definition | null>;
}
export interface SymbolProvider {
    provideDocumentSymbols(document: TextDocument, context: LSPContext): Promise<DocumentSymbol[]>;
    provideWorkspaceSymbols(query: string, documents: TextDocument[], context: LSPContext): Promise<SymbolInformation[]>;
}
export interface ReferencesProvider {
    provideReferences(document: TextDocument, position: Position, includeDeclaration: boolean, context: LSPContext): Promise<Location[]>;
    provideDocumentHighlights(document: TextDocument, position: Position, context: LSPContext): Promise<DocumentHighlight[]>;
}
export interface SignatureProvider {
    provideSignatureHelp(document: TextDocument, position: Position, context: LSPContext): Promise<SignatureHelp | null>;
}
export interface FormattingProvider {
    formatDocument(document: TextDocument, context: LSPContext): Promise<TextEdit[]>;
    formatRange(document: TextDocument, range: Range, context: LSPContext): Promise<TextEdit[]>;
}
export interface RenameProvider {
    prepareRename(document: TextDocument, position: Position, context: LSPContext): Promise<Range | null>;
    provideRename(document: TextDocument, position: Position, newName: string, context: LSPContext): Promise<WorkspaceEdit | null>;
}
export interface FoldingProvider {
    provideFoldingRanges(document: TextDocument, context: LSPContext): Promise<FoldingRange[]>;
}
export interface SemanticTokensProvider {
    provideSemanticTokens(document: TextDocument, context: LSPContext): Promise<SemanticTokens>;
}
export interface ExecuteCommandHandler {
    executeCommand(command: string, args: any[], context: LSPContext): Promise<any>;
}
export declare const semanticTokensLegend: SemanticTokensLegend;
export interface PredicateInfo {
    name: string;
    arity: number;
    description?: string;
}
export interface N3CompletionInfo {
    name: string;
    detail?: string;
}
export interface HelpDocumentation {
    name: string;
    arity: number;
    summary?: string;
    args?: Array<{
        name: string;
        description: string;
    }>;
    examples?: string[];
}
export interface BackendResponse {
    status: 'ok' | 'error';
    results?: any[];
    completions?: any[];
    doc?: HelpDocumentation;
    locations?: Array<{
        uri: string;
        line: number;
        character: number;
    }>;
    errors?: Array<{
        line?: number;
        column?: number;
        length?: number;
        message?: string;
    }>;
    error?: string;
}
//# sourceMappingURL=types.d.ts.map