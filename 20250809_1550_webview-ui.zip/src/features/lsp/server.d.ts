import { TextDocument } from 'vscode-languageserver-textdocument';
import { TextDocuments } from 'vscode-languageserver/node';
import { PrologBackend } from '../../prologBackend';
declare const connection: import("vscode-languageserver/node")._Connection<import("vscode-languageserver/node")._, import("vscode-languageserver/node")._, import("vscode-languageserver/node")._, import("vscode-languageserver/node")._, import("vscode-languageserver/node")._, import("vscode-languageserver/node")._, import("vscode-languageserver/lib/common/inlineCompletion.proposed").InlineCompletionFeatureShape, import("vscode-languageserver/node")._>;
declare const documents: TextDocuments<TextDocument>;
declare let prologBackend: PrologBackend | null;
export { connection, documents, prologBackend };
//# sourceMappingURL=server.d.ts.map