"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigurationManager = void 0;
const node_1 = require("vscode-languageserver/node");
const types_1 = require("./types");
class ConfigurationManager {
    globalSettings = types_1.defaultSettings;
    documentSettings = new Map();
    hasConfigurationCapability = false;
    connection;
    constructor(connection) {
        this.connection = connection;
    }
    setConfigurationCapability(hasCapability) {
        this.hasConfigurationCapability = hasCapability;
    }
    getHasConfigurationCapability() {
        return this.hasConfigurationCapability;
    }
    registerForConfigurationChanges() {
        if (this.hasConfigurationCapability) {
            // Register for all configuration changes.
            this.connection.client.register(node_1.DidChangeConfigurationNotification.type, undefined);
        }
    }
    onDidChangeConfiguration(change) {
        if (this.hasConfigurationCapability) {
            // Reset all cached document settings
            this.documentSettings.clear();
        }
        else {
            this.globalSettings = (change.settings.prolog || types_1.defaultSettings);
        }
    }
    getDocumentSettings(resource) {
        if (!this.hasConfigurationCapability) {
            return Promise.resolve(this.globalSettings);
        }
        let result = this.documentSettings.get(resource);
        if (!result) {
            result = this.connection.workspace.getConfiguration({
                scopeUri: resource,
                section: 'prolog',
            });
            this.documentSettings.set(resource, result);
        }
        return result;
    }
    getGlobalSettings() {
        if (!this.hasConfigurationCapability) {
            return Promise.resolve(this.globalSettings);
        }
        return this.connection.workspace.getConfiguration('prolog');
    }
    clearDocumentSettings(uri) {
        this.documentSettings.delete(uri);
    }
    clearAllDocumentSettings() {
        this.documentSettings.clear();
    }
}
exports.ConfigurationManager = ConfigurationManager;
//# sourceMappingURL=configurationManager.js.map