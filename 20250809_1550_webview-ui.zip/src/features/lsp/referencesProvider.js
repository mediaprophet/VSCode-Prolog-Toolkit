"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrologReferencesProvider = void 0;
const node_1 = require("vscode-languageserver/node");
const definitionProvider_1 = require("./definitionProvider");
class PrologReferencesProvider {
    definitionProvider;
    constructor() {
        this.definitionProvider = new definitionProvider_1.PrologDefinitionProvider();
    }
    async provideReferences(document, position, includeDeclaration, context) {
        const word = this.getWordAtPosition(document.getText(), position);
        if (!word) {
            return [];
        }
        const locations = [];
        // Search in current document
        const currentDocReferences = this.findReferencesInDocument(document, word, includeDeclaration);
        locations.push(...currentDocReferences);
        // TODO: Search in other documents in the workspace
        // This would require access to all documents in the workspace
        // For now, we only search in the current document
        return locations;
    }
    async provideDocumentHighlights(document, position, context) {
        const word = this.getWordAtPosition(document.getText(), position);
        if (!word) {
            return [];
        }
        const highlights = [];
        const text = document.getText();
        const lines = text.split('\n');
        for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const regex = new RegExp(`\\b${this.escapeRegex(word)}\\b`, 'g');
            let match;
            while ((match = regex.exec(line)) !== null) {
                const kind = this.getHighlightKind(line, match.index, word);
                highlights.push({
                    range: {
                        start: { line: i, character: match.index },
                        end: { line: i, character: match.index + word.length },
                    },
                    kind,
                });
            }
        }
        return highlights;
    }
    getWordAtPosition(text, position) {
        const lines = text.split('\n');
        const line = lines[position.line];
        if (!line) {
            return null;
        }
        const char = position.character;
        let start = char;
        let end = char;
        // Find word boundaries
        while (start > 0 && /[a-zA-Z0-9_]/.test(line[start - 1])) {
            start--;
        }
        while (end < line.length && /[a-zA-Z0-9_]/.test(line[end])) {
            end++;
        }
        return start < end ? line.substring(start, end) : null;
    }
    findReferencesInDocument(document, word, includeDeclaration) {
        const text = document.getText();
        const lines = text.split('\n');
        const locations = [];
        for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const regex = new RegExp(`\\b${this.escapeRegex(word)}\\b`, 'g');
            let match;
            while ((match = regex.exec(line)) !== null) {
                const isDeclaration = this.isPredicateDeclaration(line, match.index, word);
                // Include this occurrence if we want declarations or it's not a declaration
                if (includeDeclaration || !isDeclaration) {
                    locations.push({
                        uri: document.uri,
                        range: {
                            start: { line: i, character: match.index },
                            end: { line: i, character: match.index + word.length },
                        },
                    });
                }
            }
        }
        return locations;
    }
    isPredicateDeclaration(line, predicateIndex, predicate) {
        const beforePredicate = line.substring(0, predicateIndex).trim();
        const afterPredicate = line.substring(predicateIndex + predicate.length);
        // It's a declaration if:
        // 1. It starts the line (possibly after whitespace or :-)
        // 2. It's followed by an opening parenthesis
        // 3. The line contains :- (rule) or ends with . (fact)
        const startsLine = beforePredicate === '' || beforePredicate === ':-';
        const followedByParen = afterPredicate.trim().startsWith('(');
        const isRuleOrFact = line.includes(':-') || line.trim().endsWith('.');
        return startsLine && followedByParen && isRuleOrFact;
    }
    getHighlightKind(line, predicateIndex, predicate) {
        // Determine the kind of highlight based on context
        if (this.isPredicateDeclaration(line, predicateIndex, predicate)) {
            return node_1.DocumentHighlightKind.Write; // Declaration/definition
        }
        // Check if it's in a read context (being called)
        const beforePredicate = line.substring(0, predicateIndex);
        const afterPredicate = line.substring(predicateIndex + predicate.length);
        // If followed by opening parenthesis, it's likely a call
        if (afterPredicate.trim().startsWith('(')) {
            return node_1.DocumentHighlightKind.Read;
        }
        // Default to text highlight
        return node_1.DocumentHighlightKind.Text;
    }
    escapeRegex(str) {
        return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
    // Additional utility methods
    // Find all references to a predicate across multiple documents
    async findReferencesInDocuments(documents, predicate, includeDeclaration = true) {
        const allLocations = [];
        for (const document of documents) {
            const locations = this.findReferencesInDocument(document, predicate, includeDeclaration);
            allLocations.push(...locations);
        }
        return allLocations;
    }
    // Find unused predicates (declared but never called)
    findUnusedPredicates(document) {
        const unusedPredicates = [];
        const text = document.getText();
        const lines = text.split('\n');
        // Find all predicate declarations
        const declarations = new Set();
        const usages = new Set();
        for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            // Find predicate declarations
            const declarationMatch = line.match(/^([a-z][a-zA-Z0-9_]*)\s*\(/);
            if (declarationMatch) {
                declarations.add(declarationMatch[1]);
            }
            // Find predicate usages (not at start of line)
            const usageMatches = line.match(/\b[a-z][a-zA-Z0-9_]*\s*\(/g);
            if (usageMatches) {
                for (const match of usageMatches) {
                    const predicateName = match.replace(/\s*\($/, '');
                    // Only count as usage if not at the start of the line (not a declaration)
                    if (!line.trim().startsWith(match)) {
                        usages.add(predicateName);
                    }
                }
            }
        }
        // Find declared predicates that are never used
        Array.from(declarations).forEach(declared => {
            if (!usages.has(declared)) {
                unusedPredicates.push(declared);
            }
        });
        return unusedPredicates;
    }
    // Find predicates that are called but never defined
    findUndefinedPredicates(document) {
        const undefinedPredicates = [];
        const text = document.getText();
        const lines = text.split('\n');
        const declarations = new Set();
        const usages = new Set();
        for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            // Find predicate declarations
            const declarationMatch = line.match(/^([a-z][a-zA-Z0-9_]*)\s*\(/);
            if (declarationMatch) {
                declarations.add(declarationMatch[1]);
            }
            // Find predicate usages
            const usageMatches = line.match(/\b[a-z][a-zA-Z0-9_]*\s*\(/g);
            if (usageMatches) {
                for (const match of usageMatches) {
                    const predicateName = match.replace(/\s*\($/, '');
                    // Only count as usage if not at the start of the line
                    if (!line.trim().startsWith(match)) {
                        usages.add(predicateName);
                    }
                }
            }
        }
        // Find used predicates that are never declared (excluding built-ins)
        const builtins = new Set([
            'member', 'append', 'length', 'reverse', 'sort', 'findall', 'bagof', 'setof',
            'assert', 'retract', 'write', 'writeln', 'nl', 'is', 'var', 'nonvar',
            'atom', 'number', 'compound', 'functor', 'arg', 'univ', 'call', 'once',
            'forall', 'between', 'succ', 'true', 'fail', 'cut'
        ]);
        Array.from(usages).forEach(used => {
            if (!declarations.has(used) && !builtins.has(used)) {
                undefinedPredicates.push(used);
            }
        });
        return undefinedPredicates;
    }
}
exports.PrologReferencesProvider = PrologReferencesProvider;
//# sourceMappingURL=referencesProvider.js.map