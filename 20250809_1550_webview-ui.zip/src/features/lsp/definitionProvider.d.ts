import { TextDocument } from 'vscode-languageserver-textdocument';
import { Definition, Location, Position } from 'vscode-languageserver/node';
import { DefinitionProvider, LSPContext } from './types';
export declare class PrologDefinitionProvider implements DefinitionProvider {
    provideDefinition(document: TextDocument, position: Position, context: LSPContext): Promise<Definition | null>;
    private getWordAtPosition;
    private findLocalDefinition;
    private escapeRegex;
    findAllReferences(document: TextDocument, predicate: string, includeDeclaration?: boolean): Location[];
    private isPredicateDeclaration;
    findPredicateCalls(document: TextDocument, predicate: string): Location[];
    findPredicateDeclarations(document: TextDocument, predicate: string): Location[];
}
//# sourceMappingURL=definitionProvider.d.ts.map