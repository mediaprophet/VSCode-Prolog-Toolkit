import { TextDocument } from 'vscode-languageserver-textdocument';
import { Diagnostic } from 'vscode-languageserver/node';
import { ValidationProvider, LSPContext } from './types';
export declare class PrologValidationProvider implements ValidationProvider {
    validateTextDocument(textDocument: TextDocument, context: LSPContext): Promise<Diagnostic[]>;
    private validatePrologLine;
    private isLikelyUndefinedPredicate;
    private validateWithBackend;
}
//# sourceMappingURL=validationProvider.d.ts.map