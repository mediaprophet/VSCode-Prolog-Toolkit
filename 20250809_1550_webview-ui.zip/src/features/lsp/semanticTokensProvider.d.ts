import { TextDocument } from 'vscode-languageserver-textdocument';
import { SemanticTokens } from 'vscode-languageserver/node';
import { SemanticTokensProvider, LSPContext } from './types';
export declare class PrologSemanticTokensProvider implements SemanticTokensProvider {
    provideSemanticTokens(document: TextDocument, context: LSPContext): Promise<SemanticTokens>;
    private tokenizePrologLine;
    private getTokenType;
    private getTokenModifier;
    private getVariableModifiers;
    private getPredicateModifiers;
    private isBuiltinPredicate;
    private isInStringOrComment;
    private tokenizeDCGRule;
    provideSemanticTokensRange(document: TextDocument, startLine: number, endLine: number, context: LSPContext): Promise<SemanticTokens>;
    getTokenAtPosition(document: TextDocument, line: number, character: number): {
        type: string;
        modifiers: string[];
    } | null;
    validateLegend(): boolean;
}
//# sourceMappingURL=semanticTokensProvider.d.ts.map