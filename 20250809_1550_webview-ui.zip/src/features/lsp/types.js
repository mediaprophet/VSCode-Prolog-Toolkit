"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.semanticTokensLegend = exports.defaultSettings = void 0;
exports.defaultSettings = {
    executablePath: 'swipl',
    dialect: 'swi',
    linter: {
        run: 'onType',
        delay: 500,
        enableMsgInOutput: false,
    },
    format: {
        addSpace: true,
    },
    terminal: {
        runtimeArgs: [],
    },
};
// Semantic tokens legend
exports.semanticTokensLegend = {
    tokenTypes: [
        'namespace',
        'type',
        'class',
        'enum',
        'interface',
        'struct',
        'typeParameter',
        'parameter',
        'variable',
        'property',
        'enumMember',
        'event',
        'function',
        'method',
        'macro',
        'keyword',
        'modifier',
        'comment',
        'string',
        'number',
        'regexp',
        'operator',
        'decorator',
    ],
    tokenModifiers: [
        'declaration',
        'definition',
        'readonly',
        'static',
        'deprecated',
        'abstract',
        'async',
        'modification',
        'documentation',
        'defaultLibrary',
    ],
};
//# sourceMappingURL=types.js.map