"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LSP_MODULE_VERSION = exports.PrologValidationProvider = exports.PrologSymbolProvider = exports.PrologSignatureProvider = exports.PrologSemanticTokensProvider = exports.PrologRenameProvider = exports.PrologReferencesProvider = exports.PrologHoverProvider = exports.PrologFormattingProvider = exports.PrologFoldingProvider = exports.PrologExecuteCommandHandler = exports.PrologDefinitionProvider = exports.ConfigurationManager = exports.PrologCompletionProvider = exports.PrologCodeActionsProvider = void 0;
exports.getServerCapabilities = getServerCapabilities;
exports.registerAll = registerAll;
exports.createLSPProviders = createLSPProviders;
// --- Modular LSP server registration and capabilities ---
const node_1 = require("vscode-languageserver/node");
// Returns the full capabilities object for the LSP server
function getServerCapabilities(CodeActionKind, semanticTokensLegend, hasWorkspaceFolderCapability) {
    const base = {
        textDocumentSync: node_1.TextDocumentSyncKind.Incremental,
        completionProvider: {
            resolveProvider: true,
            triggerCharacters: ['(', ',', ' ', '.', ':', '-', '_'],
        },
        hoverProvider: true,
        codeActionProvider: {
            codeActionKinds: [
                CodeActionKind.QuickFix,
                CodeActionKind.Refactor,
                CodeActionKind.Source,
                CodeActionKind.SourceOrganizeImports,
            ],
        },
        executeCommandProvider: {
            commands: [
                'prolog.executeQuery',
                'prolog.consultFile',
                'prolog.getHelp',
                'prolog.runN3Diagnostics',
                'prolog.formatDocument',
                'prolog.organizeImports',
            ],
        },
        definitionProvider: true,
        documentSymbolProvider: true,
        workspaceSymbolProvider: true,
        referencesProvider: true,
        documentHighlightProvider: true,
        signatureHelpProvider: {
            triggerCharacters: ['(', ','],
        },
        documentFormattingProvider: true,
        documentRangeFormattingProvider: true,
        renameProvider: {
            prepareProvider: true,
        },
        foldingRangeProvider: true,
        semanticTokensProvider: {
            legend: semanticTokensLegend,
            range: true,
            full: {
                delta: true,
            },
        },
        colorProvider: true,
        callHierarchyProvider: true,
        linkedEditingRangeProvider: true,
        monikerProvider: true,
        typeDefinitionProvider: true,
        implementationProvider: true,
        declarationProvider: true,
        selectionRangeProvider: true,
    };
    if (hasWorkspaceFolderCapability) {
        return {
            ...base,
            workspace: {
                workspaceFolders: {
                    supported: true,
                },
            },
        };
    }
    return base;
}
// Registers all LSP providers with the connection
function registerAll(connection, documents, createLSPContext) {
    const providers = createLSPProviders();
    // Validation on content change
    documents.onDidChangeContent(change => {
        validateTextDocument(change.document);
    });
    async function validateTextDocument(textDocument) {
        try {
            const context = createLSPContext();
            const diagnostics = await providers.validationProvider.validateTextDocument(textDocument, context);
            connection.sendDiagnostics({ uri: textDocument.uri, diagnostics });
        }
        catch (error) {
            connection.console.error(`Validation error: ${error}`);
        }
    }
    // Completion
    connection.onCompletion(async (params) => {
        const document = documents.get(params.textDocument.uri);
        if (!document)
            return [];
        try {
            const context = createLSPContext();
            return await providers.completionProvider.provideCompletions(document, params.position, context);
        }
        catch (error) {
            connection.console.error(`Completion error: ${error}`);
            return [];
        }
    });
    // Hover
    connection.onHover(async (params) => {
        const document = documents.get(params.textDocument.uri);
        if (!document)
            return null;
        try {
            const context = createLSPContext();
            return await providers.hoverProvider.provideHover(document, params.position, context);
        }
        catch (error) {
            connection.console.error(`Hover error: ${error}`);
            return null;
        }
    });
    // Code Actions
    connection.onCodeAction(async (params) => {
        const document = documents.get(params.textDocument.uri);
        if (!document)
            return [];
        try {
            const context = createLSPContext();
            return await providers.codeActionsProvider.provideCodeActions(document, params.range, params.context.diagnostics, context);
        }
        catch (error) {
            connection.console.error(`Code actions error: ${error}`);
            return [];
        }
    });
    // Execute Command
    connection.onExecuteCommand(async (params) => {
        try {
            const context = createLSPContext();
            const result = await providers.executeCommandHandler.executeCommand(params.command, params.arguments || [], context);
            if (result.success) {
                connection.window.showInformationMessage(result.message);
            }
            else {
                connection.window.showErrorMessage(result.message);
            }
            return result;
        }
        catch (error) {
            connection.console.error(`Execute command error: ${error}`);
            connection.window.showErrorMessage(`Command execution failed: ${error}`);
            return null;
        }
    });
    // Definition
    connection.onDefinition(async (params) => {
        const document = documents.get(params.textDocument.uri);
        if (!document)
            return null;
        try {
            const context = createLSPContext();
            return await providers.definitionProvider.provideDefinition(document, params.position, context);
        }
        catch (error) {
            connection.console.error(`Definition error: ${error}`);
            return null;
        }
    });
    // Document Symbol
    connection.onDocumentSymbol(async (params) => {
        const document = documents.get(params.textDocument.uri);
        if (!document)
            return [];
        try {
            const context = createLSPContext();
            return await providers.symbolProvider.provideDocumentSymbols(document, context);
        }
        catch (error) {
            connection.console.error(`Document symbols error: ${error}`);
            return [];
        }
    });
    // Workspace Symbol
    connection.onWorkspaceSymbol(async (params) => {
        try {
            const context = createLSPContext();
            const allDocuments = documents.all();
            return await providers.symbolProvider.provideWorkspaceSymbols(params.query, allDocuments, context);
        }
        catch (error) {
            connection.console.error(`Workspace symbols error: ${error}`);
            return [];
        }
    });
    // References
    connection.onReferences(async (params) => {
        const document = documents.get(params.textDocument.uri);
        if (!document)
            return [];
        try {
            const context = createLSPContext();
            return await providers.referencesProvider.provideReferences(document, params.position, params.context.includeDeclaration, context);
        }
        catch (error) {
            connection.console.error(`References error: ${error}`);
            return [];
        }
    });
    // Document Highlight
    connection.onDocumentHighlight(async (params) => {
        const document = documents.get(params.textDocument.uri);
        if (!document)
            return [];
        try {
            const context = createLSPContext();
            return await providers.referencesProvider.provideDocumentHighlights(document, params.position, context);
        }
        catch (error) {
            connection.console.error(`Document highlight error: ${error}`);
            return [];
        }
    });
    // Signature Help
    connection.onSignatureHelp(async (params) => {
        const document = documents.get(params.textDocument.uri);
        if (!document)
            return null;
        try {
            const context = createLSPContext();
            return await providers.signatureProvider.provideSignatureHelp(document, params.position, context);
        }
        catch (error) {
            connection.console.error(`Signature help error: ${error}`);
            return null;
        }
    });
    // Document Formatting
    connection.onDocumentFormatting(async (params) => {
        const document = documents.get(params.textDocument.uri);
        if (!document)
            return [];
        try {
            const context = createLSPContext();
            return await providers.formattingProvider.formatDocument(document, context);
        }
        catch (error) {
            connection.console.error(`Document formatting error: ${error}`);
            return [];
        }
    });
    connection.onDocumentRangeFormatting(async (params) => {
        const document = documents.get(params.textDocument.uri);
        if (!document)
            return [];
        try {
            const context = createLSPContext();
            return await providers.formattingProvider.formatRange(document, params.range, context);
        }
        catch (error) {
            connection.console.error(`Document range formatting error: ${error}`);
            return [];
        }
    });
    // Rename
    connection.onPrepareRename(async (params) => {
        const document = documents.get(params.textDocument.uri);
        if (!document)
            return null;
        try {
            const context = createLSPContext();
            return await providers.renameProvider.prepareRename(document, params.position, context);
        }
        catch (error) {
            connection.console.error(`Prepare rename error: ${error}`);
            return null;
        }
    });
    connection.onRenameRequest(async (params) => {
        const document = documents.get(params.textDocument.uri);
        if (!document)
            return null;
        try {
            const context = createLSPContext();
            return await providers.renameProvider.provideRename(document, params.position, params.newName, context);
        }
        catch (error) {
            connection.console.error(`Rename error: ${error}`);
            return null;
        }
    });
    // Folding Range
    connection.onFoldingRanges(async (params) => {
        const document = documents.get(params.textDocument.uri);
        if (!document)
            return [];
        try {
            const context = createLSPContext();
            return await providers.foldingProvider.provideFoldingRanges(document, context);
        }
        catch (error) {
            connection.console.error(`Folding ranges error: ${error}`);
            return [];
        }
    });
    // Semantic Tokens
    connection.onRequest('textDocument/semanticTokens/full', async (params) => {
        const document = documents.get(params.textDocument.uri);
        if (!document)
            return { data: [] };
        try {
            const context = createLSPContext();
            return await providers.semanticTokensProvider.provideSemanticTokens(document, context);
        }
        catch (error) {
            connection.console.error(`Semantic tokens error: ${error}`);
            return { data: [] };
        }
    });
    // Document close: clear settings
    documents.onDidClose(e => {
        // If you have per-document settings, clear them here
        // configurationManager.clearDocumentSettings(e.document.uri);
    });
}
// Import all providers for internal use
const codeActionsProvider_1 = require("./codeActionsProvider");
const completionProvider_1 = require("./completionProvider");
const definitionProvider_1 = require("./definitionProvider");
const executeCommandHandler_1 = require("./executeCommandHandler");
const foldingProvider_1 = require("./foldingProvider");
const formattingProvider_1 = require("./formattingProvider");
const hoverProvider_1 = require("./hoverProvider");
const referencesProvider_1 = require("./referencesProvider");
const renameProvider_1 = require("./renameProvider");
const semanticTokensProvider_1 = require("./semanticTokensProvider");
const signatureProvider_1 = require("./signatureProvider");
const symbolProvider_1 = require("./symbolProvider");
const validationProvider_1 = require("./validationProvider");
// Export all types and interfaces
__exportStar(require("./types"), exports);
// Export all providers
var codeActionsProvider_2 = require("./codeActionsProvider");
Object.defineProperty(exports, "PrologCodeActionsProvider", { enumerable: true, get: function () { return codeActionsProvider_2.PrologCodeActionsProvider; } });
var completionProvider_2 = require("./completionProvider");
Object.defineProperty(exports, "PrologCompletionProvider", { enumerable: true, get: function () { return completionProvider_2.PrologCompletionProvider; } });
var configurationManager_1 = require("./configurationManager");
Object.defineProperty(exports, "ConfigurationManager", { enumerable: true, get: function () { return configurationManager_1.ConfigurationManager; } });
var definitionProvider_2 = require("./definitionProvider");
Object.defineProperty(exports, "PrologDefinitionProvider", { enumerable: true, get: function () { return definitionProvider_2.PrologDefinitionProvider; } });
var executeCommandHandler_2 = require("./executeCommandHandler");
Object.defineProperty(exports, "PrologExecuteCommandHandler", { enumerable: true, get: function () { return executeCommandHandler_2.PrologExecuteCommandHandler; } });
var foldingProvider_2 = require("./foldingProvider");
Object.defineProperty(exports, "PrologFoldingProvider", { enumerable: true, get: function () { return foldingProvider_2.PrologFoldingProvider; } });
var formattingProvider_2 = require("./formattingProvider");
Object.defineProperty(exports, "PrologFormattingProvider", { enumerable: true, get: function () { return formattingProvider_2.PrologFormattingProvider; } });
var hoverProvider_2 = require("./hoverProvider");
Object.defineProperty(exports, "PrologHoverProvider", { enumerable: true, get: function () { return hoverProvider_2.PrologHoverProvider; } });
var referencesProvider_2 = require("./referencesProvider");
Object.defineProperty(exports, "PrologReferencesProvider", { enumerable: true, get: function () { return referencesProvider_2.PrologReferencesProvider; } });
var renameProvider_2 = require("./renameProvider");
Object.defineProperty(exports, "PrologRenameProvider", { enumerable: true, get: function () { return renameProvider_2.PrologRenameProvider; } });
var semanticTokensProvider_2 = require("./semanticTokensProvider");
Object.defineProperty(exports, "PrologSemanticTokensProvider", { enumerable: true, get: function () { return semanticTokensProvider_2.PrologSemanticTokensProvider; } });
var signatureProvider_2 = require("./signatureProvider");
Object.defineProperty(exports, "PrologSignatureProvider", { enumerable: true, get: function () { return signatureProvider_2.PrologSignatureProvider; } });
var symbolProvider_2 = require("./symbolProvider");
Object.defineProperty(exports, "PrologSymbolProvider", { enumerable: true, get: function () { return symbolProvider_2.PrologSymbolProvider; } });
var validationProvider_2 = require("./validationProvider");
Object.defineProperty(exports, "PrologValidationProvider", { enumerable: true, get: function () { return validationProvider_2.PrologValidationProvider; } });
// Convenience factory function to create all providers
function createLSPProviders() {
    return {
        validationProvider: new validationProvider_1.PrologValidationProvider(),
        completionProvider: new completionProvider_1.PrologCompletionProvider(),
        hoverProvider: new hoverProvider_1.PrologHoverProvider(),
        codeActionsProvider: new codeActionsProvider_1.PrologCodeActionsProvider(),
        executeCommandHandler: new executeCommandHandler_1.PrologExecuteCommandHandler(),
        definitionProvider: new definitionProvider_1.PrologDefinitionProvider(),
        symbolProvider: new symbolProvider_1.PrologSymbolProvider(),
        referencesProvider: new referencesProvider_1.PrologReferencesProvider(),
        signatureProvider: new signatureProvider_1.PrologSignatureProvider(),
        formattingProvider: new formattingProvider_1.PrologFormattingProvider(),
        renameProvider: new renameProvider_1.PrologRenameProvider(),
        foldingProvider: new foldingProvider_1.PrologFoldingProvider(),
        semanticTokensProvider: new semanticTokensProvider_1.PrologSemanticTokensProvider(),
    };
}
// Version information
exports.LSP_MODULE_VERSION = '1.0.0';
//# sourceMappingURL=index.js.map