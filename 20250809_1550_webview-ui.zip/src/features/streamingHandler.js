"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaginatedStreamer = exports.StreamingHandler = void 0;
exports.createPrologResultStreamer = createPrologResultStreamer;
exports.createFileStreamer = createFileStreamer;
exports.streamQueryResults = streamQueryResults;
exports.createChatStreamer = createChatStreamer;
exports.streamToChatResponse = streamToChatResponse;
const events_1 = require("events");
const vscode_1 = require("vscode");
class StreamingHandler extends events_1.EventEmitter {
    options;
    buffer = [];
    totalProcessed = 0;
    isStreaming = false;
    bufferTimer;
    constructor(options = {}) {
        super();
        this.options = {
            chunkSize: options.chunkSize ?? 20,
            maxTotalResults: options.maxTotalResults ?? 1000,
            progressTitle: options.progressTitle ?? 'Processing results',
            showProgress: options.showProgress ?? true,
            bufferTimeout: options.bufferTimeout ?? 100,
        };
    }
    /**
     * Start streaming data processing
     */
    async startStreaming(dataSource, processor, cancellationToken) {
        if (this.isStreaming) {
            throw new Error('Streaming is already in progress');
        }
        this.isStreaming = true;
        this.totalProcessed = 0;
        this.buffer = [];
        try {
            if (this.options.showProgress) {
                await this.streamWithProgress(dataSource, processor, cancellationToken);
            }
            else {
                await this.streamWithoutProgress(dataSource, processor, cancellationToken);
            }
        }
        finally {
            this.isStreaming = false;
            this.clearBuffer();
        }
    }
    /**
     * Stream with progress indication
     */
    async streamWithProgress(dataSource, processor, cancellationToken) {
        return vscode_1.window.withProgress({
            location: vscode_1.ProgressLocation.Notification,
            title: this.options.progressTitle,
            cancellable: true,
        }, async (progress, token) => {
            const effectiveToken = cancellationToken || token;
            await this.processStream(dataSource, processor, progress, effectiveToken);
        });
    }
    /**
     * Stream without progress indication
     */
    async streamWithoutProgress(dataSource, processor, cancellationToken) {
        await this.processStream(dataSource, processor, undefined, cancellationToken);
    }
    /**
     * Process the stream data
     */
    async processStream(dataSource, processor, progress, cancellationToken) {
        let chunkIndex = 0;
        let isFirst = true;
        let totalCount;
        // Handle array data source
        if (Array.isArray(dataSource)) {
            totalCount = Math.min(dataSource.length, this.options.maxTotalResults);
            const chunks = this.chunkArray(dataSource.slice(0, this.options.maxTotalResults), this.options.chunkSize);
            for (const chunk of chunks) {
                if (cancellationToken?.isCancellationRequested) {
                    break;
                }
                const isLast = chunkIndex === chunks.length - 1;
                const streamChunk = {
                    data: chunk,
                    index: chunkIndex,
                    isFirst,
                    isLast,
                    totalCount,
                    hasMore: !isLast,
                };
                await processor(streamChunk);
                this.totalProcessed += chunk.length;
                chunkIndex++;
                isFirst = false;
                if (progress) {
                    const percentage = (this.totalProcessed / totalCount) * 100;
                    progress.report({
                        message: `Processed ${this.totalProcessed} of ${totalCount} results`,
                        increment: percentage / chunks.length,
                    });
                }
                this.emit('chunk', streamChunk);
            }
        }
        else {
            // Handle async iterable data source
            for await (const item of dataSource) {
                if (cancellationToken?.isCancellationRequested) {
                    break;
                }
                if (this.totalProcessed >= this.options.maxTotalResults) {
                    break;
                }
                this.buffer.push(item);
                this.totalProcessed++;
                // Process buffer when it reaches chunk size or timeout
                if (this.buffer.length >= this.options.chunkSize) {
                    await this.flushBuffer(processor, chunkIndex, isFirst, false, progress);
                    chunkIndex++;
                    isFirst = false;
                }
                else {
                    // Set timeout to flush buffer if no more data comes quickly
                    this.resetBufferTimer(() => {
                        if (this.buffer.length > 0) {
                            this.flushBuffer(processor, chunkIndex, isFirst, false, progress);
                            chunkIndex++;
                            isFirst = false;
                        }
                    });
                }
            }
            // Flush remaining buffer
            if (this.buffer.length > 0) {
                await this.flushBuffer(processor, chunkIndex, isFirst, true, progress);
            }
        }
        this.emit('complete', { totalProcessed: this.totalProcessed });
    }
    /**
     * Flush the current buffer
     */
    async flushBuffer(processor, chunkIndex, isFirst, isLast, progress) {
        if (this.buffer.length === 0) {
            return;
        }
        const chunk = [...this.buffer];
        this.buffer = [];
        const streamChunk = {
            data: chunk,
            index: chunkIndex,
            isFirst,
            isLast,
            totalCount: undefined,
            hasMore: !isLast,
        };
        await processor(streamChunk);
        if (progress) {
            progress.report({
                message: `Processed ${this.totalProcessed} results`,
                increment: 10, // Arbitrary increment for unknown totals
            });
        }
        this.emit('chunk', streamChunk);
    }
    /**
     * Reset buffer timeout
     */
    resetBufferTimer(callback) {
        if (this.bufferTimer) {
            clearTimeout(this.bufferTimer);
        }
        this.bufferTimer = setTimeout(callback, this.options.bufferTimeout);
    }
    /**
     * Clear buffer and timer
     */
    clearBuffer() {
        this.buffer = [];
        if (this.bufferTimer) {
            clearTimeout(this.bufferTimer);
            this.bufferTimer = undefined;
        }
    }
    /**
     * Split array into chunks
     */
    chunkArray(array, chunkSize) {
        const chunks = [];
        for (let i = 0; i < array.length; i += chunkSize) {
            chunks.push(array.slice(i, i + chunkSize));
        }
        return chunks;
    }
    /**
     * Stop streaming (if in progress)
     */
    stop() {
        this.isStreaming = false;
        this.clearBuffer();
        this.emit('stopped');
    }
    /**
     * Check if currently streaming
     */
    get streaming() {
        return this.isStreaming;
    }
    /**
     * Get total processed count
     */
    get processed() {
        return this.totalProcessed;
    }
    /**
     * Update streaming options
     */
    updateOptions(newOptions) {
        this.options = { ...this.options, ...newOptions };
    }
}
exports.StreamingHandler = StreamingHandler;
/**
 * Utility function to create a streaming handler for Prolog results
 */
function createPrologResultStreamer(options) {
    return new StreamingHandler({
        chunkSize: 50,
        maxTotalResults: 1000,
        progressTitle: 'Processing Prolog results',
        showProgress: true,
        bufferTimeout: 100,
        ...options,
    });
}
/**
 * Utility function to create a streaming handler for large file processing
 */
function createFileStreamer(options) {
    return new StreamingHandler({
        chunkSize: 100,
        maxTotalResults: 10000,
        progressTitle: 'Processing file',
        showProgress: true,
        bufferTimeout: 50,
        ...options,
    });
}
/**
 * Stream processor for paginated results
 */
class PaginatedStreamer {
    currentPage = 0;
    pageSize;
    totalPages;
    constructor(pageSize = 20) {
        this.pageSize = pageSize;
    }
    /**
     * Process paginated data
     */
    async processPaginated(fetcher, processor, cancellationToken) {
        this.currentPage = 0;
        let isFirst = true;
        let totalCount;
        while (true) {
            if (cancellationToken?.isCancellationRequested) {
                break;
            }
            const result = await fetcher(this.currentPage, this.pageSize);
            if (result.totalCount !== undefined && totalCount === undefined) {
                totalCount = result.totalCount;
                this.totalPages = Math.ceil(totalCount / this.pageSize);
            }
            const isLast = !result.hasMore || result.data.length < this.pageSize;
            const streamChunk = {
                data: result.data,
                index: this.currentPage,
                isFirst,
                isLast,
                totalCount,
                hasMore: result.hasMore,
            };
            await processor(streamChunk);
            if (isLast || result.data.length === 0) {
                break;
            }
            this.currentPage++;
            isFirst = false;
        }
    }
    /**
     * Get current page number
     */
    getCurrentPage() {
        return this.currentPage;
    }
    /**
     * Get total pages (if known)
     */
    getTotalPages() {
        return this.totalPages;
    }
    /**
     * Reset pagination state
     */
    reset() {
        this.currentPage = 0;
        this.totalPages = undefined;
    }
}
exports.PaginatedStreamer = PaginatedStreamer;
/**
 * Utility for streaming large query results
 */
async function streamQueryResults(results, formatter, options) {
    const streamer = createPrologResultStreamer(options);
    const formattedChunks = [];
    await streamer.startStreaming(results, async (chunk) => {
        const formatted = formatter(chunk.data, chunk);
        formattedChunks.push(formatted);
    });
    return formattedChunks;
}
/**
 * Create a streaming handler optimized for chat responses
 */
function createChatStreamer(options) {
    return new StreamingHandler({
        chunkSize: 30,
        maxTotalResults: 2000,
        progressTitle: 'Processing chat response',
        showProgress: false, // Chat has its own progress indicators
        bufferTimeout: 50,
        ...options,
    });
}
/**
 * Stream large results to chat with progress updates
 */
async function streamToChatResponse(results, chatStream, // ChatResponseStream type
formatter, options) {
    if (results.length <= (options?.chunkSize || 30)) {
        // Small result set, process immediately
        formatter(results, true, true, results.length);
        return;
    }
    const streamer = createChatStreamer(options);
    const totalCount = results.length;
    await streamer.startStreaming(results, async (chunk) => {
        formatter(chunk.data, chunk.isFirst, chunk.isLast, totalCount);
        // Add small delay between chunks for better UX
        if (!chunk.isLast) {
            await new Promise(resolve => setTimeout(resolve, 50));
        }
    });
}
//# sourceMappingURL=streamingHandler.js.map