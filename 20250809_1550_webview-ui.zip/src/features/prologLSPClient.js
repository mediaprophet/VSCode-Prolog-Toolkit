"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrologLSPClient = void 0;
const node_1 = require("vscode-languageclient/node");
const vscode_1 = require("vscode");
const path = __importStar(require("path"));
class PrologLSPClient {
    client = null;
    context;
    constructor(context) {
        this.context = context;
    }
    async start() {
        if (this.client) {
            return; // Already started
        }
        try {
            // The server is implemented as a separate Node.js module
            const serverModule = this.context.asAbsolutePath(path.join('out', 'pub', 'features', 'prologLSPServer.js'));
            // The debug options for the server
            const debugOptions = { execArgv: ['--nolazy', '--inspect=6009'] };
            // If the extension is launched in debug mode then the debug server options are used
            // Otherwise the run options are used
            const serverOptions = {
                run: { module: serverModule, transport: node_1.TransportKind.ipc },
                debug: {
                    module: serverModule,
                    transport: node_1.TransportKind.ipc,
                    options: debugOptions,
                },
            };
            // Options to control the language client
            const clientOptions = {
                // Register the server for Prolog documents
                documentSelector: [
                    { scheme: 'file', language: 'prolog' },
                    { scheme: 'untitled', language: 'prolog' },
                ],
                synchronize: {
                    // Notify the server about file changes to '.pl', '.pro', '.prolog' files contained in the workspace
                    fileEvents: vscode_1.workspace.createFileSystemWatcher('**/*.{pl,pro,prolog,plt,ecl}'),
                },
                revealOutputChannelOn: node_1.RevealOutputChannelOn.Never,
                initializationOptions: {
                    // Pass configuration to the server
                    settings: vscode_1.workspace.getConfiguration('prolog'),
                },
                middleware: {
                    // Add custom middleware for enhanced functionality
                    provideCompletionItem: async (document, position, context, token, next) => {
                        const result = await next(document, position, context, token);
                        // Enhance completions with custom logic if needed
                        if (Array.isArray(result)) {
                            return this.enhanceCompletions(result, document, position);
                        }
                        return result;
                    },
                    provideHover: async (document, position, token, next) => {
                        const result = await next(document, position, token);
                        // Enhance hover information
                        if (result) {
                            return this.enhanceHover(result, document, position);
                        }
                        return result;
                    },
                },
            };
            // Create the language client and start the client.
            this.client = new node_1.LanguageClient('prologLSP', 'Prolog Language Server', serverOptions, clientOptions);
            // Register client event handlers
            this.registerEventHandlers();
            // Start the client. This will also launch the server
            await this.client.start();
            vscode_1.window.showInformationMessage('Prolog LSP Server started successfully');
        }
        catch (error) {
            vscode_1.window.showErrorMessage(`Failed to start Prolog LSP Server: ${error}`);
            throw error;
        }
    }
    async stop() {
        if (this.client) {
            await this.client.stop();
            this.client = null;
        }
    }
    async restart() {
        await this.stop();
        await this.start();
    }
    isRunning() {
        return this.client !== null && this.client.state === 2; // Running state
    }
    registerEventHandlers() {
        if (!this.client) {
            return;
        }
        // Handle server ready - use the client.start() promise instead of onReady()
        // The onReady() method has been removed in newer versions of vscode-languageclient
        // We'll register custom handlers after the client starts successfully
        // Handle server errors
        this.client.onDidChangeState(event => {
            console.log(`LSP Client state changed: ${event.oldState} -> ${event.newState}`);
            if (event.newState === 2) {
                // Running state - register handlers when client becomes ready
                console.log('Prolog LSP Server is ready');
                this.registerCustomHandlers();
            }
            else if (event.newState === 3) {
                // Stopped state
                vscode_1.window.showWarningMessage('Prolog LSP Server stopped unexpectedly');
            }
        });
    }
    registerCustomHandlers() {
        if (!this.client) {
            return;
        }
        // Register custom request handlers for enhanced functionality
        this.client.onRequest('prolog/queryResult', params => {
            // Handle query results from server
            return this.handleQueryResult(params);
        });
        this.client.onRequest('prolog/helpResult', params => {
            // Handle help results from server
            return this.handleHelpResult(params);
        });
        this.client.onNotification('prolog/diagnosticsUpdate', params => {
            // Handle diagnostic updates
            this.handleDiagnosticsUpdate(params);
        });
    }
    enhanceCompletions(completions, document, position) {
        // Add context-aware completions
        const text = document.getText();
        const line = text.split('\n')[position.line];
        // Add N3/RDF completions if in semantic web context
        if (this.isSemanticWebContext(text)) {
            const semanticCompletions = this.getSemanticWebCompletions();
            completions.push(...semanticCompletions);
        }
        // Add project-specific completions
        const projectCompletions = this.getProjectSpecificCompletions(document);
        completions.push(...projectCompletions);
        return completions;
    }
    enhanceHover(hover, document, position) {
        // Enhance hover with additional information
        const word = this.getWordAtPosition(document.getText(), position);
        if (word && this.isBuiltinPredicate(word)) {
            // Add links to documentation
            if (hover.contents) {
                const enhanced = hover.contents +
                    '\n\n[📖 View full documentation](https://www.swi-prolog.org/pldoc/man?predicate=' +
                    word +
                    ')';
                return { ...hover, contents: enhanced };
            }
        }
        return hover;
    }
    isSemanticWebContext(text) {
        return (text.includes('@prefix') ||
            text.includes('rdf:') ||
            text.includes('rdfs:') ||
            text.includes('owl:'));
    }
    getSemanticWebCompletions() {
        return [
            {
                label: 'rdf_load',
                kind: 3, // Function
                detail: 'rdf_load/2',
                documentation: 'Load RDF data from file or URL',
            },
            {
                label: 'rdf_assert',
                kind: 3,
                detail: 'rdf_assert/3',
                documentation: 'Assert RDF triple',
            },
            {
                label: 'rdf_retract',
                kind: 3,
                detail: 'rdf_retract/3',
                documentation: 'Retract RDF triple',
            },
        ];
    }
    getProjectSpecificCompletions(document) {
        // Analyze project structure and provide relevant completions
        const workspaceFolder = vscode_1.workspace.getWorkspaceFolder(document.uri);
        if (!workspaceFolder) {
            return [];
        }
        // This could be enhanced to scan project files for predicates
        return [];
    }
    getWordAtPosition(text, position) {
        const lines = text.split('\n');
        const line = lines[position.line];
        if (!line) {
            return null;
        }
        const char = position.character;
        let start = char;
        let end = char;
        while (start > 0 && /[a-zA-Z0-9_]/.test(line[start - 1])) {
            start--;
        }
        while (end < line.length && /[a-zA-Z0-9_]/.test(line[end])) {
            end++;
        }
        return start < end ? line.substring(start, end) : null;
    }
    isBuiltinPredicate(predicate) {
        const builtins = [
            'member',
            'append',
            'length',
            'reverse',
            'sort',
            'findall',
            'bagof',
            'setof',
            'assert',
            'retract',
            'write',
            'writeln',
            'nl',
            'is',
            'var',
            'nonvar',
        ];
        return builtins.includes(predicate);
    }
    handleQueryResult(params) {
        // Handle query results from server
        console.log('Query result received:', params);
        return null;
    }
    handleHelpResult(params) {
        // Handle help results from server
        console.log('Help result received:', params);
        return null;
    }
    handleDiagnosticsUpdate(params) {
        // Handle diagnostic updates
        console.log('Diagnostics updated:', params);
    }
    // Public API for external use
    async executeQuery(query) {
        if (!this.client) {
            throw new Error('LSP client not started');
        }
        return await this.client.sendRequest('prolog/executeQuery', { query });
    }
    async getHelp(predicate) {
        if (!this.client) {
            throw new Error('LSP client not started');
        }
        return await this.client.sendRequest('prolog/getHelp', { predicate });
    }
    async consultFile(filePath) {
        if (!this.client) {
            throw new Error('LSP client not started');
        }
        return await this.client.sendRequest('prolog/consultFile', { filePath });
    }
}
exports.PrologLSPClient = PrologLSPClient;
//# sourceMappingURL=prologLSPClient.js.map