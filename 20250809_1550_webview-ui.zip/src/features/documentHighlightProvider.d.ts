import { CancellationToken, DocumentHighlightProvider, Position, TextDocument, DocumentHighlight } from 'vscode';
export default class PrologDocumentHighlightProvider implements DocumentHighlightProvider {
    provideDocumentHighlights(doc: TextDocument, position: Position, _token: CancellationToken): Promise<DocumentHighlight[]> | DocumentHighlight[];
}
//# sourceMappingURL=documentHighlightProvider.d.ts.map