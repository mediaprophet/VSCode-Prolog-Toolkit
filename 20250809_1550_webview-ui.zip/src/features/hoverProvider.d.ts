import { CancellationToken, Hover, HoverProvider, Position, TextDocument } from 'vscode';
export default class PrologHoverProvider implements HoverProvider {
    private textToMarkedString;
    provideHover(doc: TextDocument, position: Position, _token: CancellationToken): Hover | undefined;
}
//# sourceMappingURL=hoverProvider.d.ts.map