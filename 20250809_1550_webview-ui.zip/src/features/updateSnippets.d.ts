import { CancellationToken, CompletionContext, Position, TextDocument } from 'vscode';
export declare class SnippetUpdater {
    updateSnippet(): void;
    _getPredicat(doc: TextDocument): any[];
    dispose(): void;
}
export declare class SnippetUpdaterController {
    private snippetUpdater;
    private _disposable;
    constructor(snippetUpdater: SnippetUpdater);
    dispose(): void;
    private _onEvent;
}
export declare class PrologCompletionProvider {
    provideCompletionItems(document: TextDocument, position: Position, token: CancellationToken, context: CompletionContext): any[];
}
//# sourceMappingURL=updateSnippets.d.ts.map