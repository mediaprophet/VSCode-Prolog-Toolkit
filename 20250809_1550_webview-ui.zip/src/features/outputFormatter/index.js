"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.detailedFormatter = exports.compactFormatter = exports.defaultFormatter = exports.OutputFormatter = void 0;
const bindingsFormatter_1 = require("./bindingsFormatter");
const codeFormatter_1 = require("./codeFormatter");
const helpFormatter_1 = require("./helpFormatter");
const largeResultFormatter_1 = require("./largeResultFormatter");
const paginationFormatter_1 = require("./paginationFormatter");
const resultFormatter_1 = require("./resultFormatter");
const streamingFormatter_1 = require("./streamingFormatter");
class OutputFormatter {
    options;
    bindingsFormatter;
    resultFormatter;
    codeFormatter;
    helpFormatter;
    streamingFormatter;
    paginationFormatter;
    largeResultFormatter;
    constructor(options = {}) {
        this.options = {
            maxResults: options.maxResults ?? 50,
            maxLineLength: options.maxLineLength ?? 120,
            useCodeBlocks: options.useCodeBlocks ?? true,
            showLineNumbers: options.showLineNumbers ?? false,
            highlightVariables: options.highlightVariables ?? true,
            compactMode: options.compactMode ?? false,
            locale: options.locale ?? 'en',
        };
        this.bindingsFormatter = new bindingsFormatter_1.BindingsFormatter(this.options);
        this.resultFormatter = new resultFormatter_1.ResultFormatter(this.options);
        this.codeFormatter = new codeFormatter_1.CodeFormatter(this.options);
        this.helpFormatter = new helpFormatter_1.HelpFormatter(this.options);
        this.streamingFormatter = new streamingFormatter_1.StreamingFormatter(this.options);
        this.paginationFormatter = new paginationFormatter_1.PaginationFormatter(this.options);
        this.largeResultFormatter = new largeResultFormatter_1.LargeResultFormatter(this.options);
    }
    formatQueryResult(result) {
        return this.resultFormatter.format(result);
    }
    formatVariableBindings(bindings) {
        return this.bindingsFormatter.format(bindings);
    }
    formatPrologCode(code, title) {
        return this.codeFormatter.formatPrologCode(code, title);
    }
    formatHelpText(predicate, documentation) {
        return this.helpFormatter.formatHelpText(predicate, documentation);
    }
    formatStreamingOutput(chunk, isFirst, isLast, totalCount, chunkIndex) {
        return this.streamingFormatter.formatStreamingOutput(chunk, isFirst, isLast, totalCount, chunkIndex);
    }
    formatPaginatedOutput(results, pagination) {
        return this.paginationFormatter.formatPaginatedOutput(results, pagination);
    }
    formatLargeResultSet(results, totalCount) {
        return this.largeResultFormatter.formatLargeResultSet(results, totalCount);
    }
    updateOptions(newOptions) {
        this.options = { ...this.options, ...newOptions };
    }
    getOptions() {
        return { ...this.options };
    }
}
exports.OutputFormatter = OutputFormatter;
exports.defaultFormatter = new OutputFormatter();
exports.compactFormatter = new OutputFormatter({ compactMode: true, maxResults: 10, useCodeBlocks: false });
exports.detailedFormatter = new OutputFormatter({ compactMode: false, maxResults: 100, useCodeBlocks: true, showLineNumbers: true, highlightVariables: true });
//# sourceMappingURL=index.js.map