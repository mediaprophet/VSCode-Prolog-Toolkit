import { FormattingOptions, PrologResult } from './types';
export declare class OutputFormatter {
    private options;
    private bindingsFormatter;
    private resultFormatter;
    private codeFormatter;
    private helpFormatter;
    private streamingFormatter;
    private paginationFormatter;
    private largeResultFormatter;
    constructor(options?: FormattingOptions);
    formatQueryResult(result: PrologResult): string;
    formatVariableBindings(bindings: Record<string, any>[]): string;
    formatPrologCode(code: string, title?: string): string;
    formatHelpText(predicate: string, documentation: string): string;
    formatStreamingOutput(chunk: any[], isFirst: boolean, isLast: boolean, totalCount?: number, chunkIndex?: number): string;
    formatPaginatedOutput(results: any[], pagination: {
        total_count: number;
        offset: number;
        limit: number;
        has_more: boolean;
        next_offset?: number | null;
    }): string;
    formatLargeResultSet(results: any[], totalCount?: number): string;
    updateOptions(newOptions: Partial<FormattingOptions>): void;
    getOptions(): FormattingOptions;
}
export declare const defaultFormatter: OutputFormatter;
export declare const compactFormatter: OutputFormatter;
export declare const detailedFormatter: OutputFormatter;
//# sourceMappingURL=index.d.ts.map