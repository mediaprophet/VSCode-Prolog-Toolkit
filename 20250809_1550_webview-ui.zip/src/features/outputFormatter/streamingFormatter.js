"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StreamingFormatter = void 0;
const resultFormatter_1 = require("./resultFormatter");
class StreamingFormatter {
    options;
    resultFormatter;
    constructor(options) {
        this.options = options;
        this.resultFormatter = new resultFormatter_1.ResultFormatter(options);
    }
    formatStreamingOutput(chunk, isFirst, isLast, totalCount, chunkIndex) {
        let result = '';
        if (isFirst && totalCount !== undefined) {
            result += `📊 **Streaming results** (${totalCount} total):\n\n`;
        }
        if (chunk.length > 0) {
            if (!isFirst && chunkIndex !== undefined) {
                result += `\n**Chunk ${chunkIndex + 1}:**\n`;
            }
            const chunkResult = {
                type: 'multiple',
                bindings: chunk,
                count: chunk.length,
            };
            const originalCompactMode = this.options.compactMode;
            this.options.compactMode = totalCount ? totalCount > 50 : chunk.length > 20;
            result += this.resultFormatter.format(chunkResult);
            this.options.compactMode = originalCompactMode;
        }
        if (isLast) {
            result += '\n✅ **Streaming complete**\n';
        }
        else {
            result += '\n⏳ *Loading more results...*\n';
        }
        return result;
    }
}
exports.StreamingFormatter = StreamingFormatter;
//# sourceMappingURL=streamingFormatter.js.map