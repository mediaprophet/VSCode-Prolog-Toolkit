import { FormattingOptions } from './types';
export declare class HelpFormatter {
    private options;
    constructor(options: Required<FormattingOptions>);
    formatHelpText(predicate: string, documentation: string): string;
}
//# sourceMappingURL=helpFormatter.d.ts.map