import { FormattingOptions } from './types';
export declare class BindingsFormatter {
    private options;
    constructor(options: Required<FormattingOptions>);
    format(bindings: Record<string, any>[]): string;
    private formatSingleBinding;
    private formatMultipleBindings;
    private formatCompactTable;
    private formatDetailedList;
    private formatValue;
}
//# sourceMappingURL=bindingsFormatter.d.ts.map