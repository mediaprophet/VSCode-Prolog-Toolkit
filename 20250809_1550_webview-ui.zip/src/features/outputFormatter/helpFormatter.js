"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HelpFormatter = void 0;
class HelpFormatter {
    options;
    constructor(options) {
        this.options = options;
    }
    formatHelpText(predicate, documentation) {
        let result = `📖 **Help for \`${predicate}\`:**\n\n`;
        const lines = documentation.split('\n');
        let inCodeBlock = false;
        for (const line of lines) {
            const trimmed = line.trim();
            if (trimmed.startsWith('?-') ||
                trimmed.includes(':-') ||
                trimmed.match(/^[a-z][a-zA-Z0-9_]*\(/)) {
                if (!inCodeBlock && this.options.useCodeBlocks) {
                    result += '```prolog\n';
                    inCodeBlock = true;
                }
                result += line + '\n';
            }
            else {
                if (inCodeBlock && this.options.useCodeBlocks) {
                    result += '```\n';
                    inCodeBlock = false;
                }
                result += line + '\n';
            }
        }
        if (inCodeBlock && this.options.useCodeBlocks) {
            result += '```\n';
        }
        return result;
    }
}
exports.HelpFormatter = HelpFormatter;
//# sourceMappingURL=helpFormatter.js.map