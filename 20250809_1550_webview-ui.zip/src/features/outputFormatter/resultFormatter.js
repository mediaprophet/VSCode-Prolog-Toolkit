"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResultFormatter = void 0;
const bindingsFormatter_1 = require("./bindingsFormatter");
class ResultFormatter {
    options;
    bindingsFormatter;
    constructor(options) {
        this.options = options;
        this.bindingsFormatter = new bindingsFormatter_1.BindingsFormatter(options);
    }
    format(result) {
        switch (result.type) {
            case 'success':
                return this.formatSuccess(result);
            case 'failure':
                return this.formatFailure(result);
            case 'error':
                return this.formatError(result);
            case 'multiple':
                return this.formatMultiple(result);
            default:
                return this.formatUnknown(result);
        }
    }
    formatSuccess(result) {
        if (result.bindings && result.bindings.length > 0) {
            return this.bindingsFormatter.format(result.bindings);
        }
        return '✅ **Query succeeded**\n' + (result.message ? `\n${result.message}\n` : '');
    }
    formatFailure(result) {
        return '❌ **Query failed**\n' + (result.message ? `\n${result.message}\n` : '');
    }
    formatError(result) {
        let output = '🚫 **Query error**\n\n';
        if (result.error) {
            if (this.options.useCodeBlocks) {
                output += '```\n' + result.error + '\n```\n';
            }
            else {
                output += result.error + '\n';
            }
        }
        if (result.message) {
            output += '\n' + result.message + '\n';
        }
        return output;
    }
    formatMultiple(result) {
        if (result.bindings) {
            return this.bindingsFormatter.format(result.bindings);
        }
        return `✅ **Query succeeded** (${result.count || 0} results)\n`;
    }
    formatUnknown(result) {
        return `⚠️ **Unknown result type**: ${JSON.stringify(result)}\n`;
    }
}
exports.ResultFormatter = ResultFormatter;
//# sourceMappingURL=resultFormatter.js.map