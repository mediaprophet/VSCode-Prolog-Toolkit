"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CodeFormatter = void 0;
class CodeFormatter {
    options;
    constructor(options) {
        this.options = options;
    }
    formatPrologCode(code, title) {
        let result = '';
        if (title)
            result += `**${title}:**\n\n`;
        if (this.options.useCodeBlocks) {
            result += '```prolog\n' + code;
            if (!code.endsWith('\n'))
                result += '\n';
            result += '```\n';
        }
        else {
            result += code + '\n';
        }
        return result;
    }
}
exports.CodeFormatter = CodeFormatter;
//# sourceMappingURL=codeFormatter.js.map