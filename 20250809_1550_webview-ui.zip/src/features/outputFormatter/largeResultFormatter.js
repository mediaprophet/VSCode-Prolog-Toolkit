"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LargeResultFormatter = void 0;
const resultFormatter_1 = require("./resultFormatter");
class LargeResultFormatter {
    options;
    resultFormatter;
    constructor(options) {
        this.options = options;
        this.resultFormatter = new resultFormatter_1.ResultFormatter(options);
    }
    formatLargeResultSet(results, totalCount) {
        const displayCount = results.length;
        const actualTotal = totalCount || displayCount;
        let result = '';
        if (actualTotal > displayCount) {
            result += `📊 **Large Result Set** (showing first ${displayCount} of ${actualTotal}):\n\n`;
            result += `*💡 Performance tip: Results are automatically chunked for better performance*\n\n`;
        }
        else {
            result += `📊 **Results** (${displayCount} total):\n\n`;
        }
        const useUltraCompact = displayCount > 100;
        const useCompact = displayCount > 30;
        if (useUltraCompact) {
            result += '```\n';
            results.slice(0, 50).forEach((item, index) => {
                result += `${index + 1}. ${this.formatValueCompact(item)}\n`;
            });
            if (displayCount > 50) {
                result += `... and ${displayCount - 50} more results\n`;
            }
            result += '```\n';
        }
        else if (useCompact) {
            result += '```\n';
            results.forEach((item, index) => {
                result += `${index + 1}. ${this.formatValueCompact(item)}\n`;
            });
            result += '```\n';
        }
        else {
            const resultObj = {
                type: 'multiple',
                bindings: results,
                count: displayCount,
            };
            result += this.resultFormatter.format(resultObj);
        }
        return result;
    }
    formatValueCompact(value) {
        if (typeof value === 'object' && value !== null) {
            if (Array.isArray(value)) {
                return `[${value.map(v => this.resultFormatter['bindingsFormatter']['formatValue'](v)).join(',')}]`;
            }
            else {
                const entries = Object.entries(value);
                if (entries.length <= 3) {
                    return entries.map(([k, v]) => `${k}=${this.resultFormatter['bindingsFormatter']['formatValue'](v)}`).join(', ');
                }
                else {
                    return `{${entries.length} bindings}`;
                }
            }
        }
        return this.resultFormatter['bindingsFormatter']['formatValue'](value);
    }
}
exports.LargeResultFormatter = LargeResultFormatter;
//# sourceMappingURL=largeResultFormatter.js.map