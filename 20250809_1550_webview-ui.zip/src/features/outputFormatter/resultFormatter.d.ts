import { FormattingOptions, PrologResult } from './types';
export declare class ResultFormatter {
    private options;
    private bindingsFormatter;
    constructor(options: Required<FormattingOptions>);
    format(result: PrologResult): string;
    private formatSuccess;
    private formatFailure;
    private formatError;
    private formatMultiple;
    private formatUnknown;
}
//# sourceMappingURL=resultFormatter.d.ts.map