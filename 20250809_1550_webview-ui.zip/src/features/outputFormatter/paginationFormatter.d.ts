import { FormattingOptions } from './types';
export declare class PaginationFormatter {
    private options;
    constructor(options: Required<FormattingOptions>);
    formatPaginatedOutput(results: any[], pagination: {
        total_count: number;
        offset: number;
        limit: number;
        has_more: boolean;
        next_offset?: number | null;
    }): string;
}
//# sourceMappingURL=paginationFormatter.d.ts.map