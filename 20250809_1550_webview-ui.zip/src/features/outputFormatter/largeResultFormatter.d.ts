import { FormattingOptions } from './types';
export declare class LargeResultFormatter {
    private options;
    private resultFormatter;
    constructor(options: Required<FormattingOptions>);
    formatLargeResultSet(results: any[], totalCount?: number): string;
    private formatValueCompact;
}
//# sourceMappingURL=largeResultFormatter.d.ts.map