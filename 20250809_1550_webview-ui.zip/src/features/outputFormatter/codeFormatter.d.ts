import { FormattingOptions } from './types';
export declare class CodeFormatter {
    private options;
    constructor(options: Required<FormattingOptions>);
    formatPrologCode(code: string, title?: string): string;
}
//# sourceMappingURL=codeFormatter.d.ts.map