"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BindingsFormatter = void 0;
class BindingsFormatter {
    options;
    constructor(options) {
        this.options = options;
    }
    format(bindings) {
        if (!bindings || bindings.length === 0) {
            return '✅ **Query succeeded** (no variable bindings)\n';
        }
        if (bindings.length === 1 && bindings[0]) {
            return this.formatSingleBinding(bindings[0]);
        }
        return this.formatMultipleBindings(bindings);
    }
    formatSingleBinding(binding) {
        const variables = Object.keys(binding);
        if (variables.length === 0) {
            return '✅ **Query succeeded** (no variables)\n';
        }
        let result = '✅ **Query succeeded:**\n\n';
        if (this.options.useCodeBlocks)
            result += '```prolog\n';
        for (const [variable, value] of Object.entries(binding)) {
            result += `${variable} = ${this.formatValue(value)}\n`;
        }
        if (this.options.useCodeBlocks)
            result += '```\n';
        return result;
    }
    formatMultipleBindings(bindings) {
        const allVariables = new Set();
        bindings.forEach(binding => {
            Object.keys(binding).forEach(variable => allVariables.add(variable));
        });
        const variables = Array.from(allVariables).sort();
        const displayCount = Math.min(bindings.length, this.options.maxResults);
        const hasMore = bindings.length > this.options.maxResults;
        let result = `✅ **Query succeeded** (${bindings.length} solution${bindings.length === 1 ? '' : 's'}):\n\n`;
        if (variables.length === 0) {
            result += `Found ${bindings.length} solution${bindings.length === 1 ? '' : 's'} with no variable bindings.\n`;
            return result;
        }
        if (this.options.compactMode && variables.length <= 3) {
            result += this.formatCompactTable(bindings.slice(0, displayCount), variables);
        }
        else {
            result += this.formatDetailedList(bindings.slice(0, displayCount), variables);
        }
        if (hasMore) {
            result += `\n*... and ${bindings.length - displayCount} more solution${bindings.length - displayCount === 1 ? '' : 's'}*\n`;
        }
        return result;
    }
    formatCompactTable(bindings, variables) {
        let result = '';
        if (this.options.useCodeBlocks)
            result += '```\n';
        const headers = variables.map(v => v.padEnd(12)).join(' | ');
        result += `| ${headers} |\n`;
        result += `|${variables.map(() => '-------------').join('|')}|\n`;
        for (let i = 0; i < bindings.length; i++) {
            const binding = bindings[i];
            if (binding) {
                const row = variables
                    .map(variable => {
                    const value = binding[variable];
                    const formatted = value !== undefined ? this.formatValue(value) : '-';
                    return formatted.substring(0, 12).padEnd(12);
                })
                    .join(' | ');
                result += `| ${row} |\n`;
            }
        }
        if (this.options.useCodeBlocks)
            result += '```\n';
        return result;
    }
    formatDetailedList(bindings, variables) {
        let result = '';
        for (let i = 0; i < bindings.length; i++) {
            const binding = bindings[i];
            if (binding) {
                result += `**Solution ${i + 1}:**\n`;
                if (this.options.useCodeBlocks)
                    result += '```prolog\n';
                for (const variable of variables) {
                    const value = binding[variable];
                    if (value !== undefined) {
                        result += `${variable} = ${this.formatValue(value)}\n`;
                    }
                }
                if (this.options.useCodeBlocks)
                    result += '```\n';
                result += '\n';
            }
        }
        return result;
    }
    formatValue(value) {
        if (value === null || value === undefined)
            return '_';
        if (typeof value === 'string') {
            if (value.includes(' ') || value.includes('(') || /^[A-Z]/.test(value))
                return `'${value}'`;
            return value;
        }
        if (typeof value === 'number')
            return value.toString();
        if (typeof value === 'boolean')
            return value ? 'true' : 'false';
        if (Array.isArray(value))
            return `[${value.map(v => this.formatValue(v)).join(', ')}]`;
        if (typeof value === 'object') {
            if (value.functor && value.args) {
                const args = value.args.map((arg) => this.formatValue(arg)).join(', ');
                return `${value.functor}(${args})`;
            }
            return JSON.stringify(value);
        }
        return String(value);
    }
}
exports.BindingsFormatter = BindingsFormatter;
//# sourceMappingURL=bindingsFormatter.js.map