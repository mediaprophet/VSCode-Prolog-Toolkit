import { FormattingOptions } from './types';
export declare class StreamingFormatter {
    private options;
    private resultFormatter;
    constructor(options: Required<FormattingOptions>);
    formatStreamingOutput(chunk: any[], isFirst: boolean, isLast: boolean, totalCount?: number, chunkIndex?: number): string;
}
//# sourceMappingURL=streamingFormatter.d.ts.map