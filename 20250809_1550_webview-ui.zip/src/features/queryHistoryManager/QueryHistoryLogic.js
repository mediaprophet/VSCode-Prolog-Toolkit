"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.QueryHistoryLogic = void 0;
const events_1 = require("events");
/**
 * Query entry metadata structure:
 * {
 *   tags?: string[];
 *   userAgent?: string;
 *   sessionId?: string;
 *   source?: 'ui' | 'api' | 'automation';
 *   resourceUsage?: { cpuPercent?: number; memoryMB?: number; durationMs?: number };
 *   artifacts?: Array<{ name: string; path: string; type?: string }>;
 *   ...
 * }
 */
class QueryHistoryLogic extends events_1.EventEmitter {
    storage;
    options;
    constructor(storage, options = {}) {
        super();
        this.storage = storage;
        this.options = options;
    }
    async addQuery(entry) {
        // Ensure metadata fields exist and are normalized
        entry.metadata = entry.metadata || {};
        if (!entry.metadata.source) {
            entry.metadata.source = 'ui'; // Default to UI if not specified
        }
        if (!entry.metadata.resourceUsage) {
            entry.metadata.resourceUsage = {};
        }
        if (!entry.metadata.artifacts) {
            entry.metadata.artifacts = [];
        }
        await this.storage.saveEntry(entry);
        this.emit('queryAdded', entry);
    }
    async updateQuery(queryId, updates) {
        let entries = await this.storage.loadHistory();
        let idx = entries.findIndex((e) => e.id === queryId);
        if (idx !== -1) {
            // Merge metadata fields if present
            if (updates.metadata) {
                entries[idx].metadata = { ...entries[idx].metadata, ...updates.metadata };
                delete updates.metadata;
            }
            entries[idx] = { ...entries[idx], ...updates };
            await this.storage.rewriteHistoryFile(entries);
            this.emit('queryUpdated', entries[idx]);
        }
    }
    async getHistory(filter = {}) {
        let entries = await this.storage.loadHistory();
        // Apply filtering, sorting, pagination
        if (filter.status)
            entries = entries.filter((e) => filter.status.includes(e.status));
        if (filter.cmd)
            entries = entries.filter((e) => e.cmd === filter.cmd);
        if (filter.priority)
            entries = entries.filter((e) => filter.priority.includes(e.priority));
        if (filter.tags)
            entries = entries.filter((e) => e.metadata?.tags?.some((t) => filter.tags.includes(t)));
        if (filter.startDate)
            entries = entries.filter((e) => e.startTime >= filter.startDate.getTime());
        if (filter.endDate)
            entries = entries.filter((e) => e.endTime && e.endTime <= filter.endDate.getTime());
        if (filter.sortBy) {
            entries = entries.sort((a, b) => {
                if (filter.sortOrder === 'desc')
                    return b[filter.sortBy] - a[filter.sortBy];
                return a[filter.sortBy] - b[filter.sortBy];
            });
        }
        if (filter.offset)
            entries = entries.slice(filter.offset);
        if (filter.limit)
            entries = entries.slice(0, filter.limit);
        return entries;
    }
    async getStatistics() {
        let entries = await this.storage.loadHistory();
        const stats = {
            totalQueries: entries.length,
            completedQueries: entries.filter((e) => e.status === 'completed').length,
            errorQueries: entries.filter((e) => e.status === 'error').length,
            cancelledQueries: entries.filter((e) => e.status === 'cancelled').length,
            timeoutQueries: entries.filter((e) => e.status === 'timeout').length,
            averageDuration: 0,
            totalDuration: 0,
            queriesByStatus: {},
            queriesByPriority: {},
            queriesByCmd: {},
            dailyStats: [],
        };
        let totalDuration = 0;
        let dailyMap = {};
        for (const e of entries) {
            if (e.duration)
                totalDuration += e.duration;
            stats.queriesByStatus[e.status] = (stats.queriesByStatus[e.status] || 0) + 1;
            if (e.priority)
                stats.queriesByPriority[e.priority] = (stats.queriesByPriority[e.priority] || 0) + 1;
            if (e.cmd)
                stats.queriesByCmd[e.cmd] = (stats.queriesByCmd[e.cmd] || 0) + 1;
            if (e.startTime) {
                const date = new Date(e.startTime).toISOString().slice(0, 10);
                if (!dailyMap[date])
                    dailyMap[date] = { count: 0, total: 0 };
                dailyMap[date].count++;
                if (e.duration)
                    dailyMap[date].total += e.duration;
            }
        }
        stats.totalDuration = totalDuration;
        stats.averageDuration = entries.length ? totalDuration / entries.length : 0;
        stats.dailyStats = Object.entries(dailyMap).map(([date, { count, total }]) => ({ date, count, avgDuration: count ? total / count : 0 }));
        return stats;
    }
    // --- Tag Management ---
    async addTags(queryId, tags) {
        let entries = await this.storage.loadHistory();
        let idx = entries.findIndex((e) => e.id === queryId);
        if (idx !== -1) {
            const entry = entries[idx];
            entry.metadata = entry.metadata || {};
            entry.metadata.tags = Array.from(new Set([...(entry.metadata.tags || []), ...tags]));
            await this.storage.rewriteHistoryFile(entries);
            this.emit('queryUpdated', entry);
        }
    }
    async removeTags(queryId, tags) {
        let entries = await this.storage.loadHistory();
        let idx = entries.findIndex((e) => e.id === queryId);
        if (idx !== -1) {
            const entry = entries[idx];
            entry.metadata = entry.metadata || {};
            entry.metadata.tags = (entry.metadata.tags || []).filter((t) => !tags.includes(t));
            await this.storage.rewriteHistoryFile(entries);
            this.emit('queryUpdated', entry);
        }
    }
    async getAllTags() {
        let entries = await this.storage.loadHistory();
        const tagSet = new Set();
        for (const e of entries) {
            if (e.metadata?.tags) {
                for (const t of e.metadata.tags)
                    tagSet.add(t);
            }
        }
        return Array.from(tagSet);
    }
    // --- Analytics Event Emission ---
    async emitAnalyticsUpdate() {
        const stats = await this.getStatistics();
        this.emit('analyticsUpdated', stats);
    }
}
exports.QueryHistoryLogic = QueryHistoryLogic;
//# sourceMappingURL=QueryHistoryLogic.js.map