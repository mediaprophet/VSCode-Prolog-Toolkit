"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.QueryHistoryEvents = void 0;
// Handles all event emission and subscription for query history management
const events_1 = require("events");
class QueryHistoryEvents extends events_1.EventEmitter {
    logic;
    storage;
    constructor(logic, storage) {
        super();
        this.logic = logic;
        this.storage = storage;
        // Example: Register for logic/storage events and re-emit as needed
        if (typeof logic.on === 'function') {
            logic.on('queryAdded', (data) => this.emit('queryAdded', data));
            logic.on('queryUpdated', (data) => this.emit('queryUpdated', data));
            logic.on('error', (err) => this.emit('error', err));
        }
        if (typeof storage.on === 'function') {
            storage.on('historyLoaded', (data) => this.emit('historyLoaded', data));
        }
    }
}
exports.QueryHistoryEvents = QueryHistoryEvents;
//# sourceMappingURL=QueryHistoryEvents.js.map