import { EventEmitter } from 'events';
import { QueryHistoryOptions } from '../queryHistoryManager';
export declare class QueryHistoryStorage extends EventEmitter {
    private options;
    private historyFile;
    private compressionEnabled;
    private retentionDays;
    private batchSize;
    constructor(options?: Partial<QueryHistoryOptions>);
    private readFile;
    private writeFile;
    loadHistory(): Promise<any[]>;
    saveEntry(entry: any): Promise<void>;
    deleteEntry(queryId: string): Promise<void>;
    rewriteHistoryFile(entries: any[]): Promise<void>;
    cleanupOldEntries(): Promise<void>;
}
//# sourceMappingURL=QueryHistoryStorage.d.ts.map