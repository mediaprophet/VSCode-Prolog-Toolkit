"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.QueryHistoryStorage = void 0;
// Handles all persistent storage for query history
const events_1 = require("events");
const fs = __importStar(require("fs/promises"));
const path = __importStar(require("path"));
const zlib = __importStar(require("zlib"));
class QueryHistoryStorage extends events_1.EventEmitter {
    options;
    historyFile;
    compressionEnabled;
    retentionDays;
    batchSize;
    constructor(options = {}) {
        super();
        this.options = options;
        this.historyFile = path.resolve(options.storageDir || '.', 'queryHistory.json' + (options.compressionEnabled ? '.gz' : ''));
        this.compressionEnabled = !!options.compressionEnabled;
        this.retentionDays = options.retentionDays ?? 30;
        this.batchSize = options.batchSize ?? 100;
    }
    async readFile() {
        try {
            let data;
            try {
                data = await fs.readFile(this.historyFile);
            }
            catch (e) {
                if (e.code === 'ENOENT')
                    return [];
                throw e;
            }
            let json;
            if (this.compressionEnabled) {
                json = zlib.gunzipSync(data).toString('utf8');
            }
            else {
                json = data.toString('utf8');
            }
            return JSON.parse(json);
        }
        catch (err) {
            this.emit('error', err);
            return [];
        }
    }
    async writeFile(entries) {
        try {
            let json = JSON.stringify(entries, null, 2);
            let data;
            if (this.compressionEnabled) {
                data = zlib.gzipSync(Buffer.from(json, 'utf8'));
            }
            else {
                data = Buffer.from(json, 'utf8');
            }
            await fs.writeFile(this.historyFile, data);
        }
        catch (err) {
            this.emit('error', err);
        }
    }
    async loadHistory() {
        const entries = await this.readFile();
        this.emit('historyLoaded', entries);
        return entries;
    }
    async saveEntry(entry) {
        let entries = await this.readFile();
        entries.push(entry);
        await this.writeFile(entries);
        this.emit('entrySaved', entry);
    }
    async deleteEntry(queryId) {
        let entries = await this.readFile();
        entries = entries.filter((e) => e.id !== queryId);
        await this.writeFile(entries);
        this.emit('entryDeleted', queryId);
    }
    async rewriteHistoryFile(entries) {
        await this.writeFile(entries);
        this.emit('historyRewritten', entries);
    }
    async cleanupOldEntries() {
        let entries = await this.readFile();
        const cutoff = Date.now() - this.retentionDays * 24 * 60 * 60 * 1000;
        entries = entries.filter((e) => !e.endTime || e.endTime >= cutoff);
        await this.writeFile(entries);
        this.emit('historyCleaned', entries);
    }
}
exports.QueryHistoryStorage = QueryHistoryStorage;
//# sourceMappingURL=QueryHistoryStorage.js.map