import { EventEmitter } from 'events';
import { QueryHistoryOptions } from '../queryHistoryManager';
export declare class QueryHistoryOrchestrator extends EventEmitter {
    private storage;
    private logic;
    private events;
    constructor(options?: Partial<QueryHistoryOptions>);
    private registerEventHandlers;
    /**
     * Add a query to history. Entry metadata may include:
     *   source: 'ui' | 'api' | 'automation'
     *   resourceUsage: { cpuPercent?: number; memoryMB?: number; durationMs?: number }
     *   artifacts: Array<{ name: string; path: string; type?: string }>
     */
    addQuery(entry: any): Promise<void>;
    updateQuery(queryId: string, updates: any): Promise<void>;
    getHistory(filter?: any): Promise<any>;
    addTags(queryId: string, tags: string[]): Promise<void>;
    removeTags(queryId: string, tags: string[]): Promise<void>;
    getAllTags(): Promise<string[]>;
    getStatistics(): Promise<any>;
    emitAnalyticsUpdate(): Promise<void>;
}
//# sourceMappingURL=QueryHistoryOrchestrator.d.ts.map