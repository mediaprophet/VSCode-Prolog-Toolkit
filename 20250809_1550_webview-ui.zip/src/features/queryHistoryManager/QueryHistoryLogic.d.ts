import { QueryHistoryOptions } from '../queryHistoryManager';
import { QueryHistoryStorage } from './QueryHistoryStorage';
import { EventEmitter } from 'events';
/**
 * Query entry metadata structure:
 * {
 *   tags?: string[];
 *   userAgent?: string;
 *   sessionId?: string;
 *   source?: 'ui' | 'api' | 'automation';
 *   resourceUsage?: { cpuPercent?: number; memoryMB?: number; durationMs?: number };
 *   artifacts?: Array<{ name: string; path: string; type?: string }>;
 *   ...
 * }
 */
export declare class QueryHistoryLogic extends EventEmitter {
    private storage;
    private options;
    constructor(storage: QueryHistoryStorage, options?: Partial<QueryHistoryOptions>);
    addQuery(entry: any): Promise<void>;
    updateQuery(queryId: string, updates: any): Promise<void>;
    getHistory(filter?: any): Promise<any[]>;
    getStatistics(): Promise<any>;
    addTags(queryId: string, tags: string[]): Promise<void>;
    removeTags(queryId: string, tags: string[]): Promise<void>;
    getAllTags(): Promise<string[]>;
    emitAnalyticsUpdate(): Promise<void>;
}
//# sourceMappingURL=QueryHistoryLogic.d.ts.map