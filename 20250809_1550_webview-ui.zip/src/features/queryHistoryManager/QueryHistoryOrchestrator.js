"use strict";
// Orchestrator for Query History Management
// Composes storage, logic, and event modules for robust, testable query history management
Object.defineProperty(exports, "__esModule", { value: true });
exports.QueryHistoryOrchestrator = void 0;
const events_1 = require("events");
const QueryHistoryEvents_1 = require("./QueryHistoryEvents");
const QueryHistoryLogic_1 = require("./QueryHistoryLogic");
const QueryHistoryStorage_1 = require("./QueryHistoryStorage");
class QueryHistoryOrchestrator extends events_1.EventEmitter {
    storage;
    logic;
    events;
    constructor(options = {}) {
        super();
        this.storage = new QueryHistoryStorage_1.QueryHistoryStorage(options);
        this.logic = new QueryHistoryLogic_1.QueryHistoryLogic(this.storage, options);
        this.events = new QueryHistoryEvents_1.QueryHistoryEvents(this.logic, this.storage);
        this.registerEventHandlers();
    }
    registerEventHandlers() {
        this.events.on('queryAdded', (data) => this.emit('queryAdded', data));
        this.events.on('queryUpdated', (data) => this.emit('queryUpdated', data));
        this.events.on('error', (err) => this.emit('error', err));
        // ...add more as needed
    }
    /**
     * Add a query to history. Entry metadata may include:
     *   source: 'ui' | 'api' | 'automation'
     *   resourceUsage: { cpuPercent?: number; memoryMB?: number; durationMs?: number }
     *   artifacts: Array<{ name: string; path: string; type?: string }>
     */
    async addQuery(entry) {
        return this.logic.addQuery(entry);
    }
    async updateQuery(queryId, updates) {
        return this.logic.updateQuery(queryId, updates);
    }
    async getHistory(filter = {}) {
        return this.logic.getHistory(filter);
    }
    // Tag management
    async addTags(queryId, tags) {
        return this.logic.addTags(queryId, tags);
    }
    async removeTags(queryId, tags) {
        return this.logic.removeTags(queryId, tags);
    }
    async getAllTags() {
        return this.logic.getAllTags();
    }
    // Analytics/statistics
    async getStatistics() {
        return this.logic.getStatistics();
    }
    async emitAnalyticsUpdate() {
        return this.logic.emitAnalyticsUpdate();
    }
}
exports.QueryHistoryOrchestrator = QueryHistoryOrchestrator;
//# sourceMappingURL=QueryHistoryOrchestrator.js.map