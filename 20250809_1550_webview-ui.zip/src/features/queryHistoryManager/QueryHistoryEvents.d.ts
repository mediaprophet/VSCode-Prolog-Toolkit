import { EventEmitter } from 'events';
import { QueryHistoryLogic } from './QueryHistoryLogic';
import { QueryHistoryStorage } from './QueryHistoryStorage';
export declare class QueryHistoryEvents extends EventEmitter {
    private logic;
    private storage;
    constructor(logic: QueryHistoryLogic, storage: QueryHistoryStorage);
}
//# sourceMappingURL=QueryHistoryEvents.d.ts.map