import { QuickPickItem } from 'vscode';
import { PrologPackageManager, PrologPack } from './prologPackageManager';
export interface PackQuickPickItem extends QuickPickItem {
    pack: PrologPack;
}
export declare class PrologPackageCommands {
    private packageManager;
    constructor(packageManager: PrologPackageManager);
    /**
     * Handle package management commands from chat
     */
    handlePackageCommand(command: string, args: string[]): Promise<string>;
    private handleListCommand;
    private handleInstallCommand;
    private handleUninstallCommand;
    private handleUpdateCommand;
    private handleInfoCommand;
    private handleSearchCommand;
    private handleOutdatedCommand;
    private handleServersCommand;
    private formatOperationResult;
    private getHelpMessage;
    /**
     * Show interactive pack picker for installation
     */
    showPackPicker(): Promise<void>;
    /**
     * Show interactive pack picker for uninstallation
     */
    showUninstallPicker(): Promise<void>;
}
//# sourceMappingURL=prologPackageCommands.d.ts.map