import * as vscode from 'vscode';
import { QueryHistoryOrchestrator } from './queryHistoryManager/QueryHistoryOrchestrator';
export declare function registerQueryHistoryWebview(context: vscode.ExtensionContext, orchestrator: QueryHistoryOrchestrator): void;
//# sourceMappingURL=registerQueryHistoryWebview.d.ts.map