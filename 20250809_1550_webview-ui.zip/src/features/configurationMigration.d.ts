import * as vscode from 'vscode';
export interface MigrationResult {
    migrated: boolean;
    oldPath?: string;
    newPath?: string;
    backupCreated?: boolean;
    issues?: string[];
}
export interface ConfigurationBackup {
    timestamp: string;
    configuration: any;
    reason: string;
}
export declare class ConfigurationMigration {
    private static instance;
    private installationChecker;
    private constructor();
    static getInstance(): ConfigurationMigration;
    /**
     * Perform automatic configuration migration
     */
    performMigration(): Promise<MigrationResult>;
    /**
     * Detect and handle outdated or invalid paths
     */
    detectOutdatedPaths(): Promise<{
        hasOutdatedPaths: boolean;
        invalidPaths: string[];
        suggestions: Array<{
            path: string;
            version?: string;
        }>;
    }>;
    /**
     * Attempt to find new valid paths for invalid configurations
     */
    findNewValidPaths(): Promise<Array<{
        path: string;
        version?: string;
    }>>;
    /**
     * Create a backup of current configuration
     */
    createConfigurationBackup(reason: string): Promise<boolean>;
    /**
     * Restore configuration from backup
     */
    restoreConfigurationBackup(backupIndex?: number): Promise<boolean>;
    /**
     * Get list of available backups
     */
    getConfigurationBackups(): ConfigurationBackup[];
    /**
     * Handle migration of different SWI-Prolog versions
     */
    handleVersionMigration(oldVersion: string, newVersion: string): Promise<{
        compatibilityIssues: string[];
        recommendations: string[];
    }>;
    /**
     * Preserve user customizations during migration
     */
    preserveUserCustomizations(): Promise<{
        preserved: string[];
        issues: string[];
    }>;
    /**
     * Show migration dialog to user
     */
    showMigrationDialog(migrationResult: MigrationResult): Promise<void>;
    /**
     * Get common outdated paths that should be migrated
     */
    private getCommonOutdatedPaths;
    /**
     * Get extension context (this would need to be set by the extension)
     */
    private getExtensionContext;
    /**
     * Set extension context for storage operations
     */
    setExtensionContext(context: vscode.ExtensionContext): void;
    /**
     * Perform comprehensive migration check and handle user interaction
     */
    performComprehensiveMigration(): Promise<void>;
    /**
     * Show suggestions dialog for manual path selection
     */
    private showSuggestionsDialog;
}
//# sourceMappingURL=configurationMigration.d.ts.map