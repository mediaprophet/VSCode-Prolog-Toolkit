import * as vscode from 'vscode';
export declare class PrologDashboardProvider implements vscode.WebviewViewProvider {
    private readonly _extensionUri;
    static readonly viewType = "prologDashboard";
    private _view?;
    private installationChecker;
    private queryHistory;
    constructor(_extensionUri: vscode.Uri);
    resolveWebviewView(webviewView: vscode.WebviewView, context: vscode.WebviewViewResolveContext, _token: vscode.CancellationToken): void;
    private _executeQuery;
    private _refreshStatus;
    private _createNewFile;
    private _clearHistory;
    private _getHtmlForWebview;
}
//# sourceMappingURL=prologDashboardProvider.d.ts.map