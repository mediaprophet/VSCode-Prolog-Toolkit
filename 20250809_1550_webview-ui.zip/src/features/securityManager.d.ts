import { EventEmitter } from 'events';
export interface SecurityConfig {
    sandboxing: {
        enabled: boolean;
        isolatedProcesses: boolean;
        fileSystemRestrictions: string[];
        networkAccess: boolean;
        dangerousPredicates: string[];
    };
    resourceLimits: {
        maxInferenceSteps: number;
        maxCallDepth: number;
        maxChoicePoints: number;
        maxMemoryPerQuery: number;
        maxExecutionTime: number;
    };
    queryValidation: {
        syntaxChecking: boolean;
        predicateBlacklist: string[];
        maxQueryLength: number;
    };
}
export interface QuerySecurityContext {
    userId: string;
    role: string;
    permissions: string[];
    trusted: boolean;
    resourceQuota: ResourceQuota;
}
export interface ResourceQuota {
    maxConcurrentQueries: number;
    maxSessionsPerUser: number;
    maxQueryTime: number;
    maxMemoryPerQuery: number;
    maxResultsPerQuery: number;
    rateLimitPerMinute: number;
}
export interface SecurityViolation {
    type: 'dangerous_predicate' | 'resource_limit' | 'syntax_error' | 'permission_denied';
    message: string;
    query?: string;
    userId?: string;
    timestamp: Date;
    severity: 'low' | 'medium' | 'high' | 'critical';
}
/**
 * Security Manager for Prolog query execution
 * Handles sandboxing, resource quotas, and query validation
 */
export declare class SecurityManager extends EventEmitter {
    private config;
    private activeProcesses;
    private userResourceUsage;
    constructor(config: SecurityConfig);
    /**
     * Validate a query before execution
     */
    validateQuery(query: string, context: QuerySecurityContext): Promise<{
        valid: boolean;
        violations: SecurityViolation[];
    }>;
    /**
     * Execute query in sandbox if required
     */
    executeSecureQuery(query: string, context: QuerySecurityContext, originalExecutor: (query: string) => Promise<any>): Promise<any>;
    /**
     * Execute query in isolated sandbox process
     */
    private executeSandboxedQuery;
    /**
     * Execute query with resource limits but not in sandbox
     */
    private executeWithResourceLimits;
    /**
     * Check resource quotas for user
     */
    private checkResourceQuotas;
    /**
     * Validate Prolog syntax
     */
    private validateSyntax;
    /**
     * Get user resource usage, creating if not exists
     */
    private getUserResourceUsage;
    /**
     * Update resource usage for user
     */
    private updateResourceUsage;
    /**
     * Get allowed predicates for security context
     */
    private getAllowedPredicates;
    /**
     * Build sandbox query with security constraints
     */
    private buildSandboxQuery;
    /**
     * Parse output from sandbox execution
     */
    private parseSandboxOutput;
    /**
     * Check if parentheses are balanced
     */
    private checkBalancedParentheses;
    /**
     * Basic Prolog structure validation
     */
    private isValidPrologStructure;
    /**
     * Clean up inactive processes and old usage data
     */
    private setupCleanupInterval;
    /**
     * Get security statistics
     */
    getSecurityStatistics(): {
        activeProcesses: number;
        trackedUsers: number;
        totalViolations: number;
        resourceUsage: Map<string, any>;
    };
    /**
     * Kill all active sandbox processes
     */
    shutdown(): Promise<void>;
}
/**
 * Default security configuration
 */
export declare const defaultSecurityConfig: SecurityConfig;
/**
 * Get default resource quota for role
 */
export declare function getDefaultResourceQuota(role: string): ResourceQuota;
//# sourceMappingURL=securityManager.d.ts.map