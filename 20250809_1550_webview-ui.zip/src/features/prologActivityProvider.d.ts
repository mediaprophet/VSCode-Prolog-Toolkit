import * as vscode from 'vscode';
import { PrologError } from './errorHandler';
export interface PrologTreeItem {
    id: string;
    label: string;
    description?: string;
    tooltip?: string;
    iconPath?: vscode.ThemeIcon | {
        light: vscode.Uri;
        dark: vscode.Uri;
    };
    contextValue?: string;
    command?: vscode.Command;
    children?: PrologTreeItem[];
}
export declare class PrologActivityProvider implements vscode.TreeDataProvider<PrologTreeItem> {
    private context;
    private _onDidChangeTreeData;
    readonly onDidChangeTreeData: vscode.Event<PrologTreeItem | undefined | null | void>;
    private installationChecker;
    private queryHistory;
    private queryNotificationManager;
    private errorHandler;
    private recentErrors;
    private isInstalled;
    private currentVersion;
    /**
     * Add an error to the recent errors list
     */
    addError(error: PrologError): void;
    constructor(context: vscode.ExtensionContext);
    private checkInstallation;
    refresh(): void;
    getTreeItem(element: PrologTreeItem): vscode.TreeItem;
    getChildren(element?: PrologTreeItem): Promise<PrologTreeItem[]>;
    private getRootItems;
    private getInstallationItems;
    private getQueryItems;
    private getFileItems;
    private getDebuggingItems;
    private getSettingsItems;
    private getNotificationsAndErrorsItems;
}
//# sourceMappingURL=prologActivityProvider.d.ts.map