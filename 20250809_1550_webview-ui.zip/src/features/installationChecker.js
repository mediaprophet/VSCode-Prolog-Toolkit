"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.InstallationChecker = void 0;
const os = __importStar(require("os"));
const path = __importStar(require("path"));
const vscode = __importStar(require("vscode"));
const executableFinder_js_1 = require("../utils/executableFinder.js");
const platformUtils_js_1 = require("../utils/platformUtils.js");
class InstallationChecker {
    /**
     * Return a list of common SWI-Prolog installation paths for the current OS.
     * This is used for migration and validation of outdated configurations.
     */
    static detectCommonInstallPaths() {
        const platform = os.platform();
        if (platform === 'win32') {
            return [
                'C:/Program Files/SWI-Prolog/bin/swipl.exe',
                'C:/Program Files (x86)/SWI-Prolog/bin/swipl.exe',
                'C:/SWI-Prolog/bin/swipl.exe',
                'C:/ProgramData/chocolatey/bin/swipl.exe',
                'C:/tools/swi-prolog/bin/swipl.exe',
                'C:/scoop/apps/swi-prolog/current/bin/swipl.exe',
            ];
        }
        else if (platform === 'darwin') {
            return [
                '/usr/local/bin/swipl',
                '/opt/homebrew/bin/swipl',
                '/opt/local/bin/swipl',
                '/Applications/SWI-Prolog.app/Contents/MacOS/swipl',
            ];
        }
        else if (platform === 'linux') {
            return [
                '/usr/bin/swipl',
                '/usr/local/bin/swipl',
                '/snap/bin/swipl',
                '/opt/swi-prolog/bin/swipl',
            ];
        }
        return [];
    }
    static instance;
    executableFinder;
    static getInstance() {
        if (!InstallationChecker.instance) {
            InstallationChecker.instance = new InstallationChecker();
        }
        return InstallationChecker.instance;
    }
    constructor() {
        this.executableFinder = new executableFinder_js_1.ExecutableFinder();
    }
    /**
     * Check SWI-Prolog installation status.
     * This is the primary method for verifying the SWI-Prolog installation.
     */
    async checkSwiplInstallation() {
        const config = vscode.workspace.getConfiguration('prolog');
        const configuredPath = config.get('executablePath', platformUtils_js_1.PlatformUtils.getDefaultExecutablePath());
        const platformInfo = platformUtils_js_1.PlatformUtils.getPlatformInfo();
        // Helper to build the InstallationStatus object
        const buildStatus = (result, isInstalled, detectionMethod) => {
            const status = {
                isInstalled,
                platformInfo: {
                    platform: platformInfo.platform,
                    architecture: platformInfo.architecture,
                    osVersion: platformInfo.osVersion,
                },
                issues: result.issues || [],
            };
            if (result.path) {
                status.path = result.path;
            }
            if (result.version) {
                status.version = result.version;
            }
            if (result.permissions) {
                status.permissions = result.permissions;
            }
            const finalDetectionMethod = result.detectionMethod || detectionMethod;
            if (finalDetectionMethod) {
                status.detectionMethod = finalDetectionMethod;
            }
            return status;
        };
        // 1. Validate the user-configured path first
        if (configuredPath && configuredPath !== platformUtils_js_1.PlatformUtils.getDefaultExecutablePath()) {
            const configuredResult = await this.executableFinder.validateExecutable(configuredPath);
            if (configuredResult.found) {
                return buildStatus(configuredResult, true, 'User Configuration');
            }
        }
        // 2. Try automatic detection if user path is invalid or default
        const detectionResult = await this.executableFinder.findSwiplExecutable();
        if (detectionResult.found) {
            const status = buildStatus(detectionResult, true);
            if (configuredPath && configuredPath !== detectionResult.path) {
                status.issues?.unshift(`Configured path '${configuredPath}' is invalid, but found SWI-Prolog at '${detectionResult.path}'`);
            }
            return status;
        }
        // 3. Not found, return detailed failure information
        const installationSuggestions = await this.executableFinder.getInstallationSuggestions();
        const finalIssues = [
            'SWI-Prolog executable not found.',
            `Configured path '${configuredPath}' is not valid.`,
            ...installationSuggestions,
        ];
        if (detectionResult.issues) {
            finalIssues.push(...detectionResult.issues);
        }
        return {
            isInstalled: false,
            platformInfo: {
                platform: platformInfo.platform,
                architecture: platformInfo.architecture,
                osVersion: platformInfo.osVersion,
            },
            issues: finalIssues,
        };
    }
    /**
     * Find SWI-Prolog executable using the ExecutableFinder.
     */
    async findSwiplExecutable() {
        const result = await this.executableFinder.findSwiplExecutable();
        return result.path || null;
    }
    /**
     * Validate that a given path points to a valid SWI-Prolog executable.
     * Delegates to ExecutableFinder.
     */
    async validateSwiplPath(execPath) {
        const result = await this.executableFinder.validateExecutable(execPath);
        return result.found;
    }
    /**
     * Get detailed validation information for an executable path.
     * Delegates to ExecutableFinder.
     */
    async validateSwiplPathDetailed(execPath) {
        return this.executableFinder.validateExecutable(execPath);
    }
    /**
     * Get SWI-Prolog version from executable.
     * This is a convenience method that delegates to ExecutableFinder.
     */
    async getSwiplVersion(execPath) {
        const result = await this.executableFinder.validateExecutable(execPath);
        return result.version || null;
    }
    /**
     * Check if the current configuration is valid and update if needed
     */
    async validateAndUpdateConfiguration() {
        const config = vscode.workspace.getConfiguration('prolog');
        const currentPath = config.get('executablePath', 'swipl');
        // If current path is valid, no update needed
        if (await this.validateSwiplPath(currentPath)) {
            return { updated: false };
        }
        // Try to find a valid path
        const foundPath = await this.findSwiplExecutable();
        if (foundPath) {
            try {
                await config.update('executablePath', foundPath, vscode.ConfigurationTarget.Global);
                return {
                    updated: true,
                    oldPath: currentPath,
                    newPath: foundPath,
                };
            }
            catch (error) {
                console.error('Failed to update configuration:', error);
                return { updated: false };
            }
        }
        return { updated: false };
    }
    /**
     * Get detailed system information for troubleshooting
     */
    getSystemInfo() {
        return {
            platform: os.platform(),
            arch: os.arch(),
            pathEnv: (process.env.PATH || '').split(path.delimiter).filter(p => p.length > 0),
        };
    }
    /**
     * Check if SWI-Prolog version meets minimum requirements.
     * This logic is now more robust and handles different version formats.
     */
    checkVersionCompatibility(version) {
        if (!version || version === 'Unknown') {
            return {
                compatible: false,
                message: 'Unable to determine SWI-Prolog version.',
            };
        }
        const minVersion = '8.0.0';
        const parse = (v) => {
            const parts = v.split('.').map(part => parseInt(part, 10));
            return parts.some(isNaN) ? [] : parts;
        };
        const minParts = parse(minVersion);
        const versionParts = parse(version);
        if (versionParts.length === 0 || minParts.length < 3) {
            return { compatible: false, message: `Invalid version format: ${version}` };
        }
        const major = versionParts[0];
        const minor = versionParts[1] ?? 0;
        const patch = versionParts[2] ?? 0;
        const minMajor = minParts[0];
        const minMinor = minParts[1];
        const minPatch = minParts[2];
        if (typeof major !== 'number' || typeof minMajor !== 'number' || typeof minMinor !== 'number' || typeof minPatch !== 'number') {
            return { compatible: false, message: `Invalid version format: ${version}` };
        }
        if (major > minMajor)
            return { compatible: true };
        if (major === minMajor && minor > minMinor)
            return { compatible: true };
        if (major === minMajor && minor === minMinor && patch >= minPatch) {
            return { compatible: true };
        }
        return {
            compatible: false,
            message: `SWI-Prolog version ${version} is below the minimum required version ${minVersion}.`,
        };
    }
    /**
     * Perform comprehensive installation diagnostics.
     * This is the main entry point for gathering detailed troubleshooting information.
     */
    async performDiagnostics() {
        const installation = await this.checkSwiplInstallation();
        const system = this.getSystemInfo();
        const platformInfo = platformUtils_js_1.PlatformUtils.getPlatformInfo();
        const config = vscode.workspace.getConfiguration('prolog');
        const currentPath = config.get('executablePath', platformUtils_js_1.PlatformUtils.getDefaultExecutablePath());
        const detailedValidation = await this.validateSwiplPathDetailed(currentPath);
        const recommendations = [];
        const permissionIssues = [];
        // Helper to add platform-specific troubleshooting tips
        const addTroubleshootingTips = () => {
            switch (platformInfo.platform) {
                case 'windows':
                    recommendations.push('Windows Troubleshooting: Check if Antivirus/Firewall is blocking the executable.');
                    break;
                case 'macos':
                    recommendations.push('macOS Troubleshooting: Check Gatekeeper settings in System Preferences > Security & Privacy.');
                    break;
                case 'linux':
                    recommendations.push('Linux Troubleshooting: Ensure all required libraries are installed (use `ldd` on the executable).');
                    break;
            }
        };
        if (installation.isInstalled) {
            // Check version compatibility
            if (installation.version) {
                const compatibility = this.checkVersionCompatibility(installation.version);
                if (!compatibility.compatible) {
                    recommendations.push(`Update SWI-Prolog: ${compatibility.message}`);
                }
            }
            // Check permissions
            if (installation.permissions) {
                if (!installation.permissions.executable) {
                    const message = `Executable file lacks execute permissions: ${installation.path}`;
                    permissionIssues.push(message);
                    if (platformUtils_js_1.PlatformUtils.getPlatform() !== 'windows') {
                        recommendations.push(`To fix, run: chmod +x "${installation.path}"`);
                    }
                }
                if (!installation.permissions.readable) {
                    permissionIssues.push(`Cannot read executable file: ${installation.path}`);
                }
            }
            // Check if configuration is pointing to the found installation
            if (!detailedValidation.found && installation.path) {
                recommendations.push(`Configuration mismatch. Update 'prolog.executablePath' to the found path: ${installation.path}`);
            }
        }
        else {
            // Not installed: provide installation and troubleshooting guidance
            recommendations.push(...(installation.issues || []));
            // Attempt to add package manager suggestions
            try {
                const { PackageManagerIntegration } = await Promise.resolve().then(() => __importStar(require('./packageManagerIntegration.js')));
                const packageManager = PackageManagerIntegration.getInstance();
                if ((await packageManager.detectAvailableManagers()).length > 0) {
                    recommendations.push('Quick Install: Use the "Prolog: Install SWI-Prolog" command.');
                }
            }
            catch (error) {
                console.warn('Package manager integration check failed:', error);
            }
            addTroubleshootingTips();
        }
        return {
            installation,
            system: { ...system, platformInfo },
            configuration: {
                current: currentPath,
                valid: detailedValidation.found,
                detailedValidation,
            },
            recommendations,
            ...(permissionIssues.length > 0 && { permissionIssues }),
        };
    }
}
exports.InstallationChecker = InstallationChecker;
//# sourceMappingURL=installationChecker.js.map