import { EventEmitter } from 'events';
import { CancellationToken } from 'vscode';
export interface StreamingOptions {
    chunkSize?: number;
    maxTotalResults?: number;
    progressTitle?: string;
    showProgress?: boolean;
    bufferTimeout?: number;
}
export interface StreamChunk<T> {
    data: T[];
    index: number;
    isFirst: boolean;
    isLast: boolean;
    totalCount?: number;
    hasMore: boolean;
}
export declare class StreamingHandler<T> extends EventEmitter {
    private options;
    private buffer;
    private totalProcessed;
    private isStreaming;
    private bufferTimer?;
    constructor(options?: StreamingOptions);
    /**
     * Start streaming data processing
     */
    startStreaming(dataSource: AsyncIterable<T> | T[], processor: (chunk: StreamChunk<T>) => Promise<void> | void, cancellationToken?: CancellationToken): Promise<void>;
    /**
     * Stream with progress indication
     */
    private streamWithProgress;
    /**
     * Stream without progress indication
     */
    private streamWithoutProgress;
    /**
     * Process the stream data
     */
    private processStream;
    /**
     * Flush the current buffer
     */
    private flushBuffer;
    /**
     * Reset buffer timeout
     */
    private resetBufferTimer;
    /**
     * Clear buffer and timer
     */
    private clearBuffer;
    /**
     * Split array into chunks
     */
    private chunkArray;
    /**
     * Stop streaming (if in progress)
     */
    stop(): void;
    /**
     * Check if currently streaming
     */
    get streaming(): boolean;
    /**
     * Get total processed count
     */
    get processed(): number;
    /**
     * Update streaming options
     */
    updateOptions(newOptions: Partial<StreamingOptions>): void;
}
/**
 * Utility function to create a streaming handler for Prolog results
 */
export declare function createPrologResultStreamer(options?: StreamingOptions): StreamingHandler<unknown>;
/**
 * Utility function to create a streaming handler for large file processing
 */
export declare function createFileStreamer(options?: StreamingOptions): StreamingHandler<string>;
/**
 * Stream processor for paginated results
 */
export declare class PaginatedStreamer<T> {
    private currentPage;
    private pageSize;
    private totalPages?;
    constructor(pageSize?: number);
    /**
     * Process paginated data
     */
    processPaginated(fetcher: (page: number, pageSize: number) => Promise<{
        data: T[];
        totalCount?: number;
        hasMore: boolean;
    }>, processor: (chunk: StreamChunk<T>) => Promise<void> | void, cancellationToken?: CancellationToken): Promise<void>;
    /**
     * Get current page number
     */
    getCurrentPage(): number;
    /**
     * Get total pages (if known)
     */
    getTotalPages(): number | undefined;
    /**
     * Reset pagination state
     */
    reset(): void;
}
/**
 * Utility for streaming large query results
 */
export declare function streamQueryResults(results: unknown[], formatter: (chunk: unknown[], chunkInfo: StreamChunk<unknown>) => string, options?: StreamingOptions): Promise<string[]>;
/**
 * Create a streaming handler optimized for chat responses
 */
export declare function createChatStreamer(options?: StreamingOptions): StreamingHandler<unknown>;
/**
 * Stream large results to chat with progress updates
 */
export declare function streamToChatResponse(results: unknown[], chatStream: unknown, // ChatResponseStream type
formatter: (chunk: unknown[], isFirst: boolean, isLast: boolean, totalCount?: number) => void, options?: StreamingOptions): Promise<void>;
//# sourceMappingURL=streamingHandler.d.ts.map