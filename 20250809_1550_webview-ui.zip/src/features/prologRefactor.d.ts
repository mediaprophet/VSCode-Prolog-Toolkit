import { Location, TextDocument } from 'vscode';
import { IPredicate } from '../utils/utils';
export declare class PrologRefactor {
    private _executable;
    private _locations;
    private _clauseRefs;
    private _outputChannel;
    private _isBuiltin;
    private _defLocFound;
    constructor();
    refactorPredUnderCursor(): void;
    private applyRefactoring;
    findAllRefs(): Promise<Location[]>;
    findFilesAndRefs(pred: IPredicate, includingDefLoc: boolean, doc: TextDocument): Promise<Location[]>;
    findFilesAndRefs1(pred: IPredicate, includingDefLoc: boolean, doc: TextDocument): Promise<Location[]>;
    private loadFileAndFindRefs;
    private findRefsFromOutputSwi;
    private findRefsFromOutputEcl;
}
//# sourceMappingURL=prologRefactor.d.ts.map