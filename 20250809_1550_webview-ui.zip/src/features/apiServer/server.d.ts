import { Express } from 'express';
import { ApiServerOptions } from './config';
export declare class ApiServer {
    private app;
    private server;
    private config;
    private prologBackend;
    private isRunning;
    constructor(options: ApiServerOptions);
    start(): Promise<void>;
    stop(): Promise<void>;
    getStatus(): {
        running: boolean;
        port: number;
        host: string;
        connections: any;
    };
    getApp(): Express;
}
//# sourceMappingURL=server.d.ts.map