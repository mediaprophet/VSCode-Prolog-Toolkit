import { Express } from 'express';
export declare function setupApiRoutes(app: Express, prologBackend: any): void;
//# sourceMappingURL=routes.d.ts.map