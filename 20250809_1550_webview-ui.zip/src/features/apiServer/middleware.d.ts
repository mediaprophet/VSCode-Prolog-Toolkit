import { Express } from 'express';
export declare function setupApiMiddleware(app: Express, config: any): void;
//# sourceMappingURL=middleware.d.ts.map