"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.setupApiRoutes = setupApiRoutes;
const apiRoutes_1 = require("../apiRoutes");
function setupApiRoutes(app, prologBackend) {
    app.get('/health', (req, res) => {
        res.json({
            status: 'healthy',
            timestamp: new Date().toISOString(),
            version: '1.0.0',
            backend: {
                running: prologBackend.isRunning(),
                port: prologBackend['port'] || 3060,
            },
        });
    });
    app.get('/api', (req, res) => {
        res.json({
            name: 'VSCode Prolog Toolkit API',
            version: '1.0.0',
            description: 'RESTful API for Prolog operations and AI agent integration',
            documentation: '/api/docs',
            endpoints: {
                query: 'POST /api/v1/query',
                batch: 'POST /api/v1/batch',
                sessions: 'GET|POST /api/v1/sessions',
                reasoning: {
                    clp: 'POST /api/v1/reasoning/clp',
                    probabilistic: 'POST /api/v1/reasoning/probabilistic',
                    n3: 'POST /api/v1/reasoning/n3',
                },
                history: 'GET /api/v1/history',
                status: 'GET /api/v1/status',
            },
        });
    });
    app.use('/api/v1', (0, apiRoutes_1.apiRoutes)(prologBackend));
}
//# sourceMappingURL=routes.js.map