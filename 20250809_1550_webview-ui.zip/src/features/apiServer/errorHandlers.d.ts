import { Express } from 'express';
export declare function setupApiErrorHandlers(app: Express): void;
//# sourceMappingURL=errorHandlers.d.ts.map