"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApiServer = void 0;
// Main ApiServer class orchestrating modular components
const express_1 = __importDefault(require("express"));
const errorHandlers_1 = require("./errorHandlers");
const middleware_1 = require("./middleware");
const routes_1 = require("./routes");
class ApiServer {
    app;
    server = null;
    config;
    prologBackend;
    isRunning = false;
    constructor(options) {
        this.config = options.config;
        this.prologBackend = options.prologBackend;
        this.app = (0, express_1.default)();
        (0, middleware_1.setupApiMiddleware)(this.app, this.config);
        (0, routes_1.setupApiRoutes)(this.app, this.prologBackend);
        (0, errorHandlers_1.setupApiErrorHandlers)(this.app);
    }
    async start() {
        if (this.isRunning)
            throw new Error('API server is already running');
        if (!this.config.enabled) {
            console.log('[ApiServer] API server is disabled in configuration');
            return;
        }
        return new Promise((resolve, reject) => {
            try {
                this.server = this.app.listen(this.config.port, this.config.host, () => {
                    this.isRunning = true;
                    console.log(`[ApiServer] HTTP API server started on ${this.config.host}:${this.config.port}`);
                    console.log(`[ApiServer] Health check: http://${this.config.host}:${this.config.port}/health`);
                    console.log(`[ApiServer] API documentation: http://${this.config.host}:${this.config.port}/api`);
                    resolve();
                });
                this.server.on('error', (error) => {
                    console.error('[ApiServer] Server error:', error);
                    reject(error);
                });
                this.server.maxConnections = this.config.maxConnections;
            }
            catch (error) {
                reject(error);
            }
        });
    }
    async stop() {
        if (!this.isRunning || !this.server)
            return;
        return new Promise((resolve, reject) => {
            this.server.close(error => {
                if (error) {
                    console.error('[ApiServer] Error stopping server:', error);
                    reject(error);
                }
                else {
                    this.isRunning = false;
                    this.server = null;
                    console.log('[ApiServer] HTTP API server stopped');
                    resolve();
                }
            });
        });
    }
    getStatus() {
        return {
            running: this.isRunning,
            port: this.config.port,
            host: this.config.host,
            connections: this.server?.connections || 0,
        };
    }
    getApp() {
        return this.app;
    }
}
exports.ApiServer = ApiServer;
//# sourceMappingURL=server.js.map