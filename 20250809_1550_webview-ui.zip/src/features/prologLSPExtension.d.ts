import { ExtensionContext } from 'vscode';
import { PrologBackend } from '../prologBackend';
/**
 * LSP Extension for Prolog that provides custom requests for queries, help, and N3 diagnostics
 * This works alongside existing language providers to enhance the development experience
 */
export declare class PrologLSPExtension {
    private backend;
    private diagnosticCollection;
    private context;
    constructor(context: ExtensionContext, backend: PrologBackend | null);
    /**
     * Register all LSP extension features
     */
    registerFeatures(): void;
    /**
     * Register custom LSP-style commands
     */
    private registerCustomCommands;
    /**
     * Register enhanced code action provider
     */
    private registerCodeActionProvider;
    /**
     * Register enhanced completion provider with backend integration
     */
    private registerEnhancedCompletionProvider;
    /**
     * Register N3 diagnostics provider
     */
    private registerN3DiagnosticsProvider;
    /**
     * Run N3 diagnostics on a document
     */
    private runN3Diagnostics;
    /**
     * Check for common N3 issues
     */
    private checkN3CommonIssues;
    /**
     * Show query results in a user-friendly way
     */
    private showQueryResults;
    /**
     * Show help documentation
     */
    private showHelpDocumentation;
    /**
     * Check if document contains N3 content
     */
    private isN3Content;
    /**
     * Get built-in predicates (would need backend support)
     */
    private getBuiltinPredicates;
    /**
     * Get N3-specific completions
     */
    private getN3Completions;
    /**
     * Dispose of resources
     */
    dispose(): void;
}
//# sourceMappingURL=prologLSPExtension.d.ts.map