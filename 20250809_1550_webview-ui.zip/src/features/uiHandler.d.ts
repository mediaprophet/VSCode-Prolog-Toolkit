export interface UIHandler {
    showErrorMessage(message: string, ...items: string[]): Promise<string | undefined>;
    executeCommand(command: string, ...rest: any[]): Promise<any>;
}
export declare const defaultUIHandler: UIHandler;
//# sourceMappingURL=uiHandler.d.ts.map