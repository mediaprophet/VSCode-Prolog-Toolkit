import { SessionManagerOptions } from '../sessionManager';
import { SessionStorage } from './SessionStorage';
import type { ConcurrencyManagerOrchestrator } from '../concurrencyManager/ConcurrencyManagerOrchestrator';
import { ResourceQuota } from '../concurrencyManager/ConcurrencyResource';
import type { QueryHistoryOrchestrator } from '../queryHistoryManager/QueryHistoryOrchestrator';
import { SessionConfig, SessionSnapshot, SessionState } from '../sessionManager';
import { EventEmitter } from 'events';
export interface SessionLogicEvents {
    sessionCreated: {
        sessionId: string;
        config: SessionConfig;
    };
    sessionDeleted: {
        sessionId: string;
        config: SessionConfig;
    };
    sessionSwitched: {
        previousSessionId: string | null;
        currentSessionId: string;
        sessionConfig: SessionConfig;
    };
    snapshotCreated: {
        snapshotId: string;
        snapshot: SessionSnapshot;
    };
}
export declare class SessionLogic extends EventEmitter {
    private storage;
    private options;
    private concurrencyOrchestrator?;
    private historyOrchestrator?;
    private sessions;
    private sessionStates;
    private activeSession;
    private isInitialized;
    private sessionConcurrencyManagers;
    private sessionHistoryManagers;
    constructor(storage: SessionStorage, options?: Partial<SessionManagerOptions>, concurrencyOrchestrator?: ConcurrencyManagerOrchestrator, historyOrchestrator?: QueryHistoryOrchestrator);
    createSession(name: string, options?: {
        description?: string;
        userId?: string;
        agentId?: string;
        resourceQuota?: Partial<ResourceQuota>;
        persistenceEnabled?: boolean;
        autoSave?: boolean;
        metadata?: Record<string, unknown>;
    }): Promise<string>;
    switchToSession(sessionId: string): Promise<void>;
    deleteSession(sessionId: string): Promise<boolean>;
    listSessions(filter?: {
        userId?: string;
        agentId?: string;
        isActive?: boolean;
        includeInactive?: boolean;
    }): Array<{
        sessionId: string;
        config: SessionConfig;
    }>;
    createSnapshot(sessionId: string, name: string, description?: string): Promise<string>;
    loadSnapshot(snapshotId: string): Promise<SessionSnapshot | null>;
    getCurrentSession(): {
        sessionId: string;
        config: SessionConfig;
        state: SessionState;
    } | null;
}
//# sourceMappingURL=SessionLogic.d.ts.map