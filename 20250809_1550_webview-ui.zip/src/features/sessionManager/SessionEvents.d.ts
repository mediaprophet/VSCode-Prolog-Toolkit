import { EventEmitter } from 'events';
import { SessionLogic } from './SessionLogic';
import { SessionStorage } from './SessionStorage';
export declare class SessionEvents extends EventEmitter {
    private logic;
    private storage;
    constructor(logic: SessionLogic, storage: SessionStorage);
}
//# sourceMappingURL=SessionEvents.d.ts.map