"use strict";
// Orchestrator for Session Management
// Composes storage, event, and logic modules for robust, testable session management
Object.defineProperty(exports, "__esModule", { value: true });
exports.SessionManagerOrchestrator = void 0;
const events_1 = require("events");
const SessionEvents_1 = require("./SessionEvents");
const SessionLogic_1 = require("./SessionLogic");
const SessionStorage_1 = require("./SessionStorage");
class SessionManagerOrchestrator extends events_1.EventEmitter {
    storage;
    logic;
    events;
    constructor(options = {}) {
        super();
        this.storage = new SessionStorage_1.SessionStorage(options);
        this.logic = new SessionLogic_1.SessionLogic(this.storage, options);
        this.events = new SessionEvents_1.SessionEvents(this.logic, this.storage);
        this.registerEventHandlers();
    }
    registerEventHandlers() {
        this.events.on('sessionCreated', (data) => this.emit('sessionCreated', data));
        this.events.on('sessionDeleted', (data) => this.emit('sessionDeleted', data));
        this.events.on('error', (err) => this.emit('error', err));
        // ...add more as needed
    }
    // Expose orchestrated API
    async createSession(name, options) {
        return this.logic.createSession(name, options);
    }
    async switchToSession(sessionId) {
        return this.logic.switchToSession(sessionId);
    }
    getCurrentSession() {
        return this.logic.getCurrentSession();
    }
}
exports.SessionManagerOrchestrator = SessionManagerOrchestrator;
//# sourceMappingURL=SessionManagerOrchestrator.js.map