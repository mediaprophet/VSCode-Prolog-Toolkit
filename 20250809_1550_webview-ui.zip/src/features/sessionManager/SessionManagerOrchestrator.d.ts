import { EventEmitter } from 'events';
import { SessionManagerOptions } from '../sessionManager';
export declare class SessionManagerOrchestrator extends EventEmitter {
    private storage;
    private logic;
    private events;
    constructor(options?: Partial<SessionManagerOptions>);
    private registerEventHandlers;
    createSession(name: string, options?: any): Promise<string>;
    switchToSession(sessionId: string): Promise<void>;
    getCurrentSession(): {
        sessionId: string;
        config: import("../sessionManager").SessionConfig;
        state: import("../sessionManager").SessionState;
    };
}
//# sourceMappingURL=SessionManagerOrchestrator.d.ts.map