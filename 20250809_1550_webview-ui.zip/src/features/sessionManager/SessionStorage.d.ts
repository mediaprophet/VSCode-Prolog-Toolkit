import { SessionManagerOptions } from '../sessionManager';
import { SessionConfig, SessionSnapshot, SessionState } from '../sessionManager';
export declare class SessionStorage {
    private options;
    private storageDir;
    private sessionsFile;
    private statesDir;
    private snapshotsDir;
    constructor(options?: Partial<SessionManagerOptions>);
    ensureDirs(): Promise<void>;
    loadSessions(): Promise<Record<string, SessionConfig>>;
    saveSessions(sessions: Record<string, SessionConfig>): Promise<void>;
    loadState(sessionId: string): Promise<SessionState | null>;
    saveState(sessionId: string, state: SessionState): Promise<void>;
    deleteSession(sessionId: string): Promise<void>;
    saveSnapshot(snapshotId: string, snapshot: SessionSnapshot): Promise<void>;
    loadSnapshot(snapshotId: string): Promise<SessionSnapshot | null>;
}
//# sourceMappingURL=SessionStorage.d.ts.map