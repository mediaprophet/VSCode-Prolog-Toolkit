"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SessionEvents = void 0;
// Handles all event emission and subscription for session management
const events_1 = require("events");
class SessionEvents extends events_1.EventEmitter {
    logic;
    storage;
    constructor(logic, storage) {
        super();
        this.logic = logic;
        this.storage = storage;
        // Register for logic/storage events and re-emit as needed
    }
}
exports.SessionEvents = SessionEvents;
//# sourceMappingURL=SessionEvents.js.map