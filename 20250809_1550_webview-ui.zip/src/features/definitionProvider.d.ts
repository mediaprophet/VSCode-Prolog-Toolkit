import { CancellationToken, DefinitionProvider, Location, Position, TextDocument } from 'vscode';
export declare class PrologDefinitionProvider implements DefinitionProvider {
    provideDefinition(doc: TextDocument, position: Position, _token: CancellationToken): Location | undefined | Promise<Location | undefined>;
}
//# sourceMappingURL=definitionProvider.d.ts.map