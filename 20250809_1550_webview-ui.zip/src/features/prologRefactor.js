"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrologRefactor = void 0;
const fast_glob_1 = __importDefault(require("fast-glob"));
const fs = __importStar(require("fs"));
const jsesc_1 = __importDefault(require("jsesc"));
const process_promises_1 = require("process-promises");
const vscode_1 = require("vscode");
const utils_1 = require("../utils/utils");
// import { resolve } from 'path';
const path = __importStar(require("path"));
class PrologRefactor {
    _executable;
    _locations = [];
    _clauseRefs = {};
    _outputChannel;
    _isBuiltin = false;
    _defLocFound = false;
    // pick predicate at pos in doc
    constructor() {
        this._executable = utils_1.PrologExecUtils.RUNTIMEPATH || '';
        this._outputChannel = vscode_1.window.createOutputChannel('PrologFormatter');
        this._locations = [];
        this._clauseRefs = {};
    }
    // Initiates the refactoring process for the predicate currently under the cursor
    refactorPredUnderCursor() {
        // Get the current document and cursor position
        if (!vscode_1.window.activeTextEditor) {
            return;
        }
        const doc = vscode_1.window.activeTextEditor.document;
        const pos = vscode_1.window.activeTextEditor.selection.active;
        const pred = utils_1.SnippetUtils.getPredicateUnderCursor(doc, pos); // Get the predicate information under the cursor using utility function
        if (!pred) {
            return;
        }
        // Find all references to the predicate
        this.findFilesAndRefs(pred, true, doc).then(refLocs => {
            // Check if the predicate is a built-in predicate
            if (this._isBuiltin) {
                // If built-in, ask for confirmation before refactoring references
                vscode_1.window
                    .showInformationMessage(`'${pred.pi}' is a builtin predicate, so its definition cannot be refactored. Are you still SURE to refactor its all references?`, 'yes', 'no')
                    .then(answer => {
                    // If the user confirms, apply the refactoring
                    if (answer !== 'yes') {
                        return;
                    }
                    this.applyRefactoring(pred, refLocs);
                });
            }
            else {
                // If not built-in, ask for confirmation to refactor both definition and references
                vscode_1.window
                    .showInformationMessage(`'Are you SURE to refactor '${pred.pi}' in all its references and definition? You'd better to commit current stage of the VCS to rollback refactoring if necessary.`, 'yes', 'no')
                    .then(answer => {
                    // If the user confirms, apply the refactoring
                    if (answer !== 'yes') {
                        return;
                    }
                    this.applyRefactoring(pred, refLocs);
                });
            }
        });
    }
    // Applies the refactoring by replacing all occurrences of the predicate with a new name in the given reference locations
    async applyRefactoring(pred, refLocs) {
        // Prompt the user to input a new predicate name
        const newPredName = await vscode_1.window.showInputBox({
            prompt: `Input new predicate name to replace ${pred.functor}`,
            placeHolder: pred.functor,
            ignoreFocusOut: true,
            validateInput: value => {
                // Validate the input for the new predicate name
                if (/\s/.test(value) && !/^'[^']+'$/.test(value)) {
                    return 'Predicate name must not contain any spaces, tab and new line.';
                }
                if (/^[^a-z']/.test(value) || (/^'[^a-z]/.test(value) && !/'$/.test(value))) {
                    return 'Illegal starting letter in predicate name.';
                }
                return null; // Input is valid
            },
        });
        // Replace occurrences of the old predicate with the new name in each reference location
        await Promise.all(refLocs.map(async (refLoc) => {
            if (newPredName) {
                const edit = new vscode_1.WorkspaceEdit();
                edit.replace(refLoc.uri, refLoc.range, newPredName);
                return await Promise.resolve(vscode_1.workspace.applyEdit(edit));
            }
            return Promise.resolve(true);
        }));
        // Save all open documents after refactoring
        await Promise.all(vscode_1.workspace.textDocuments.map(async (doc) => {
            return await doc.save();
        }));
        return;
    }
    // Finds all references to the predicate currently under the cursor
    findAllRefs() {
        // Get the current document and cursor position
        if (!vscode_1.window.activeTextEditor) {
            return Promise.resolve([]);
        }
        const doc = vscode_1.window.activeTextEditor.document;
        const pos = vscode_1.window.activeTextEditor.selection.active;
        const pred = utils_1.SnippetUtils.getPredicateUnderCursor(doc, pos); // Get the predicate information under the cursor using utility function
        if (!pred) {
            return Promise.resolve([]);
        }
        return this.findFilesAndRefs(pred, false, doc); // Call the findFilesAndRefs method to find references and return the result
    }
    // Finds references to the given predicate in multiple files
    async findFilesAndRefs(pred, includingDefLoc = false, doc) {
        // Call the findFilesAndRefs1 method to perform the actual search
        return await this.findFilesAndRefs1(pred, includingDefLoc, doc);
    }
    // Performs the search for references to the given predicate in multiple files
    async findFilesAndRefs1(pred, includingDefLoc = false, doc) {
        // Save all open documents before searching
        await Promise.all(vscode_1.workspace.textDocuments.map(async (doc) => {
            return await doc.save();
        }));
        // Use fast-glob to locate files containing references to the predicate
        if (!vscode_1.workspace.workspaceFolders || vscode_1.workspace.workspaceFolders.length === 0) {
            return this._locations;
        }
        if (!vscode_1.workspace.workspaceFolders || vscode_1.workspace.workspaceFolders.length === 0) {
            return this._locations;
        }
        const root = vscode_1.workspace.workspaceFolders[0]?.uri?.fsPath;
        if (!root) {
            return this._locations;
        }
        const patterns = ['**/*.pl', '**/*.ecl'];
        const filePaths = await (0, fast_glob_1.default)(patterns, { cwd: root, absolute: true });
        for (const file of filePaths) {
            // Read file and check if it contains the predicate functor
            const content = await fs.promises.readFile(file, 'utf8');
            if (content.includes(pred.functor)) {
                const defLoc = includingDefLoc && !this._defLocFound;
                await this.loadFileAndFindRefs(pred, file, defLoc, doc);
            }
        }
        return this._locations; // Return the array of reference locations
    }
    // Loads the Prolog file and finds references based on the Prolog dialect
    async loadFileAndFindRefs(pred, file, includingDefLoc = false, doc) {
        let input, args = [];
        // Construct the appropriate input and arguments based on the Prolog dialect
        switch (utils_1.PrologExecUtils.DIALECT) {
            case 'swi': {
                const pfile = (0, jsesc_1.default)(path.resolve(`${__dirname}/features/findallrefs_swi`));
                input = `
          use_module('${pfile}').
          load_files('${file}').
          findrefs:findrefs(${pred.pi}, ${includingDefLoc}).
          halt.
        `;
                args = ['-q'];
                break;
            }
            case 'ecl': {
                const efile = (0, jsesc_1.default)(path.resolve(`${__dirname}/features/findallrefs`));
                args = ['-f', efile];
                input = `digout_predicate('${file}', ${pred.pi}). `;
                break;
            }
            default:
                break;
        }
        try {
            // Spawn a child process to execute Prolog queries
            if (!vscode_1.workspace.workspaceFolders || vscode_1.workspace.workspaceFolders.length === 0) {
                return;
            }
            if (!vscode_1.workspace.workspaceFolders || vscode_1.workspace.workspaceFolders.length === 0) {
                return;
            }
            const cwd = vscode_1.workspace.workspaceFolders[0]?.uri?.fsPath;
            if (!cwd) {
                return;
            }
            await (0, process_promises_1.spawn)(this._executable, args, { cwd })
                .on('process', (proc) => {
                if (proc.pid) {
                    // Write the input to the stdin of the spawned process
                    proc.stdin.write(input);
                    proc.stdin.end();
                }
            })
                .on('stdout', (output) => {
                // Parse the output based on the Prolog dialect
                switch (utils_1.PrologExecUtils.DIALECT) {
                    case 'swi':
                        this.findRefsFromOutputSwi(pred, output, doc);
                        break;
                    case 'ecl':
                        this.findRefsFromOutputEcl(file, pred.pi, output);
                        break;
                    default:
                        break;
                }
            })
                .on('stderr', (err) => {
                // Handle any errors or display them in the output channel
                this._outputChannel.append(err + '\n');
                this._outputChannel.show(true);
            });
        }
        catch (error) {
            // Handle specific error cases (e.g., executable not found) and display error messages
            let message = '';
            if (error &&
                typeof error === 'object' &&
                'code' in error &&
                error.code === 'ENOENT') {
                message = `Cannot debug the prolog file. The Prolog executable was not found. Correct the 'prolog.executablePath' configure please.`;
            }
            else {
                message =
                    error &&
                        typeof error === 'object' &&
                        'message' in error &&
                        typeof error.message === 'string'
                        ? error.message
                        : `Failed to run swipl using path: ${this._executable}. Reason is unknown.`;
            }
        }
    }
    // Parses the output from SWI-Prolog and extracts reference information
    findRefsFromOutputSwi(pred, output, doc) {
        // Check if the predicate is a built-in or foreign predicate
        const docContent = doc.getText();
        if (/{"reference":"built_in or foreign"}/.test(output)) {
            this._isBuiltin = true;
        }
        // Check if a definition location is found in the output
        if (/{"reference":"definition location found"}/.test(output)) {
            this._defLocFound = true;
        }
        let pred_void = pred.functor + '(?=\\(';
        for (let i = 0; i < pred.arity; i++) {
            pred_void = pred_void + "[a-zA-Z0-9_,$&+,:;=?@#|'<>.^*()%!-:[\\]\\s]*";
            if (i < pred.arity - 1) {
                pred_void = pred_void + ',';
            }
        }
        pred_void = pred_void + '\\))|' + pred.functor + '(?=/' + pred.arity + ')';
        const regexp = new RegExp(pred_void, 'gm');
        const array = [...docContent.matchAll(regexp)]; // Extract occurrences of the predicate in the document
        let locations = array.map(elem => new vscode_1.Location(vscode_1.Uri.file(doc.fileName), new vscode_1.Range(doc.positionAt(elem.index || 0), doc.positionAt((elem.index || 0) + (elem[0]?.length || 0))))); // Create an array to store Location objects
        const regexpModule = /^\s*:-\s*use_module\(([a-zA-Z0-9_/]*|("|')[a-zA-Z0-9_/.]*("|'))\s*((,\s*[/a-zA-Z0-9[\]]*\s*\)|\))\s*\.)/gm; // Define a regular expression for finding "use_module" declarations in the document
        const arrayModule = [...docContent.matchAll(regexpModule)]; // Extract "use_module" declarations from the document
        const filenameParts = doc.fileName.split('.');
        const prolog = filenameParts.length > 1 ? filenameParts[1] : 'pl'; // Extract the Prolog dialect from the file extension
        // Iterate through "use_module" declarations
        for (let i = 0; i < arrayModule.length; i++) {
            if (!arrayModule[i]?.[1]) {
                continue;
            }
            const modpathRaw = arrayModule?.[i]?.[1] ?? '';
            if (!modpathRaw) {
                continue;
            }
            let modpath = modpathRaw.replace(new RegExp("'", 'gm'), '');
            if (!modpath) {
                continue;
            }
            modpath = modpath.replace(new RegExp('"', 'gm'), '');
            var text = '';
            try {
                if (!vscode_1.workspace.workspaceFolders || vscode_1.workspace.workspaceFolders.length === 0) {
                    continue;
                }
                if (!vscode_1.workspace.workspaceFolders || vscode_1.workspace.workspaceFolders.length === 0) {
                    continue;
                }
                text = fs.readFileSync(vscode_1.workspace.workspaceFolders[0]?.uri?.fsPath + '/' + modpath + '.' + prolog, 'utf8'); // Read the content of the referenced module file
            }
            catch (error) {
                console.error('Error reading file:', error);
            }
            const array = [...text.matchAll(regexp)]; // Extract occurrences of the predicate in the referenced module file
            if (vscode_1.workspace.workspaceFolders && vscode_1.workspace.workspaceFolders.length > 0) {
                locations = locations.concat(array.map(elem => new vscode_1.Location(vscode_1.Uri.file((vscode_1.workspace.workspaceFolders?.[0]?.uri?.fsPath || '') + '/' + modpath + '.' + prolog), new vscode_1.Range(utils_1.PositionUtils.findLineColForByte(text, elem.index), utils_1.PositionUtils.findLineColForByte(text, elem.index + elem[0].length))))); // Append the new occurrences to the locations array
            }
        }
        this._locations = locations;
        /*let refReg = /\{"reference":\s*(\{.+?\})\}/g;// Regular expression to match reference information in the output
        // Attempt to match and parse each reference in the output
        let match: RegExpExecArray = refReg.exec(output);
        while (match) {
          // Parse the reference information from the matched JSON
          let ref: { file: string; line: number; char: number } = JSON.parse(
            match[1]
          );
          // Relocate if the reference points to the start of the clause
          let lines = fs
            .readFileSync(ref.file)
            .toString()
            .split("\n");
          let predName = pi.split("/")[0];
          // Extract the predicate name in case of a module
          if (predName.indexOf(":") > -1) {
            predName = predName.split(":")[1];
          }
          // Check if the reference is not at the beginning of the clause
          if (!new RegExp("^" + predName).test(lines[ref.line].slice(ref.char))) {
            let clauseStart = ref.line;
            let start = ref.line;
            // Adjust the start based on previous clause references
            if (
              this._clauseRefs[ref.file] &&
              this._clauseRefs[ref.file][clauseStart]
            ) {
              start = this._clauseRefs[ref.file][clauseStart] + 1;
            }
            let str = lines.slice(start).join("\n");
            let index = str.indexOf(predName);
            // If the predicate name is found, adjust the reference location
            if (index > -1) {
              str = str.slice(0, index);
              let strLines = str.split("\n");
              ref.line = start + strLines.length - 1;
              ref.char = strLines[strLines.length - 1].length;
              // Update the clause references with the adjusted location
              if (this._clauseRefs[ref.file]) {
                this._clauseRefs[ref.file][clauseStart] = ref.line;
              } else {
                this._clauseRefs[ref.file] = {};
                this._clauseRefs[ref.file][clauseStart] = ref.line;
              }
            }
          }
          // Add the adjusted reference location to the _locations array
          this._locations.push(
            new Location(
              Uri.file(jsesc(path.resolve(ref.file))),
              new Range(ref.line, ref.char, ref.line, ref.char + predName.length)
            )
          );
          match = refReg.exec(output);// Attempt to find the next reference in the output
        }*/
    }
    //Parses the output from ECLiPSe Prolog and extracts reference information
    findRefsFromOutputEcl(file, pi, output) {
        const match = output.match(/references:\[(.*)\]/); // Extract references information from the output using a regular expression
        // Return if no matches are found or the references array is empty
        if (!match || match[1] === '') {
            return;
        }
        if (!match || !pi) {
            return;
        }
        const predLen = pi.split(':')[1]?.split('/')[0]?.length || 0; // Extract the length of the predicate name
        const locs = match[1]?.split(',') || []; // Split the references string into an array of location strings
        if (locs.length === 0) {
            return;
        }
        vscode_1.workspace.openTextDocument(vscode_1.Uri.file(file)).then(doc => {
            // Open the Prolog document to map character positions to positions in the file
            // Iterate through each location string and create Location objects
            locs.forEach(fromS => {
                const from = parseInt(fromS);
                this._locations.push(new vscode_1.Location(vscode_1.Uri.file(file), new vscode_1.Range(doc.positionAt(from), doc.positionAt(from + predLen))));
            });
        });
    }
}
exports.PrologRefactor = PrologRefactor;
//# sourceMappingURL=prologRefactor.js.map