"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("../utils/utils");
'use strict';
const child_process_1 = require("child_process");
const jsesc_1 = __importDefault(require("jsesc"));
const vscode_1 = require("vscode");
const executableFinder_1 = require("../utils/executableFinder");
const platformUtils_1 = require("../utils/platformUtils");
const installationGuide_1 = require("./installationGuide");
class PrologTerminal {
    static _terminal;
    static _document;
    static _platform;
    static _shellInfo = null;
    constructor() {
        // Static terminal class - no instance initialization needed
    }
    // Initialize the Prolog terminal
    static init() {
        PrologTerminal._platform = platformUtils_1.PlatformUtils.getPlatform();
        return vscode_1.window.onDidCloseTerminal((terminal) => {
            PrologTerminal._terminal = null;
            terminal.dispose();
        });
    }
    /**
     * Detect the default shell for the current platform
     */
    static async detectShell() {
        if (PrologTerminal._shellInfo) {
            return PrologTerminal._shellInfo;
        }
        let shellInfo;
        switch (PrologTerminal._platform) {
            case 'windows': {
                shellInfo = await PrologTerminal.detectWindowsShell();
                break;
            }
            case 'macos': {
                shellInfo = await PrologTerminal.detectMacOSShell();
                break;
            }
            case 'linux': {
                shellInfo = await PrologTerminal.detectLinuxShell();
                break;
            }
            default:
                // Fallback to basic shell
                shellInfo = {
                    name: 'sh',
                    path: '/bin/sh',
                    args: [],
                    supportsColors: false,
                    requiresQuoting: true,
                };
                break;
        }
        PrologTerminal._shellInfo = shellInfo;
        return shellInfo;
    }
    /**
     * Detect Windows shell (PowerShell, Command Prompt, WSL)
     */
    static async detectWindowsShell() {
        // Check for PowerShell Core first
        try {
            await PrologTerminal.testCommand('pwsh', ['--version']);
            return {
                name: 'PowerShell Core',
                path: 'pwsh',
                args: ['-NoLogo'],
                supportsColors: true,
                requiresQuoting: true,
            };
        }
        catch (_error) {
            // Ignore shell detection failure
        }
        // Check for Windows PowerShell
        try {
            await PrologTerminal.testCommand('powershell', ['-Version']);
            return {
                name: 'Windows PowerShell',
                path: 'powershell',
                args: ['-NoLogo'],
                supportsColors: true,
                requiresQuoting: true,
            };
        }
        catch (_error) {
            // Ignore shell detection failure
        }
        // Check for WSL
        try {
            await PrologTerminal.testCommand('wsl', ['--version']);
            return {
                name: 'WSL',
                path: 'wsl',
                args: [],
                supportsColors: true,
                requiresQuoting: true,
            };
        }
        catch (_error) {
            // Ignore bash detection failure
        }
        // Fallback to Command Prompt
        return {
            name: 'Command Prompt',
            path: 'cmd',
            args: ['/K'],
            supportsColors: false,
            requiresQuoting: true,
        };
    }
    /**
     * Detect macOS shell (zsh, bash)
     */
    static async detectMacOSShell() {
        // Check for zsh (default on macOS Catalina+)
        try {
            await PrologTerminal.testCommand('zsh', ['--version']);
            return {
                name: 'Zsh',
                path: '/bin/zsh',
                args: [],
                supportsColors: true,
                requiresQuoting: true,
            };
        }
        catch (_error) {
            // Ignore zsh detection failure
        }
        // Check for bash
        try {
            await PrologTerminal.testCommand('bash', ['--version']);
            return {
                name: 'Bash',
                path: '/bin/bash',
                args: [],
                supportsColors: true,
                requiresQuoting: true,
            };
        }
        catch (_error) {
            // Ignore WSL detection failure
        }
        // Fallback to sh
        return {
            name: 'Shell',
            path: '/bin/sh',
            args: [],
            supportsColors: false,
            requiresQuoting: true,
        };
    }
    /**
     * Detect Linux shell (bash, zsh, fish, etc.)
     */
    static async detectLinuxShell() {
        // Get user's default shell from environment
        const userShell = process.env.SHELL;
        if (userShell) {
            const shellName = platformUtils_1.PlatformUtils.basename(userShell);
            try {
                await PrologTerminal.testCommand(userShell, ['--version']);
                return {
                    name: shellName,
                    path: userShell,
                    args: [],
                    supportsColors: true,
                    requiresQuoting: true,
                };
            }
            catch (_error) {
                // Ignore Windows PowerShell detection failure
            }
        }
        // Check for common shells
        const shells = [
            { name: 'bash', path: '/bin/bash' },
            { name: 'zsh', path: '/bin/zsh' },
            { name: 'fish', path: '/usr/bin/fish' },
            { name: 'dash', path: '/bin/dash' },
        ];
        for (const shell of shells) {
            try {
                await PrologTerminal.testCommand(shell.path, ['--version']);
                return {
                    name: shell.name,
                    path: shell.path,
                    args: [],
                    supportsColors: shell.name !== 'dash',
                    requiresQuoting: true,
                };
            }
            catch (_error) {
                // Ignore PowerShell Core detection failure
            }
        }
        // Fallback to sh
        return {
            name: 'Shell',
            path: '/bin/sh',
            args: [],
            supportsColors: false,
            requiresQuoting: true,
        };
    }
    /**
     * Test if a command is available
     */
    static async testCommand(command, args) {
        return new Promise(resolve => {
            const process = (0, child_process_1.spawn)(command, args, {
                stdio: ['ignore', 'ignore', 'ignore'],
                timeout: 3000,
            });
            process.on('close', code => {
                resolve(code === 0);
            });
            process.on('error', () => {
                resolve(false);
            });
            setTimeout(() => {
                process.kill();
                resolve(false);
            }, 3000);
        });
    }
    /**
     * Get platform-specific terminal configuration
     */
    static async getTerminalConfig() {
        const section = vscode_1.workspace.getConfiguration('prolog');
        let executable = section.get('executablePath', platformUtils_1.PlatformUtils.getDefaultExecutablePath());
        // Enhanced executable resolution
        if (!(await platformUtils_1.PlatformUtils.pathExists(executable)) ||
            !(await platformUtils_1.PlatformUtils.isExecutable(executable))) {
            const executableFinder = new executableFinder_1.ExecutableFinder();
            const detectionResult = await executableFinder.findSwiplExecutable();
            if (detectionResult.found && detectionResult.path) {
                executable = detectionResult.path;
            }
        }
        executable = platformUtils_1.PlatformUtils.normalizePath(executable);
        // Get platform-specific runtime arguments
        const args = section.get('terminal.runtimeArgs') || platformUtils_1.PlatformUtils.getDefaultRuntimeArgs();
        // Detect shell for better integration
        const shell = await PrologTerminal.detectShell();
        // Platform-specific environment variables
        const env = {};
        switch (PrologTerminal._platform) {
            case 'windows': {
                // Windows-specific environment setup
                env.TERM = 'xterm-256color';
                break;
            }
            case 'macos': {
                // macOS-specific environment setup
                env.TERM = 'xterm-256color';
                env.LANG = process.env.LANG || 'en_US.UTF-8';
                break;
            }
            case 'linux': {
                // Linux-specific environment setup
                env.TERM = 'xterm-256color';
                env.LANG = process.env.LANG || 'en_US.UTF-8';
                break;
            }
        }
        return {
            executable,
            args,
            shell,
            env,
            cwd: vscode_1.workspace.workspaceFolders?.[0]?.uri.fsPath || process.cwd(),
        };
    }
    /**
     * Escape command arguments for the detected shell
     */
    static escapeForShell(text, shell) {
        if (!shell.requiresQuoting) {
            return text;
        }
        switch (PrologTerminal._platform) {
            case 'windows': {
                // Windows shell escaping
                if (shell.name.includes('PowerShell')) {
                    // PowerShell escaping
                    return `'${text.replace(/'/g, "''")}'`;
                }
                else {
                    // Command Prompt escaping
                    return `"${text.replace(/"/g, '""')}"`;
                }
            }
            case 'macos':
            case 'linux': {
                // Unix shell escaping
                if (text.includes(' ') || text.includes('"') || text.includes("'")) {
                    return `'${text.replace(/'/g, "'\"'\"'")}'`;
                }
                return text;
            }
            default:
                return text;
        }
    }
    // Create a Prolog terminal instance
    static async createPrologTerm() {
        if (PrologTerminal._terminal) {
            return;
        }
        try {
            const config = await PrologTerminal.getTerminalConfig();
            const title = 'Prolog';
            // Validate executable exists and has proper permissions
            if (!(await platformUtils_1.PlatformUtils.pathExists(config.executable))) {
                throw new Error(`Executable not found: ${config.executable}`);
            }
            if (!(await platformUtils_1.PlatformUtils.isExecutable(config.executable))) {
                const platform = platformUtils_1.PlatformUtils.getPlatform();
                let permissionError = `Executable lacks execute permissions: ${config.executable}`;
                if (platform !== 'windows') {
                    permissionError += `\n\nTry fixing permissions with: chmod +x "${config.executable}"`;
                }
                throw new Error(permissionError);
            }
            // Create terminal with enhanced configuration
            const terminalOptions = {
                name: title,
                shellPath: config.executable,
                shellArgs: config.args,
                cwd: config.cwd,
                env: {
                    ...process.env,
                    ...config.env,
                },
            };
            // Add platform-specific terminal options
            switch (PrologTerminal._platform) {
                case 'windows': {
                    // Windows-specific terminal options
                    terminalOptions.hideFromUser = false;
                    break;
                }
                case 'macos': {
                    // macOS-specific terminal options
                    terminalOptions.strictEnv = false;
                    break;
                }
                case 'linux': {
                    // Linux-specific terminal options
                    terminalOptions.strictEnv = false;
                    break;
                }
            }
            PrologTerminal._terminal = vscode_1.window.createTerminal(terminalOptions);
            // Send initial setup commands based on platform and shell
            setTimeout(async () => {
                await PrologTerminal.sendInitialSetupCommands(config);
            }, 1000);
        }
        catch (error) {
            await PrologTerminal.handleTerminalCreationError(error);
            throw error;
        }
    }
    /**
     * Send initial setup commands to configure the terminal environment
     */
    static async sendInitialSetupCommands(config) {
        if (!PrologTerminal._terminal)
            return;
        const shell = config.shell;
        if (!shell)
            return;
        // Platform-specific setup commands
        const setupCommands = [];
        switch (PrologTerminal._platform) {
            case 'windows': {
                if (shell.name.includes('PowerShell')) {
                    setupCommands.push('$Host.UI.RawUI.WindowTitle = "Prolog Terminal"');
                    if (shell.supportsColors) {
                        setupCommands.push('$PSStyle.OutputRendering = "Host"');
                    }
                }
                else if (shell.name === 'Command Prompt') {
                    setupCommands.push('title Prolog Terminal');
                }
                break;
            }
            case 'macos':
            case 'linux': {
                if (shell.supportsColors) {
                    setupCommands.push('export TERM=xterm-256color');
                }
                // Set terminal title
                setupCommands.push('echo -ne "\\033]0;Prolog Terminal\\007"');
                break;
            }
        }
        // Send setup commands
        for (const command of setupCommands) {
            PrologTerminal._terminal.sendText(command);
        }
    }
    /**
     * Handle terminal creation errors with enhanced error messages and recovery options
     */
    static async handleTerminalCreationError(error) {
        let errorMessage = 'Failed to create Prolog terminal';
        let isExecutableError = false;
        if (error.code === 'ENOENT' || error.message?.includes('not found')) {
            errorMessage =
                'SWI-Prolog executable not found. The terminal requires SWI-Prolog to run interactive Prolog sessions.';
            isExecutableError = true;
        }
        else if (error.message?.includes('permission')) {
            errorMessage = `Permission error: ${error.message}`;
            isExecutableError = true;
        }
        else {
            errorMessage = `Failed to create Prolog terminal: ${error.message || error}`;
        }
        if (isExecutableError) {
            const action = await vscode_1.window.showErrorMessage(errorMessage, 'Install with Package Manager', 'Installation Guide', 'Setup Wizard', 'Configure Path', 'Dismiss');
            const installationGuide = installationGuide_1.InstallationGuide.getInstance();
            switch (action) {
                case 'Install with Package Manager': {
                    const { PackageManagerIntegration } = await Promise.resolve().then(() => __importStar(require('./packageManagerIntegration')));
                    const packageManager = PackageManagerIntegration.getInstance();
                    await packageManager.showInstallationDialog();
                    break;
                }
                case 'Installation Guide': {
                    await installationGuide.showInstallationGuideDialog();
                    break;
                }
                case 'Setup Wizard': {
                    await vscode_1.commands.executeCommand('prolog.setupWizard');
                    break;
                }
                case 'Configure Path': {
                    await vscode_1.commands.executeCommand('workbench.action.openSettings', 'prolog.executablePath');
                    break;
                }
            }
        }
        else {
            vscode_1.window.showErrorMessage(errorMessage);
        }
    }
    // Send a string to the Prolog terminal
    static async sendString(text) {
        try {
            await PrologTerminal.createPrologTerm();
            // Get shell info for proper escaping
            const shell = await PrologTerminal.detectShell();
            // finish goal by .
            if (!text.endsWith('.')) {
                text += '.';
            }
            // Escape text for the detected shell if needed
            const escapedText = PrologTerminal.escapeForShell(text, shell);
            PrologTerminal._terminal.sendText(escapedText);
            PrologTerminal._terminal.show(false);
        }
        catch (error) {
            // Error already handled in createPrologTerm
            console.error('Failed to send string to Prolog terminal:', error);
        }
    }
    // load the prolog file
    static async loadDocument() {
        if (!vscode_1.window.activeTextEditor) {
            return;
        }
        try {
            PrologTerminal._document = vscode_1.window.activeTextEditor.document; // Get the active Prolog document
            await PrologTerminal.createPrologTerm(); // Create the Prolog terminal
            // Get the file name and escape it using jsesc
            const fname = (0, jsesc_1.default)(platformUtils_1.PlatformUtils.normalizePath(PrologTerminal._document.fileName), {
                quotes: 'single',
            });
            const goals = `['${fname}']`; // Define the goals to load the Prolog file
            // load the file into swipl with a goal
            if (PrologTerminal._document.isDirty) {
                PrologTerminal._document.save().then(_ => {
                    PrologTerminal.sendString(goals);
                });
            }
            else {
                await PrologTerminal.sendString(goals);
            }
        }
        catch (error) {
            // Error already handled in createPrologTerm
            console.error('Failed to load document in Prolog terminal:', error);
        }
    }
    // query the goal under the cursor command
    static queryGoalUnderCursor() {
        // Get the active text editor and document
        if (!vscode_1.window.activeTextEditor) {
            return;
        }
        const editor = vscode_1.window.activeTextEditor;
        const doc = editor.document;
        const pred = utils_1.SnippetUtils.getPredicateUnderCursor(doc, editor.selection.active); // Get the predicate under the cursor using utility function
        // if no predicate under cursor
        if (!pred) {
            return;
        }
        PrologTerminal.loadDocument(); // Load the current Prolog document into the Prolog terminal
        let goal = pred?.wholePred || ''; // Extract the goal from the predicate
        // Separate the module if present
        if (goal.indexOf(':') > -1) {
            const parts = goal.split(':');
            goal = (parts.length > 1 && typeof parts[1] === 'string') ? parts[1] : goal;
        }
        PrologTerminal.sendString(goal);
    }
}
exports.default = PrologTerminal;
//# sourceMappingURL=prologTerminal.js.map