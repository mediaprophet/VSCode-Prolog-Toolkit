"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrologReferenceProvider = void 0;
const fs = __importStar(require("fs"));
const vscode_1 = require("vscode");
const utils_1 = require("../utils/utils");
class PrologReferenceProvider {
    constructor() {
        // No initialization required for reference provider
    }
    // Implement the provideReferences method required by ReferenceProvider interface
    provideReferences(doc, position, _context, _token) {
        const docContent = doc.getText(); // Get the content of the entire document as a string
        // Define a regular expression for finding occurrences of the predicate in the document
        const pred = utils_1.SnippetUtils.getPredicateUnderCursor(doc, position);
        if (!pred) {
            return [];
        }
        const regex = '\\((.|\\s)*?\\)';
        const regexp = new RegExp(pred.functor + regex, 'gm');
        const regexpModule = /^\s*:-\s*use_module\(([a-zA-Z0-9_/]*|("|')[a-zA-Z0-9_/.]*("|'))\s*((,\s*[/a-zA-Z0-9[\]]*\s*\)|\))\s*\.)/gm; // Define a regular expression for finding "use_module" declarations in the document
        const arrayModule = [...docContent.matchAll(regexpModule)]; // Extract "use_module" declarations from the document
        const filenameParts = doc.fileName.split('.');
        const prolog = filenameParts.length > 1 ? filenameParts[1] : 'pl'; // Extract the Prolog dialect from the file extension
        const array = [...docContent.matchAll(regexp)]; // Extract occurrences of the predicate in the document
        let locations = array
            .map(elem => elem.index !== undefined
            ? new vscode_1.Location(vscode_1.Uri.file(doc.fileName), doc.positionAt(elem.index))
            : null)
            .filter(loc => loc !== null); // Create an array to store Location objects
        // Iterate through "use_module" declarations
        for (let i = 0; i < arrayModule.length; i++) {
            const modpathRaw = arrayModule?.[i]?.[1] ?? '';
            if (!modpathRaw) {
                continue;
            }
            let modpath = modpathRaw.replace(new RegExp("'", 'gm'), '');
            if (!modpath) {
                continue;
            }
            modpath = modpath.replace(new RegExp('"', 'gm'), '');
            let text = '';
            try {
                const wsRoot = vscode_1.workspace.workspaceFolders?.[0]?.uri?.fsPath;
                if (!wsRoot) {
                    continue;
                }
                text = fs.readFileSync(wsRoot + '/' + modpath + '.' + prolog, 'utf8');
            }
            catch (error) {
                console.error('Error reading file:', error);
                continue;
            }
            const array = [...text.matchAll(regexp)]; // Extract occurrences of the predicate in the referenced module file
            const wsRoot = vscode_1.workspace.workspaceFolders?.[0]?.uri?.fsPath;
            if (!wsRoot) {
                continue;
            }
            const newLocations = array
                .map(elem => elem.index !== undefined
                ? new vscode_1.Location(vscode_1.Uri.file(wsRoot + '/' + modpath + '.' + prolog), utils_1.PositionUtils.findLineColForByte(text, elem.index))
                : null)
                .filter(loc => loc !== null);
            locations = locations.concat(newLocations); // Append the new occurrences to the locations array
        }
        // Return the array of Location objects
        return locations;
    }
}
exports.PrologReferenceProvider = PrologReferenceProvider;
//# sourceMappingURL=referenceProvider.js.map