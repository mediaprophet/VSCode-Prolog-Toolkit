import { Request, Response, NextFunction } from 'express';
export interface AuthConfig {
    method: 'api_key' | 'jwt_token' | 'local_only' | 'oauth2';
    apiKeys: string[];
    jwtSecret: string;
    localOnly: boolean;
    oauth2: {
        providers: string[];
        clientId?: string;
        clientSecret?: string;
        redirectUri?: string;
        scope?: string;
    };
    roles: {
        admin: string[];
        agent: string[];
        readonly: string[];
        limited: string[];
    };
    quotas: {
        admin: {
            requestsPerMinute: number;
            maxConcurrentSessions: number;
        };
        agent: {
            requestsPerMinute: number;
            maxConcurrentSessions: number;
        };
        readonly: {
            requestsPerMinute: number;
            maxConcurrentSessions: number;
        };
        limited: {
            requestsPerMinute: number;
            maxConcurrentSessions: number;
        };
    };
}
export interface AuthenticatedUser {
    id: string;
    role: string;
    permissions: string[];
    method: string;
}
export interface AuthenticatedRequest extends Request {
    user?: AuthenticatedUser;
}
/**
 * Authentication middleware factory
 */
export declare function authMiddleware(config: AuthConfig): (req: AuthenticatedRequest, res: Response, next: NextFunction) => Promise<void | Response<any, Record<string, any>>>;
/**
 * Generate a new API key
 */
export declare function generateApiKey(): string;
/**
 * Hash an API key for secure storage
 */
export declare function hashApiKey(apiKey: string): string;
/**
 * Generate a JWT token
 */
export declare function generateJwtToken(payload: any, config: AuthConfig): string;
/**
 * Verify JWT token
 */
export declare function verifyJwtToken(token: string, config: AuthConfig): Record<string, unknown>;
/**
 * Permission checking utility
 */
export declare function hasPermission(user: AuthenticatedUser | undefined, permission: string): boolean;
/**
 * Resource quota middleware
 */
export declare function resourceQuotaMiddleware(quotas: {
    [role: string]: {
        requests_per_minute?: number;
        maxConcurrentSessions?: number;
    };
}): (req: AuthenticatedRequest, res: Response, next: NextFunction) => void;
/**
 * Audit logging middleware
 */
export declare function auditMiddleware(): (req: AuthenticatedRequest, res: Response, next: NextFunction) => void;
//# sourceMappingURL=apiMiddleware.d.ts.map