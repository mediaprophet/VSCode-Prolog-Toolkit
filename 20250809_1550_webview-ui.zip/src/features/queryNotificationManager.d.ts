import { EventEmitter } from 'events';
export interface QueryStatus {
    id: string;
    status: 'pending' | 'running' | 'completed' | 'error' | 'cancelled' | 'timeout';
    startTime: number;
    endTime?: number;
    progress?: number;
    message?: string;
    results?: any;
    error?: any;
    isBatch?: boolean;
    batchIndex?: number;
    totalBatchSize?: number;
}
export interface QueryNotificationOptions {
    enableProgress?: boolean;
    progressInterval?: number;
    enableWebSocket?: boolean;
    webSocketPort?: number;
}
export interface QueryCallback {
    onProgress?: (status: QueryStatus) => void;
    onComplete?: (status: QueryStatus) => void;
    onError?: (status: QueryStatus) => void;
    onCancel?: (status: QueryStatus) => void;
}
/**
 * Manages query status tracking and notifications for long-running Prolog queries
 */
export declare class QueryNotificationManager extends EventEmitter {
    private queries;
    private callbacks;
    private wsServer?;
    private wsClients;
    private options;
    constructor(options?: QueryNotificationOptions);
    /**
     * Initialize WebSocket server for real-time notifications
     */
    private initializeWebSocketServer;
    /**
     * Handle incoming WebSocket messages
     */
    private handleWebSocketMessage;
    /**
     * Broadcast notification to all WebSocket clients
     */
    private broadcastNotification;
    /**
     * Register a new query for tracking
     */
    registerQuery(queryId: string, callback?: QueryCallback, isBatch?: boolean, batchIndex?: number, totalBatchSize?: number): void;
    /**
     * Update query status
     */
    updateQueryStatus(queryId: string, updates: Partial<QueryStatus>): void;
    /**
     * Update query progress
     */
    updateQueryProgress(queryId: string, progress: number, message?: string): void;
    /**
     * Mark query as completed
     */
    completeQuery(queryId: string, results?: unknown): void;
    /**
     * Mark query as failed
     */
    failQuery(queryId: string, error: unknown): void;
    /**
     * Cancel a running query
     */
    cancelQuery(queryId: string): boolean;
    /**
     * Get query status
     */
    getQueryStatus(queryId: string): QueryStatus | undefined;
    /**
     * Get all active queries
     */
    getActiveQueries(): QueryStatus[];
    /**
     * Get all queries
     */
    getAllQueries(): QueryStatus[];
    /**
     * Clean up query from tracking
     */
    private cleanupQuery;
    /**
     * Clean up all completed queries
     */
    cleanupCompletedQueries(): void;
    /**
     * Get query statistics
     */
    getStatistics(): {
        total: number;
        pending: number;
        running: number;
        completed: number;
        error: number;
        cancelled: number;
        timeout: number;
    };
    /**
     * Close WebSocket server and cleanup
     */
    close(): void;
}
//# sourceMappingURL=queryNotificationManager.d.ts.map