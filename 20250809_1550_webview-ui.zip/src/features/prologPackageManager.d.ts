import { PrologBackend } from '../prologBackend';
export interface PrologPack {
    name: string;
    version?: string;
    title?: string;
    description?: string;
    author?: string;
    home?: string;
    download?: string;
    requires?: string[];
    conflicts?: string[];
    installed?: boolean;
    outdated?: boolean;
}
export interface PackageOperationResult {
    success: boolean;
    message: string;
    details?: string;
}
export declare class PrologPackageManager {
    private backend;
    private packServers;
    constructor(backend: PrologBackend);
    /**
     * List all available SWI-Prolog packs from configured servers
     */
    listAvailablePacks(): Promise<PrologPack[]>;
    /**
     * List installed SWI-Prolog packs
     */
    listInstalledPacks(): Promise<PrologPack[]>;
    /**
     * Install a Prolog pack by name
     */
    installPack(packName: string): Promise<PackageOperationResult>;
    /**
     * Uninstall a Prolog pack by name
     */
    uninstallPack(packName: string): Promise<PackageOperationResult>;
    /**
     * Update a Prolog pack by name
     */
    updatePack(packName: string): Promise<PackageOperationResult>;
    /**
     * Get detailed information about a pack
     */
    getPackInfo(packName: string): Promise<PrologPack | null>;
    /**
     * Search for packs by keyword
     */
    searchPacks(keyword: string): Promise<PrologPack[]>;
    /**
     * Add a custom pack server
     */
    addPackServer(serverUrl: string): void;
    /**
     * Remove a custom pack server
     */
    removePackServer(serverUrl: string): void;
    /**
     * Get list of configured pack servers
     */
    getPackServers(): string[];
    /**
     * Check for outdated packs
     */
    checkOutdatedPacks(): Promise<PrologPack[]>;
    private validatePackName;
    private parsePackList;
    private parsePackData;
    private parsePackInfo;
    /**
     * Validate pack security and warn about untrusted packs
     */
    validatePackSecurity(packName: string): Promise<{
        safe: boolean;
        warnings: string[];
    }>;
}
//# sourceMappingURL=prologPackageManager.d.ts.map