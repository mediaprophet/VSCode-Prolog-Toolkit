"use strict";
/**
 * API-related type definitions for HTTP API, WebSocket, and external integrations
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.InternalServerError = exports.ResourceNotFoundError = exports.RateLimitError = exports.AuthorizationError = exports.AuthenticationError = exports.ValidationError = void 0;
class ValidationError extends Error {
    field;
    value;
    constraint;
    statusCode = 400;
    code = 'VALIDATION_ERROR';
    constructor(message, field, value, constraint) {
        super(message);
        this.field = field;
        this.value = value;
        this.constraint = constraint;
        this.name = 'ValidationError';
    }
}
exports.ValidationError = ValidationError;
class AuthenticationError extends Error {
    statusCode = 401;
    code = 'AUTHENTICATION_ERROR';
    constructor(message = 'Authentication required') {
        super(message);
        this.name = 'AuthenticationError';
    }
}
exports.AuthenticationError = AuthenticationError;
class AuthorizationError extends Error {
    statusCode = 403;
    code = 'AUTHORIZATION_ERROR';
    constructor(message = 'Insufficient permissions') {
        super(message);
        this.name = 'AuthorizationError';
    }
}
exports.AuthorizationError = AuthorizationError;
class RateLimitError extends Error {
    retryAfter;
    statusCode = 429;
    code = 'RATE_LIMIT_ERROR';
    constructor(message = 'Rate limit exceeded', retryAfter) {
        super(message);
        this.retryAfter = retryAfter;
        this.name = 'RateLimitError';
    }
}
exports.RateLimitError = RateLimitError;
class ResourceNotFoundError extends Error {
    statusCode = 404;
    code = 'RESOURCE_NOT_FOUND';
    constructor(resource, id) {
        super(`${resource}${id ? ` with id '${id}'` : ''} not found`);
        this.name = 'ResourceNotFoundError';
    }
}
exports.ResourceNotFoundError = ResourceNotFoundError;
class InternalServerError extends Error {
    statusCode = 500;
    code = 'INTERNAL_SERVER_ERROR';
    constructor(message = 'Internal server error') {
        super(message);
        this.name = 'InternalServerError';
    }
}
exports.InternalServerError = InternalServerError;
//# sourceMappingURL=api.js.map