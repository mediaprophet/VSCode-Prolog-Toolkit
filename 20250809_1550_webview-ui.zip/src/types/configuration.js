"use strict";
/**
 * Configuration type definitions for the extension
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=configuration.js.map