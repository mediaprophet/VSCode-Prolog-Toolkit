/**
 * VSCode-specific type definitions for extension functionality
 */
import { ExtensionContext, TextDocument, Position, Range, Location, Hover, DocumentHighlight, DocumentHighlightKind, CompletionItem, CompletionItemKind, CodeAction, CodeActionKind, Diagnostic, DiagnosticSeverity, DiagnosticRelatedInformation, TextEdit, WorkspaceEdit, ChatRequest, ChatResponseStream, CancellationToken, ChatResult, Terminal, TerminalExitStatus, Uri, MarkdownString, MarkedString, SnippetString, Command } from 'vscode';
export interface ExtensionState {
    context: ExtensionContext;
    isActive: boolean;
    activatedAt?: Date;
    version: string;
    configuration: ExtensionConfiguration;
}
export interface ExtensionConfiguration {
    executablePath: string;
    dialect: 'swi' | 'ecl';
    linter: {
        run: 'onSave' | 'onType' | 'never';
        delay: number;
        enableMsgInOutput: boolean;
    };
    format: {
        enabled: boolean;
        addSpace: boolean;
    };
    terminal: {
        runtimeArgs: string[];
    };
    telemetry: {
        enabled: boolean;
    };
    apiServer: {
        enabled: boolean;
        port: number;
        host: string;
        corsOrigins: string[];
        maxConnections: number;
        requestTimeout: number;
        rateLimiting: {
            enabled: boolean;
            requestsPerMinute: number;
            burstLimit: number;
        };
        auth: {
            method: 'local_only' | 'api_key' | 'jwt_token' | 'oauth2';
            apiKeys: Record<string, {
                role: 'admin' | 'agent' | 'readonly' | 'limited';
                permissions: string[];
            }>;
            jwtSecret: string;
            jwtExpiration: string;
        };
    };
    webSocketServer: {
        enabled: boolean;
        port: number;
        maxConnections: number;
        heartbeatInterval: number;
    };
}
export interface PrologDocument {
    document: TextDocument;
    uri: Uri;
    languageId: 'prolog';
    version: number;
    getText(): string;
    getWordRangeAtPosition(position: Position): Range | undefined;
    lineAt(line: number): {
        text: string;
        range: Range;
        rangeIncludingLineBreak: Range;
        firstNonWhitespaceCharacterIndex: number;
        isEmptyOrWhitespace: boolean;
    };
}
export interface PrologPosition extends Position {
    line: number;
    character: number;
}
export interface PrologRange extends Range {
    start: PrologPosition;
    end: PrologPosition;
}
export interface PrologLocation extends Location {
    uri: Uri;
    range: PrologRange;
}
export interface PrologHoverInfo {
    predicate: string;
    arity: number;
    module?: string;
    documentation?: string;
    signature?: string;
    examples?: string[];
    seeAlso?: string[];
    isBuiltin: boolean;
    isDeterministic?: boolean;
}
export interface PrologHover extends Hover {
    contents: (MarkdownString | MarkedString)[];
    range?: PrologRange;
}
export interface PrologDefinition {
    predicate: string;
    arity: number;
    file: string;
    line: number;
    column: number;
    clause?: string;
    isExported?: boolean;
    module?: string;
}
export interface PrologReference {
    predicate: string;
    arity: number;
    file: string;
    line: number;
    column: number;
    context: 'definition' | 'call' | 'export' | 'import';
    clause?: string;
}
export interface PrologDocumentHighlight extends DocumentHighlight {
    range: PrologRange;
    kind?: DocumentHighlightKind;
}
export interface PrologCompletionItem extends CompletionItem {
    label: string;
    kind: CompletionItemKind;
    detail?: string;
    documentation?: string | MarkdownString;
    insertText?: string | SnippetString;
    predicate?: string;
    arity?: number;
    module?: string;
    isBuiltin?: boolean;
}
export interface PrologCodeAction extends CodeAction {
    title: string;
    kind?: CodeActionKind;
    diagnostics?: Diagnostic[];
    edit?: WorkspaceEdit;
    command?: Command;
}
export interface PrologDiagnostic extends Diagnostic {
    range: PrologRange;
    message: string;
    severity: DiagnosticSeverity;
    source?: string;
    code?: string | number;
    relatedInformation?: DiagnosticRelatedInformation[];
}
export interface PrologFormattingOptions {
    tabSize: number;
    insertSpaces: boolean;
    addSpaceAfterCommas: boolean;
    indentClauses: boolean;
    alignParameters: boolean;
    maxLineLength?: number;
}
export interface PrologTextEdit extends TextEdit {
    range: PrologRange;
    newText: string;
}
export interface PrologLinterOptions {
    trigger: 'onSave' | 'onType' | 'never';
    delay: number;
    enableOutput: boolean;
    executablePath: string;
    additionalArgs: string[];
}
export interface PrologLinterResult {
    diagnostics: PrologDiagnostic[];
    success: boolean;
    output?: string;
    error?: string;
    executionTime: number;
}
export interface PrologTerminalOptions {
    name: string;
    shellPath: string;
    shellArgs: string[];
    cwd?: string;
    env?: Record<string, string>;
}
export interface PrologTerminal extends Omit<Terminal, 'exitStatus'> {
    name: string;
    processId: Promise<number | undefined>;
    creationOptions: PrologTerminalOptions;
    exitStatus: Promise<TerminalExitStatus | undefined>;
    sendText(text: string, addNewLine?: boolean): void;
    show(preserveFocus?: boolean): void;
    hide(): void;
    dispose(): void;
}
export interface PrologChatContext {
    request: ChatRequest;
    stream: ChatResponseStream;
    token: CancellationToken;
    command?: string;
    args?: string[];
}
export interface PrologChatResult extends ChatResult {
    metadata?: {
        command?: string;
        success?: boolean;
        executionTime?: number;
        resultCount?: number;
        error?: string;
    };
}
export interface PrologChatCommand {
    name: string;
    description: string;
    handler: (context: PrologChatContext) => Promise<void>;
    examples?: string[];
    parameters?: Array<{
        name: string;
        description: string;
        required: boolean;
        type: 'string' | 'number' | 'boolean';
    }>;
}
export interface TelemetryData {
    command: string;
    success: boolean;
    error?: string;
    timestamp: number;
    executionTime?: number;
    resultCount?: number;
    userId?: string;
    sessionId?: string;
}
export interface TelemetryCollector {
    enabled: boolean;
    collect(data: TelemetryData): void;
    getStats(): {
        totalCommands: number;
        commands: Record<string, number>;
        successRate: number;
        averageExecutionTime: number;
    } | null;
    clear(): void;
}
export interface PrologDebugConfiguration {
    type: 'prolog';
    request: 'launch';
    name: string;
    program: string;
    startupQuery: string;
    stopOnEntry: boolean;
    cwd: string;
    env: Record<string, string>;
    runtimeExecutable: string;
    runtimeArgs: string[];
    traceCmds: {
        continue: string[];
        stepover: string[];
        stepinto: string[];
        stepout: string[];
    };
}
export interface PrologDebugSession {
    id: string;
    configuration: PrologDebugConfiguration;
    isRunning: boolean;
    currentFrame?: {
        file: string;
        line: number;
        predicate: string;
        variables: Record<string, any>;
    };
}
export interface PrologSnippet {
    name: string;
    prefix: string;
    body: string | string[];
    description: string;
    scope?: string;
    predicate?: string;
    arity?: number;
    module?: string;
}
export interface SnippetCollection {
    [key: string]: PrologSnippet;
}
export interface PrologRefactorAction {
    type: 'rename' | 'extract' | 'inline' | 'move';
    title: string;
    description: string;
    predicate: string;
    arity: number;
    range: PrologRange;
    newName?: string;
    targetFile?: string;
}
export interface PrologWorkspace {
    rootPath: string;
    folders: Array<{
        uri: Uri;
        name: string;
        index: number;
    }>;
    prologFiles: Uri[];
    configuration: ExtensionConfiguration;
}
export interface ExtensionEventMap {
    activated: (context: ExtensionContext) => void;
    deactivated: () => void;
    configurationChanged: (config: ExtensionConfiguration) => void;
    documentOpened: (document: PrologDocument) => void;
    documentClosed: (document: PrologDocument) => void;
    documentSaved: (document: PrologDocument) => void;
    terminalCreated: (terminal: PrologTerminal) => void;
    terminalClosed: (terminal: PrologTerminal) => void;
    debugSessionStarted: (session: PrologDebugSession) => void;
    debugSessionEnded: (session: PrologDebugSession) => void;
}
export interface PrologCommand {
    command: string;
    title: string;
    category?: string;
    handler: (...args: any[]) => any;
    when?: string;
}
export interface SettingsWebViewMessage {
    type: 'getSetting' | 'setSetting' | 'resetSetting' | 'exportSettings' | 'importSettings';
    key?: string;
    value?: any;
    settings?: Record<string, any>;
}
export interface SettingsWebViewState {
    settings: ExtensionConfiguration;
    isDirty: boolean;
    lastSaved?: Date;
}
export interface IDEConfiguration {
    name: string;
    configFiles: Array<{
        path: string;
        content: string;
        description: string;
    }>;
    launchConfigurations?: Array<{
        name: string;
        type: string;
        request: string;
        [key: string]: any;
    }>;
}
export interface SupportedIDE {
    name: string;
    detected: boolean;
    version?: string;
    configPath?: string;
    executable?: string;
}
//# sourceMappingURL=vscode.d.ts.map