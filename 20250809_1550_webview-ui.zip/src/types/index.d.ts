/**
 * Core type definitions for VSCode Prolog Toolkit
 * This file exports all type definitions used throughout the extension
 */
export * from './backend';
export * from './api';
export * from './utils';
export * from './vscode';
export * from './configuration';
export type Awaitable<T> = T | Promise<T>;
export type Optional<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;
export type RequiredKeys<T, K extends keyof T> = T & Required<Pick<T, K>>;
export type DeepPartial<T> = {
    [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};
export interface ErrorWithCode extends Error {
    code?: string;
    statusCode?: number;
    details?: Record<string, any>;
}
export interface ValidationError extends ErrorWithCode {
    field?: string;
    value?: any;
    constraint?: string;
}
export type EventCallback<T = any> = (data: T) => void;
export type EventMap = Record<string, (...args: any[]) => void>;
export interface Result<T, E = Error> {
    success: boolean;
    data?: T;
    error?: E;
    message?: string;
}
export interface PaginatedResult<T> {
    items: T[];
    total: number;
    limit: number;
    offset: number;
    hasMore: boolean;
}
export interface TimeRange {
    start: Date;
    end: Date;
}
export interface Timestamp {
    createdAt: Date;
    updatedAt?: Date;
}
export type UUID = string;
export type EntityId = string;
export type Status = 'active' | 'inactive' | 'pending' | 'error' | 'completed';
export type Priority = 'low' | 'medium' | 'high' | 'critical';
export interface BaseConfig {
    enabled: boolean;
    [key: string]: any;
}
export type LogLevel = 'debug' | 'info' | 'warn' | 'error';
export interface LogEntry {
    level: LogLevel;
    message: string;
    timestamp: Date;
    context?: Record<string, any>;
}
//# sourceMappingURL=index.d.ts.map