"use strict";
/**
 * VSCode-specific type definitions for extension functionality
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=vscode.js.map