"use strict";
/**
 * Backend-related type definitions for PrologBackend and related functionality
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=backend.js.map