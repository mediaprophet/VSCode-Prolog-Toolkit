import { EventEmitter } from 'events';
export interface PrologWebSocketConfig {
    url: string;
    auth?: {
        type: 'api_key' | 'jwt_token' | 'none';
        apiKey?: string;
        jwtToken?: string;
    };
    reconnect?: {
        enabled: boolean;
        maxAttempts: number;
        delay: number;
        backoff: boolean;
    };
    heartbeat?: {
        enabled: boolean;
        interval: number;
    };
}
export interface QueryNotification {
    type: 'query_progress' | 'query_complete';
    query_id: string;
    status?: string;
    progress?: number;
    message?: string;
    results?: any[];
    execution_time?: number;
    timestamp: string;
}
export interface SessionEvent {
    type: 'session_event';
    session_id: string;
    event: 'created' | 'switched' | 'deleted' | 'state_saved';
    timestamp: string;
}
export interface SystemStatus {
    type: 'system_status';
    active_queries: number;
    active_sessions: number;
    memory_usage?: any;
    cpu_usage?: number;
}
/**
 * WebSocket client for real-time Prolog notifications
 * Provides real-time updates for query progress, session events, and system status
 */
export declare class PrologWebSocketClient extends EventEmitter {
    private ws;
    private config;
    private reconnectAttempts;
    private reconnectTimer;
    private heartbeatTimer;
    private isConnected;
    private subscriptions;
    constructor(config: PrologWebSocketConfig);
    /**
     * Connect to the WebSocket server
     */
    connect(): Promise<void>;
    /**
     * Disconnect from the WebSocket server
     */
    disconnect(): void;
    /**
     * Subscribe to query notifications
     */
    subscribeToQuery(queryId: string, eventTypes?: string[]): Promise<void>;
    /**
     * Subscribe to session events
     */
    subscribeToSession(sessionId: string, eventTypes?: string[]): Promise<void>;
    /**
     * Subscribe to system status updates
     */
    subscribeToSystemStatus(): Promise<void>;
    /**
     * Unsubscribe from query notifications
     */
    unsubscribeFromQuery(queryId: string): Promise<void>;
    /**
     * Unsubscribe from session events
     */
    unsubscribeFromSession(sessionId: string): Promise<void>;
    /**
     * Cancel a running query
     */
    cancelQuery(queryId: string): Promise<void>;
    /**
     * Get query status
     */
    getQueryStatus(queryId: string): Promise<void>;
    /**
     * Get system status
     */
    getSystemStatus(): Promise<void>;
    /**
     * Send ping to server
     */
    ping(): void;
    /**
     * Check if connected
     */
    isConnectedToServer(): boolean;
    /**
     * Get current subscriptions
     */
    getSubscriptions(): string[];
    /**
     * Build connection URL with authentication
     */
    private buildConnectionUrl;
    /**
     * Handle incoming WebSocket messages
     */
    private handleMessage;
    /**
     * Send message to server
     */
    private send;
    /**
     * Schedule reconnection attempt
     */
    private scheduleReconnect;
    /**
     * Start heartbeat mechanism
     */
    private startHeartbeat;
    /**
     * Stop heartbeat mechanism
     */
    private stopHeartbeat;
}
/**
 * Factory function to create a PrologWebSocketClient instance
 */
export declare function createPrologWebSocketClient(config: PrologWebSocketConfig): PrologWebSocketClient;
/**
 * Convenience function to create a WebSocket client with API key authentication
 */
export declare function createApiKeyWebSocketClient(url: string, apiKey: string): PrologWebSocketClient;
/**
 * Convenience function to create a WebSocket client with JWT authentication
 */
export declare function createJwtWebSocketClient(url: string, jwtToken: string): PrologWebSocketClient;
/**
 * Convenience function to create a local WebSocket client (no authentication)
 */
export declare function createLocalWebSocketClient(url?: string): PrologWebSocketClient;
//# sourceMappingURL=prologWebSocketClient.d.ts.map