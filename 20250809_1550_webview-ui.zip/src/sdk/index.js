"use strict";
/**
 * VSCode Prolog Toolkit API SDK
 *
 * A comprehensive TypeScript/JavaScript SDK for integrating AI agents and external applications
 * with the VSCode Prolog Toolkit's HTTP and WebSocket APIs.
 *
 * @version 1.0.0
 * @author VSCode Prolog Toolkit Team
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.utils = exports.DEFAULT_CONFIG = exports.SUPPORTED_API_VERSION = exports.SDK_VERSION = exports.PrologSDK = exports.createLocalWebSocketClient = exports.createJwtWebSocketClient = exports.createApiKeyWebSocketClient = exports.createPrologWebSocketClient = exports.PrologWebSocketClient = exports.createLocalClient = exports.createJwtClient = exports.createApiKeyClient = exports.createPrologApiClient = exports.PrologApiClient = void 0;
exports.createPrologSDK = createPrologSDK;
exports.createLocalSDK = createLocalSDK;
exports.createApiKeySDK = createApiKeySDK;
exports.createJwtSDK = createJwtSDK;
// Main API Client
var prologApiClient_1 = require("./prologApiClient");
Object.defineProperty(exports, "PrologApiClient", { enumerable: true, get: function () { return prologApiClient_1.PrologApiClient; } });
Object.defineProperty(exports, "createPrologApiClient", { enumerable: true, get: function () { return prologApiClient_1.createPrologApiClient; } });
Object.defineProperty(exports, "createApiKeyClient", { enumerable: true, get: function () { return prologApiClient_1.createApiKeyClient; } });
Object.defineProperty(exports, "createJwtClient", { enumerable: true, get: function () { return prologApiClient_1.createJwtClient; } });
Object.defineProperty(exports, "createLocalClient", { enumerable: true, get: function () { return prologApiClient_1.createLocalClient; } });
// WebSocket Client
var prologWebSocketClient_1 = require("./prologWebSocketClient");
Object.defineProperty(exports, "PrologWebSocketClient", { enumerable: true, get: function () { return prologWebSocketClient_1.PrologWebSocketClient; } });
Object.defineProperty(exports, "createPrologWebSocketClient", { enumerable: true, get: function () { return prologWebSocketClient_1.createPrologWebSocketClient; } });
Object.defineProperty(exports, "createApiKeyWebSocketClient", { enumerable: true, get: function () { return prologWebSocketClient_1.createApiKeyWebSocketClient; } });
Object.defineProperty(exports, "createJwtWebSocketClient", { enumerable: true, get: function () { return prologWebSocketClient_1.createJwtWebSocketClient; } });
Object.defineProperty(exports, "createLocalWebSocketClient", { enumerable: true, get: function () { return prologWebSocketClient_1.createLocalWebSocketClient; } });
// Type Definitions
__exportStar(require("./types"), exports);
// Import the classes for use in the SDK
const prologApiClient_2 = require("./prologApiClient");
const prologWebSocketClient_2 = require("./prologWebSocketClient");
/**
 * Combined SDK class that provides both HTTP and WebSocket functionality
 */
class PrologSDK {
    api;
    ws;
    constructor(config) {
        this.api = new prologApiClient_2.PrologApiClient(config.apiConfig);
        if (config.wsConfig) {
            this.ws = new prologWebSocketClient_2.PrologWebSocketClient(config.wsConfig);
        }
        else {
            // Create WebSocket client with same auth as API client
            const wsUrl = config.apiConfig.baseUrl.replace(/^https?:/, 'ws:').replace(/^http:/, 'ws:') + ':8081';
            this.ws = new prologWebSocketClient_2.PrologWebSocketClient({
                url: wsUrl,
                auth: config.apiConfig.auth,
            });
        }
    }
    /**
     * Initialize both API and WebSocket connections
     */
    async connect() {
        await this.ws.connect();
    }
    /**
     * Disconnect from both API and WebSocket
     */
    async disconnect() {
        this.ws.disconnect();
    }
    /**
     * Execute a query with real-time progress notifications
     */
    async queryWithNotifications(request, onProgress) {
        // Subscribe to query notifications if WebSocket is connected
        if (this.ws.isConnectedToServer() && onProgress) {
            const response = await this.api.query(request);
            // Subscribe to this specific query
            await this.ws.subscribeToQuery(response.query_id);
            // Set up progress listener
            const progressHandler = (notification) => {
                if (notification.query_id === response.query_id) {
                    onProgress(notification);
                    // Unsubscribe when query completes
                    if (notification.type === 'query_complete') {
                        this.ws.unsubscribeFromQuery(response.query_id);
                        this.ws.off('queryProgress', progressHandler);
                        this.ws.off('queryComplete', progressHandler);
                    }
                }
            };
            this.ws.on('queryProgress', progressHandler);
            this.ws.on('queryComplete', progressHandler);
            return response;
        }
        else {
            // Fallback to regular query without notifications
            return this.api.query(request);
        }
    }
    /**
     * Test connection to both API and WebSocket servers
     */
    async testConnection() {
        const apiTest = await this.api.testConnection();
        const wsStart = Date.now();
        const wsConnected = this.ws.isConnectedToServer();
        const wsLatency = wsConnected ? Date.now() - wsStart : -1;
        return {
            api: apiTest,
            websocket: {
                connected: wsConnected,
                latency: wsLatency,
            },
        };
    }
}
exports.PrologSDK = PrologSDK;
/**
 * Factory function to create a complete SDK instance
 */
function createPrologSDK(config) {
    const apiConfig = {
        baseUrl: config.baseUrl,
        auth: config.auth,
    };
    const wsConfig = {
        url: config.wsUrl || config.baseUrl.replace(/^https?:/, 'ws:') + ':8081',
        auth: config.auth,
    };
    return new PrologSDK({ apiConfig, wsConfig });
}
/**
 * Convenience function to create SDK for local development
 */
function createLocalSDK(apiUrl = 'http://localhost:8080', wsUrl = 'ws://localhost:8081') {
    return createPrologSDK({
        baseUrl: apiUrl,
        wsUrl,
        auth: { type: 'none' },
    });
}
/**
 * Convenience function to create SDK with API key authentication
 */
function createApiKeySDK(baseUrl, apiKey, wsUrl) {
    return createPrologSDK({
        baseUrl,
        wsUrl,
        auth: {
            type: 'api_key',
            apiKey,
        },
    });
}
/**
 * Convenience function to create SDK with JWT authentication
 */
function createJwtSDK(baseUrl, jwtToken, wsUrl) {
    return createPrologSDK({
        baseUrl,
        wsUrl,
        auth: {
            type: 'jwt_token',
            jwtToken,
        },
    });
}
// Version information
exports.SDK_VERSION = '1.0.0';
exports.SUPPORTED_API_VERSION = 'v1';
// Default configurations
exports.DEFAULT_CONFIG = {
    API_PORT: 8080,
    WEBSOCKET_PORT: 8081,
    TIMEOUT: 30000,
    MAX_RETRIES: 3,
    RETRY_DELAY: 1000,
    HEARTBEAT_INTERVAL: 30000,
    MAX_RECONNECT_ATTEMPTS: 5,
};
/**
 * Utility functions for common operations
 */
exports.utils = {
    /**
     * Validate Prolog query syntax (basic validation)
     */
    validateQuery(query) {
        if (!query || typeof query !== 'string') {
            return { valid: false, error: 'Query must be a non-empty string' };
        }
        const trimmed = query.trim();
        if (trimmed.length === 0) {
            return { valid: false, error: 'Query cannot be empty' };
        }
        // Basic syntax checks
        const openParens = (trimmed.match(/\(/g) || []).length;
        const closeParens = (trimmed.match(/\)/g) || []).length;
        if (openParens !== closeParens) {
            return { valid: false, error: 'Mismatched parentheses' };
        }
        return { valid: true };
    },
    /**
     * Format query results for display
     */
    formatResults(results) {
        if (!results || results.length === 0) {
            return 'No results found.';
        }
        return results
            .map((result, index) => {
            if (typeof result === 'object' && result !== null) {
                const bindings = Object.entries(result)
                    .map(([variable, value]) => `${variable} = ${value}`)
                    .join(', ');
                return `Solution ${index + 1}: ${bindings}`;
            }
            else {
                return `Solution ${index + 1}: ${result}`;
            }
        })
            .join('\n');
    },
    /**
     * Create a session name with timestamp
     */
    createSessionName(prefix = 'session') {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        return `${prefix}-${timestamp}`;
    },
    /**
     * Parse error response
     */
    parseError(error) {
        if (error.response?.data) {
            return {
                message: error.response.data.message || error.response.data.error || 'Unknown API error',
                code: error.response.data.code,
                status: error.response.status,
            };
        }
        else if (error.message) {
            return { message: error.message };
        }
        else {
            return { message: 'Unknown error occurred' };
        }
    },
};
// Export default SDK class
exports.default = PrologSDK;
//# sourceMappingURL=index.js.map