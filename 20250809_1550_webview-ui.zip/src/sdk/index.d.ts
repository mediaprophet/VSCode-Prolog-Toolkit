/**
 * VSCode Prolog Toolkit API SDK
 *
 * A comprehensive TypeScript/JavaScript SDK for integrating AI agents and external applications
 * with the VSCode Prolog Toolkit's HTTP and WebSocket APIs.
 *
 * @version 1.0.0
 * @author VSCode Prolog Toolkit Team
 */
export { PrologApiClient, createPrologApiClient, createApiKeyClient, createJwtClient, createLocalClient, } from './prologApiClient';
export { PrologWebSocketClient, createPrologWebSocketClient, createApiKeyWebSocketClient, createJwtWebSocketClient, createLocalWebSocketClient, } from './prologWebSocketClient';
export * from './types';
export type { PrologApiClientConfig, QueryRequest, QueryResponse, BatchRequest, BatchResponse, SessionConfig, Session, CLPRequest, ProbabilisticRequest, N3Request, } from './prologApiClient';
export type { PrologWebSocketConfig, QueryNotification, SessionEvent, SystemStatus, } from './prologWebSocketClient';
/**
 * Combined SDK class that provides both HTTP and WebSocket functionality
 */
export declare class PrologSDK {
    readonly api: import('./prologApiClient').PrologApiClient;
    readonly ws: import('./prologWebSocketClient').PrologWebSocketClient;
    constructor(config: {
        apiConfig: import('./prologApiClient').PrologApiClientConfig;
        wsConfig?: import('./prologWebSocketClient').PrologWebSocketConfig;
    });
    /**
     * Initialize both API and WebSocket connections
     */
    connect(): Promise<void>;
    /**
     * Disconnect from both API and WebSocket
     */
    disconnect(): Promise<void>;
    /**
     * Execute a query with real-time progress notifications
     */
    queryWithNotifications(request: import('./prologApiClient').QueryRequest, onProgress?: (notification: import('./prologWebSocketClient').QueryNotification) => void): Promise<import('./prologApiClient').QueryResponse>;
    /**
     * Test connection to both API and WebSocket servers
     */
    testConnection(): Promise<{
        api: {
            connected: boolean;
            latency: number;
            version?: string;
        };
        websocket: {
            connected: boolean;
            latency: number;
        };
    }>;
}
/**
 * Factory function to create a complete SDK instance
 */
export declare function createPrologSDK(config: {
    baseUrl: string;
    auth?: {
        type: 'api_key' | 'jwt_token' | 'none';
        apiKey?: string;
        jwtToken?: string;
    };
    wsUrl?: string;
}): PrologSDK;
/**
 * Convenience function to create SDK for local development
 */
export declare function createLocalSDK(apiUrl?: string, wsUrl?: string): PrologSDK;
/**
 * Convenience function to create SDK with API key authentication
 */
export declare function createApiKeySDK(baseUrl: string, apiKey: string, wsUrl?: string): PrologSDK;
/**
 * Convenience function to create SDK with JWT authentication
 */
export declare function createJwtSDK(baseUrl: string, jwtToken: string, wsUrl?: string): PrologSDK;
export declare const SDK_VERSION = "1.0.0";
export declare const SUPPORTED_API_VERSION = "v1";
export declare const DEFAULT_CONFIG: {
    API_PORT: number;
    WEBSOCKET_PORT: number;
    TIMEOUT: number;
    MAX_RETRIES: number;
    RETRY_DELAY: number;
    HEARTBEAT_INTERVAL: number;
    MAX_RECONNECT_ATTEMPTS: number;
};
/**
 * Utility functions for common operations
 */
export declare const utils: {
    /**
     * Validate Prolog query syntax (basic validation)
     */
    validateQuery(query: string): {
        valid: boolean;
        error?: string;
    };
    /**
     * Format query results for display
     */
    formatResults(results: any[]): string;
    /**
     * Create a session name with timestamp
     */
    createSessionName(prefix?: string): string;
    /**
     * Parse error response
     */
    parseError(error: any): {
        message: string;
        code?: string;
        status?: number;
    };
};
export default PrologSDK;
//# sourceMappingURL=index.d.ts.map