"use strict";
/**
 * TypeScript type definitions for VSCode Prolog Toolkit API SDK
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=types.js.map