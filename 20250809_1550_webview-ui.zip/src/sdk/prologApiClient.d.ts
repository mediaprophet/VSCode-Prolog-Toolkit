import { EventEmitter } from 'events';
export interface PrologApiClientConfig {
    baseUrl: string;
    timeout?: number;
    auth?: {
        type: 'api_key' | 'jwt_token' | 'none';
        apiKey?: string;
        jwtToken?: string;
    };
    retries?: {
        enabled: boolean;
        maxRetries: number;
        retryDelay: number;
    };
}
export interface QueryRequest {
    query: string;
    session_id?: string;
    options?: {
        timeout?: number;
        max_results?: number;
        reasoning_mode?: 'default' | 'clp' | 'probabilistic' | 'n3' | 'custom';
        stream?: boolean;
    };
}
export interface QueryResponse {
    query_id: string;
    success: boolean;
    results: any[];
    execution_time: number;
    more_available: boolean;
    cursor?: string;
    streaming_info?: any;
}
export interface BatchRequest {
    queries: (QueryRequest | string)[];
    session_id?: string;
    batch_options?: {
        parallel?: boolean;
        fail_fast?: boolean;
        timeout?: number;
    };
}
export interface BatchResponse {
    batch_id: string;
    results: Array<{
        query_index: number;
        success: boolean;
        results: any[];
        error?: string;
    }>;
    total_queries: number;
    successful_queries: number;
}
export interface SessionConfig {
    name: string;
    description?: string;
    config?: any;
}
export interface Session {
    session_id: string;
    name: string;
    description?: string;
    created_at: string;
    is_active: boolean;
    user_id?: string;
}
export interface CLPRequest {
    constraints: string[];
    domain: 'fd' | 'r' | 'q';
    variables: string[];
}
export interface ProbabilisticRequest {
    facts: Array<{
        fact: string;
        probability: number;
    }>;
    query: string;
    samples?: number;
}
export interface N3Request {
    rules?: string;
    data?: string;
    query: string;
}
/**
 * TypeScript/JavaScript SDK for VSCode Prolog Toolkit API
 * Provides easy integration for AI agents and external applications
 */
export declare class PrologApiClient extends EventEmitter {
    private client;
    private config;
    constructor(config: PrologApiClientConfig);
    /**
     * Set up authentication headers
     */
    private setupAuthentication;
    /**
     * Set up request/response interceptors
     */
    private setupInterceptors;
    /**
     * Check if request should be retried
     */
    private shouldRetry;
    /**
     * Retry failed request
     */
    private retryRequest;
    /**
     * Execute a single Prolog query
     */
    query(request: QueryRequest): Promise<QueryResponse>;
    /**
     * Execute multiple queries in batch
     */
    batch(request: BatchRequest): Promise<BatchResponse>;
    /**
     * List all sessions
     */
    listSessions(includeInactive?: boolean): Promise<{
        sessions: Session[];
        total: number;
    }>;
    /**
     * Create a new session
     */
    createSession(config: SessionConfig): Promise<Session>;
    /**
     * Get session details
     */
    getSession(sessionId: string): Promise<any>;
    /**
     * Delete a session
     */
    deleteSession(sessionId: string): Promise<{
        message: string;
    }>;
    /**
     * Export session state
     */
    exportSessionState(sessionId: string): Promise<any>;
    /**
     * Import session state
     */
    importSessionState(sessionId: string, state: any): Promise<{
        message: string;
    }>;
    /**
     * Execute CLP (Constraint Logic Programming) reasoning
     */
    clpReasoning(request: CLPRequest): Promise<any>;
    /**
     * Execute probabilistic inference
     */
    probabilisticReasoning(request: ProbabilisticRequest): Promise<any>;
    /**
     * Execute N3/RDF reasoning
     */
    n3Reasoning(request: N3Request): Promise<any>;
    /**
     * Get query history
     */
    getHistory(options?: {
        session_id?: string;
        limit?: number;
        offset?: number;
        status?: string;
    }): Promise<any>;
    /**
     * Get system status
     */
    getStatus(): Promise<any>;
    /**
     * Check API health
     */
    health(): Promise<any>;
    /**
     * Update authentication
     */
    updateAuth(auth: PrologApiClientConfig['auth']): void;
    /**
     * Update base URL
     */
    updateBaseUrl(baseUrl: string): void;
    /**
     * Handle API errors
     */
    private handleError;
    /**
     * Get client configuration
     */
    getConfig(): PrologApiClientConfig;
    /**
     * Test connection to the API
     */
    testConnection(): Promise<{
        connected: boolean;
        latency: number;
        version?: string;
        error?: string;
    }>;
}
/**
 * Factory function to create a PrologApiClient instance
 */
export declare function createPrologApiClient(config: PrologApiClientConfig): PrologApiClient;
/**
 * Convenience function to create a client with API key authentication
 */
export declare function createApiKeyClient(baseUrl: string, apiKey: string): PrologApiClient;
/**
 * Convenience function to create a client with JWT authentication
 */
export declare function createJwtClient(baseUrl: string, jwtToken: string): PrologApiClient;
/**
 * Convenience function to create a local client (no authentication)
 */
export declare function createLocalClient(baseUrl?: string): PrologApiClient;
//# sourceMappingURL=prologApiClient.d.ts.map