% src/prolog_json_server.pl

:- use_module(library(http/http_server)).
:- use_module(library(http/json)).
:- use_module(library(http/http_unix_daemon)).
:- use_module(library(http/http_cors)).
:- use_module(library(apply)).
:- use_module(library(pldoc)).

main :-
    http_daemon.

handler(Request) :-
    cors_enable,
    http_read_json(Request, DictIn),
    format(user_error, '[prolog_json_server] Received request: ~w~n', [DictIn]),
    (   DictIn = _{cmd:Cmd, id:Id} 
    ->  catch(handle_cmd(Cmd, DictIn, Id, DictOut), Err, DictOut = _{id:Id, status:error, error:Err}),
        reply_json_dict(DictOut)
    ;   reply_json_dict(_{status:error, error:'missing_cmd_or_id'})
    ).

handle_cmd(Cmd, Dict, Id, DictOut) :-
    % Your original handle_cmd/3 logic here, but adapted to set DictOut instead of reply_json
    % For example:
    ( Cmd = version ->
        current_prolog_flag(version, V),
        DictOut = _{id:Id, status:ok, version:V}
    ; Cmd = query ->
        % ... (adapt other commands similarly)
    ; DictOut = _{id:Id, status:error, error:'unknown_command'}
    ).

% Add other predicates (get_predicate_doc, doc_comment, etc.) as before

% Start the server on port 3060 (or configurable)
:- http_server(handler, [port(3060)]).